package net.mcreator.climber.grip;

/**
 * Режим захвата поверхностей.
 * <ul>
 *   <li>{@link #LIP_HANDS} ("Липкие ручки") — можно цепляться за любую твёрдую поверхность блока
 *       (поведение по умолчанию).</li>
 *   <li>{@link #REALISTIC} ("Реалистичный захват") — можно цепляться только за настоящие выступы
 *       (карнизы, уступы, углы) с зазором не менее 6 пикселей — см. {@link LedgeDetector}.</li>
 * </ul>
 */
public enum GripMode {
    LIP_HANDS,
    REALISTIC;

    public static GripMode byId(String id) {
        if (id == null) return LIP_HANDS;
        for (GripMode m : values()) {
            if (m.name().equalsIgnoreCase(id)) return m;
        }
        // Удобные алиасы
        if (id.equalsIgnoreCase("lip") || id.equalsIgnoreCase("lip_hands") || id.equalsIgnoreCase("liphands")) {
            return LIP_HANDS;
        }
        if (id.equalsIgnoreCase("real") || id.equalsIgnoreCase("realistic")) {
            return REALISTIC;
        }
        return LIP_HANDS;
    }
}
