package net.mcreator.climber.grip;

/**
 * Режим работы Auto Grip — непрерывной попытки захвата, пока зажата кнопка мыши: как
 * только прицел попадает на подходящую цель (блок в Lip Hands, выступ в Realistic),
 * захват происходит автоматически, без необходимости отпускать и снова нажимать кнопку.
 * <ul>
 *   <li>{@link #OFF} — Auto Grip отключён полностью, нужен явный клик по цели.</li>
 *   <li>{@link #ONLY_LIP_HANDS} — работает только в режиме {@link GripMode#LIP_HANDS}.</li>
 *   <li>{@link #ONLY_REALISTIC} — работает только в режиме {@link GripMode#REALISTIC}.</li>
 *   <li>{@link #BOTH} — работает в обоих режимах захвата.</li>
 * </ul>
 */
public enum AutoGripMode {
    OFF,
    ONLY_LIP_HANDS,
    ONLY_REALISTIC,
    BOTH;

    /** Активен ли Auto Grip при текущем режиме захвата gripMode. */
    public boolean isActiveFor(GripMode gripMode) {
        return switch (this) {
            case OFF -> false;
            case ONLY_LIP_HANDS -> gripMode == GripMode.LIP_HANDS;
            case ONLY_REALISTIC -> gripMode == GripMode.REALISTIC;
            case BOTH -> true;
        };
    }

    public static AutoGripMode byId(String id) {
        if (id == null) return OFF;
        for (AutoGripMode m : values()) {
            if (m.name().equalsIgnoreCase(id)) return m;
        }
        String s = id.toLowerCase().replace("-", "_").trim();
        return switch (s) {
            case "off", "disabled", "none" -> OFF;
            case "only_liphands", "only_lip_hands", "lip", "liphands", "lip_hands" -> ONLY_LIP_HANDS;
            case "only_realistic", "realistic", "real" -> ONLY_REALISTIC;
            case "both", "all", "on" -> BOTH;
            default -> OFF;
        };
    }
}
