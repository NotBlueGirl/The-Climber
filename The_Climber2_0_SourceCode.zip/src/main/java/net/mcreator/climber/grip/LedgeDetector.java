package net.mcreator.climber.grip;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Realistic grip: decides whether the exact point the player aims at is a real hold.
 * <p>
 * A point is grabbable when it is
 * <ul>
 *   <li><b>a lip</b> – on a side face, no lower than {@link #GRIP_ZONE} below the top edge of the block's
 *       collision shape, with at least {@link #LEDGE_THRESHOLD} (6 px) of free space above that edge for the
 *       fingers to curl over;</li>
 *   <li><b>a top edge</b> – on a top face, within {@link #EDGE_REACH} of an edge that has a drop of at least
 *       6 px behind it;</li>
 *   <li><b>an outside corner</b> – on a side face, close to a vertical edge the hand can wrap around.</li>
 * </ul>
 * Smooth walls, the middle of floors and ceilings are not grabbable. Partial blocks (slabs, stairs, fences,
 * walls, trapdoors…) are handled through their real collision shapes.
 */
public final class LedgeDetector {

    /** 6 of 16 pixels: minimum gap for the fingers. */
    public static final double LEDGE_THRESHOLD = 6.0 / 16.0;
    /** How far below a top edge a side-face hit may be. */
    public static final double GRIP_ZONE = 7.0 / 16.0;
    /** How far from an edge a top-face hit may be. */
    public static final double EDGE_REACH = 7.0 / 16.0;
    /** How close to a vertical edge a side-face hit must be for a corner pinch. */
    public static final double CORNER_REACH = 5.0 / 16.0;
    private static final double EPS = 1.0E-4;

    private LedgeDetector() {}

    /** @deprecated use {@link #isLedge(Level, BlockPos, Direction, Vec3)} (needs the exact hit point). */
    @Deprecated
    public static boolean isLedge(Level level, BlockPos blockPos, Direction face) {
        return isLedge(level, blockPos, face, Vec3.atCenterOf(blockPos).add(
                face.getStepX() * 0.5, face.getStepY() * 0.5 + 0.45, face.getStepZ() * 0.5));
    }

    public static boolean isLedge(Level level, BlockPos pos, Direction face, Vec3 hit) {
        if (face == null || face == Direction.DOWN) return false;
        BlockState state = level.getBlockState(pos);
        VoxelShape shape = state.getCollisionShape(level, pos);
        if (shape.isEmpty()) return false;
        AABB b = shape.bounds().move(pos);

        if (face == Direction.UP) {
            for (Direction d : Direction.Plane.HORIZONTAL) {
                if (edgeDistance(b, d, hit) <= EDGE_REACH && dropBeyondEdge(level, b, d, hit)) return true;
            }
            return false;
        }

        // ---- side faces ----
        double top = topAt(shape, pos, face, hit);
        if (hit.y >= top - GRIP_ZONE && hit.y <= top + 0.02 && fingerRoomAbove(level, face, hit, top)) {
            return true;
        }
        // outside corner pinch
        for (Direction s : new Direction[]{ face.getClockWise(), face.getCounterClockWise() }) {
            if (edgeDistance(b, s, hit) <= CORNER_REACH && roomAroundCorner(level, b, face, s, hit)) return true;
        }
        return false;
    }

    /** Highest point of the collision shape in a thin column right behind the hit point. */
    private static double topAt(VoxelShape shape, BlockPos pos, Direction face, Vec3 hit) {
        double px = hit.x - face.getStepX() * 0.05;
        double pz = hit.z - face.getStepZ() * 0.05;
        double best = Double.NEGATIVE_INFINITY;
        for (AABB a : shape.toAabbs()) {
            AABB w = a.move(pos);
            if (px >= w.minX - 0.01 && px <= w.maxX + 0.01 && pz >= w.minZ - 0.01 && pz <= w.maxZ + 0.01
                    && w.minY <= hit.y + 0.02) {
                best = Math.max(best, w.maxY);
            }
        }
        if (best == Double.NEGATIVE_INFINITY) best = shape.bounds().maxY + pos.getY();
        return best;
    }

    /** Free box over the top edge: in front of the face and 6 px deep over the top. */
    private static boolean fingerRoomAbove(Level level, Direction face, Vec3 hit, double top) {
        double out = 0.2, in = LEDGE_THRESHOLD, half = 0.2;
        boolean pos = face.getAxisDirection() == Direction.AxisDirection.POSITIVE;
        double plane = face.getAxis() == Direction.Axis.X ? hit.x : hit.z;
        // inward = opposite of the face normal
        double minA = pos ? plane - in : plane - out;
        double maxA = pos ? plane + out : plane + in;
        AABB box = face.getAxis() == Direction.Axis.X
                ? new AABB(minA, top + EPS, hit.z - half, maxA, top + LEDGE_THRESHOLD, hit.z + half)
                : new AABB(hit.x - half, top + EPS, minA, hit.x + half, top + LEDGE_THRESHOLD, maxA);
        return isFree(level, box);
    }

    /** Free box beyond a top edge, 6 px deep downwards. */
    private static boolean dropBeyondEdge(Level level, AABB b, Direction d, Vec3 hit) {
        double half = 0.2, w = 0.2;
        double top = b.maxY;
        AABB box = switch (d) {
            case EAST  -> new AABB(b.maxX + EPS, top - LEDGE_THRESHOLD, hit.z - half, b.maxX + w, top - EPS, hit.z + half);
            case WEST  -> new AABB(b.minX - w, top - LEDGE_THRESHOLD, hit.z - half, b.minX - EPS, top - EPS, hit.z + half);
            case SOUTH -> new AABB(hit.x - half, top - LEDGE_THRESHOLD, b.maxZ + EPS, hit.x + half, top - EPS, b.maxZ + w);
            default    -> new AABB(hit.x - half, top - LEDGE_THRESHOLD, b.minZ - w, hit.x + half, top - EPS, b.minZ - EPS);
        };
        return isFree(level, box);
    }

    /** Free space around a vertical edge so the hand can wrap the corner. */
    private static boolean roomAroundCorner(Level level, AABB b, Direction face, Direction side, Vec3 hit) {
        double w = 0.2, in = LEDGE_THRESHOLD, half = 0.2;
        double y0 = hit.y - half, y1 = hit.y + half;
        double edge = switch (side) {
            case EAST -> b.maxX; case WEST -> b.minX; case SOUTH -> b.maxZ; default -> b.minZ;
        };
        double s0 = side.getAxisDirection() == Direction.AxisDirection.POSITIVE ? edge + EPS : edge - w;
        double s1 = side.getAxisDirection() == Direction.AxisDirection.POSITIVE ? edge + w : edge - EPS;
        double plane = face.getAxis() == Direction.Axis.X ? hit.x : hit.z;
        double f0 = face.getAxisDirection() == Direction.AxisDirection.POSITIVE ? plane - in : plane;
        double f1 = face.getAxisDirection() == Direction.AxisDirection.POSITIVE ? plane : plane + in;
        AABB box = side.getAxis() == Direction.Axis.X
                ? new AABB(s0, y0, Math.min(f0, f1), s1, y1, Math.max(f0, f1))
                : new AABB(Math.min(f0, f1), y0, s0, Math.max(f0, f1), y1, s1);
        return isFree(level, box);
    }

    private static double edgeDistance(AABB b, Direction d, Vec3 hit) {
        return switch (d) {
            case EAST  -> b.maxX - hit.x;
            case WEST  -> hit.x - b.minX;
            case SOUTH -> b.maxZ - hit.z;
            case NORTH -> hit.z - b.minZ;
            default    -> Double.MAX_VALUE;
        };
    }

    /** True if no block collision box intersects the given world box. */
    public static boolean isFree(Level level, AABB box) {
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        int x0 = Mth.floor(box.minX), x1 = Mth.floor(box.maxX);
        int y0 = Mth.floor(box.minY), y1 = Mth.floor(box.maxY);
        int z0 = Mth.floor(box.minZ), z1 = Mth.floor(box.maxZ);
        for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) {
            mp.set(x, y, z);
            BlockState st = level.getBlockState(mp);
            if (st.isAir()) continue;
            VoxelShape sh = st.getCollisionShape(level, mp);
            if (sh.isEmpty()) continue;
            for (AABB a : sh.toAabbs()) if (a.move(mp).intersects(box)) return false;
        }
        return true;
    }
}
