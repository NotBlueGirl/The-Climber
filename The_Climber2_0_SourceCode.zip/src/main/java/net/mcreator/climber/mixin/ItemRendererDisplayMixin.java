package net.mcreator.climber.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.mcreator.climber.client.ItemDisplayOverrides;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.ForgeHooksClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Item display debug editor: when an override exists for the item and hand slot (first / third
 * person), it replaces the model's "display" transform.
 */
@Mixin(ItemRenderer.class)
public abstract class ItemRendererDisplayMixin {

    @Redirect(method = "render(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IILnet/minecraft/client/resources/model/BakedModel;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraftforge/client/ForgeHooksClient;handleCameraTransforms(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/resources/model/BakedModel;Lnet/minecraft/world/item/ItemDisplayContext;Z)Lnet/minecraft/client/resources/model/BakedModel;", remap = false),
            require = 0)
    private BakedModel climber$displayOverride(PoseStack ps, BakedModel model, ItemDisplayContext ctx, boolean leftHand,
                                               ItemStack stack, ItemDisplayContext ctx0, boolean left0, PoseStack ps0,
                                               MultiBufferSource buf, int light, int overlay, BakedModel model0) {
        ItemDisplayOverrides.Slot slot = ItemDisplayOverrides.Slot.of(ctx);
        if (slot != null && !stack.isEmpty()) {
            float[] v = ItemDisplayOverrides.get(stack.getItem(), slot);
            if (v != null) {
                ItemDisplayOverrides.toTransform(v).apply(leftHand, ps);
                return model;
            }
        }
        return ForgeHooksClient.handleCameraTransforms(ps, model, ctx, leftHand);
    }
}
