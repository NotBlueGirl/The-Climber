package net.mcreator.climber.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.mcreator.climber.client.ClientDoorAngles;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.model.data.ModelData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Двери с активным углом (т.е. схваченные/анимируемые прямо сейчас) больше НЕ рисуются
 * в статический меш чанка — их каждый кадр рисует
 * {@link net.mcreator.climber.client.renderer.DoorBlockEntityRenderer}.
 * <p>
 * ВАЖНО: у BlockRenderDispatcher.renderBatched есть ДВЕ перегрузки — ванильная
 * (7 параметров, без ModelData) и Forge-специфичная (9 параметров, с ModelData и
 * RenderType). Компиляция секции чанка (SectionCompiler/RebuildTask) в Forge реально
 * вызывает 9-параметровую перегрузку, чтобы прокинуть ModelData от BlockEntity.
 * Перехват только ванильной сигнатуры НЕ РАБОТАЕТ и приводит к тому, что статичная
 * дверь никогда не скрывается — отменяем обе перегрузки, чтобы не зависеть от того,
 * какая из них реально используется в текущей версии/сборке.
 */
@Mixin(BlockRenderDispatcher.class)
public abstract class BlockRenderDispatcherMixin {

    @Inject(method = "renderBatched(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/BlockAndTintGetter;Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;ZLnet/minecraft/util/RandomSource;)V",
            at = @At("HEAD"), cancellable = true, remap = true, require = 0)
    private void climber$hideAnimatedDoorFromChunkMeshVanilla(BlockState state, BlockPos pos, BlockAndTintGetter level,
                                                                PoseStack pose, VertexConsumer consumer,
                                                                boolean checkSides, RandomSource random,
                                                                CallbackInfo ci) {
        climber$maybeCancel(state, pos, level, ci);
    }

    @Inject(method = "renderBatched(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/BlockAndTintGetter;Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;ZLnet/minecraft/util/RandomSource;Lnet/minecraftforge/client/model/data/ModelData;Lnet/minecraft/client/renderer/RenderType;)V",
            at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void climber$hideAnimatedDoorFromChunkMeshForge(BlockState state, BlockPos pos, BlockAndTintGetter level,
                                                              PoseStack pose, VertexConsumer consumer,
                                                              boolean checkSides, RandomSource random,
                                                              ModelData modelData, RenderType renderType,
                                                              CallbackInfo ci) {
        climber$maybeCancel(state, pos, level, ci);
    }

    private void climber$maybeCancel(BlockState state, BlockPos pos, BlockAndTintGetter level, CallbackInfo ci) {
        if (!(state.getBlock() instanceof DoorBlock)) return;

        if (ClientDoorAngles.getFor(level, pos) != null) {
            ci.cancel();
        }
    }
}
