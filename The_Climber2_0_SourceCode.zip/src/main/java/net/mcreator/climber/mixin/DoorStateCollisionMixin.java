package net.mcreator.climber.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.phys.shapes.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Door dimensions/angles are live config, never the vanilla cached collision box. */
@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class DoorStateCollisionMixin {
  @Inject(
      method =
          "getCollisionShape(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/phys/shapes/VoxelShape;",
      at = @At("HEAD"),
      cancellable = true)
  private void climber$uncachedDoor(
      BlockGetter world, BlockPos pos, CallbackInfoReturnable<VoxelShape> cir) {
    var state = (BlockState) (Object) this;
    if (state.getBlock() instanceof DoorBlock && world instanceof Level)
      cir.setReturnValue(state.getCollisionShape(world, pos, CollisionContext.empty()));
  }

  @Inject(method = "hasLargeCollisionShape", at = @At("HEAD"), cancellable = true)
  private void climber$doorNeighbors(CallbackInfoReturnable<Boolean> cir) {
    if (((BlockState) (Object) this).getBlock() instanceof DoorBlock
        && net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics())
      cir.setReturnValue(true);
  }
}
