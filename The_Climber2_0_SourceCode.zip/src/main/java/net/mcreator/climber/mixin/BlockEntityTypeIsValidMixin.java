package net.mcreator.climber.mixin;

import net.mcreator.climber.init.ClimberModBlockEntities;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * BlockEntityType.Builder требует явный (непустой) список "валидных" блоков, но наш
 * door_animator должен быть валиден для ЛЮБОГО DoorBlock — включая двери из модов,
 * которых нет и не может быть в списке на момент регистрации.
 * <p>
 * Расширяем isValid: если это наш тип и state.getBlock() instanceof DoorBlock —
 * валиден всегда, независимо от исходного списка validBlocks.
 */
@Mixin(BlockEntityType.class)
public abstract class BlockEntityTypeIsValidMixin {

    @Inject(method = "isValid", at = @At("HEAD"), cancellable = true)
    private void climber$anyDoorIsValid(BlockState state, CallbackInfoReturnable<Boolean> cir) {
        if (!ClimberModBlockEntities.DOOR_ANIMATOR.isPresent()) return;

        BlockEntityType<?> self = (BlockEntityType<?>) (Object) this;
        if (self == ClimberModBlockEntities.DOOR_ANIMATOR.get() && state.getBlock() instanceof DoorBlock) {
            cir.setReturnValue(true);
        }
    }
}
