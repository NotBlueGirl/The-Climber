package net.mcreator.climber.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.mcreator.climber.client.animation.AnimationClient;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Pose the vanilla first-person hand mesh after vanilla resets its X angle. */
@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererAnimationMixin {
    @Redirect(method = "renderHand", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/model/geom/ModelPart;render(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;II)V"))
    private void climber$firstPerson(ModelPart part, PoseStack pose, VertexConsumer vertices, int light, int overlay,
                                    PoseStack handPose, MultiBufferSource buffers, int packedLight,
                                    AbstractClientPlayer player, ModelPart arm, ModelPart sleeve) {
        PlayerRenderer renderer = (PlayerRenderer)(Object)this;
        AnimationClient.firstPerson(player, renderer.getModel(), part, arm == renderer.getModel().rightArm);
        part.render(pose, vertices, light, overlay);
    }
}
