package net.mcreator.climber.mixin;

import net.mcreator.climber.blockentity.DoorBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.jetbrains.annotations.Nullable;

/**
 * Делает DoorBlock (любой — ванильный или из другого мода) реализующим EntityBlock,
 * чтобы у каждой двери был лёгкий маркерный BlockEntity. Сам блок-энтити почти ничего
 * не хранит и не тикает (см. DoorBlockEntity) — он нужен только чтобы движок вызывал
 * DoorBlockEntityRenderer каждый кадр для дверей, у которых сейчас идёт анимация.
 * <p>
 * Двери без активного угла по-прежнему рендерятся статично через chunk-меш
 * (см. BlockRenderDispatcherMixin) — BlockEntity на производительность обычных
 * закрытых/открытых дверей не влияет, т.к. рендерер для них ничего не рисует
 * и не тикает.
 */
@Mixin(DoorBlock.class)
@Implements(@Interface(iface = EntityBlock.class, prefix = "entityBlock$"))
public abstract class DoorEntityBlockMixin {

    @Unique
    @Nullable
    public BlockEntity entityBlock$newBlockEntity(BlockPos pos, BlockState state) {
        return new DoorBlockEntity(pos, state);
    }
}
