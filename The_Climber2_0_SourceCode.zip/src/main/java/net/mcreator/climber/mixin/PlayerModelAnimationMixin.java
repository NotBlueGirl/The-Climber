package net.mcreator.climber.mixin;

import net.mcreator.climber.client.animation.AnimationClient;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Standard and slim player rigs, including held-item and clothing layers. Client-only in mixin config. */
@Mixin(PlayerModel.class)
public abstract class PlayerModelAnimationMixin {
    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("HEAD"))
    private void climber$restore(LivingEntity entity, float walk, float amount, float age, float yaw, float pitch, CallbackInfo ci) {
        AnimationClient.restore((PlayerModel<?>)(Object)this);
    }
    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void climber$animate(LivingEntity entity, float walk, float amount, float age, float yaw, float pitch, CallbackInfo ci) {
        if (entity instanceof Player p) AnimationClient.apply(p, (PlayerModel<?>)(Object)this);
    }
}
