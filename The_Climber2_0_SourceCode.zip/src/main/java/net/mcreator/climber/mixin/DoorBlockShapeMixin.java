package net.mcreator.climber.mixin;

import net.mcreator.climber.door.DoorClientHooks;
import net.mcreator.climber.door.DoorGeometry;
import net.mcreator.climber.door.DoorStateManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(DoorBlock.class)
public abstract class DoorBlockShapeMixin {

  /** Аутлайн + кликабельная форма (метод объявлен в DoorBlock) */
  @Inject(method = "getShape", at = @At("RETURN"), cancellable = true)
  private void climber$rotatedShape(
      BlockState state,
      BlockGetter level,
      BlockPos pos,
      CollisionContext ctx,
      CallbackInfoReturnable<VoxelShape> cir) {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()) return;
    if (!(level instanceof Level l)) return;

    BlockPos lower = state.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? pos.below() : pos;
    BlockState lowerState = l.getBlockState(lower);

    if (!(lowerState.getBlock() instanceof DoorBlock)) return;

    Float angle;

    if (l.isClientSide()) {
      angle = DoorClientHooks.clientAngle(l, lower);
    } else if (l instanceof ServerLevel sl) {
      var rs = DoorStateManager.get(sl).get(lower);
      angle = rs == null ? null : rs.angleDeg;
    } else {
      return;
    }

    if (angle == null)
      angle =
          lowerState.getValue(DoorBlock.OPEN)
              ? DoorGeometry.vanillaOpenAngle(
                  lowerState.getValue(DoorBlock.HINGE) == DoorHingeSide.RIGHT)
              : 0f;

    cir.setReturnValue(
        DoorGeometry.rotatedShape(
            lower,
            lowerState.getValue(DoorBlock.FACING),
            lowerState.getValue(DoorBlock.HINGE) == DoorHingeSide.RIGHT,
            angle,
            pos.getY() - lower.getY()));
  }
}
