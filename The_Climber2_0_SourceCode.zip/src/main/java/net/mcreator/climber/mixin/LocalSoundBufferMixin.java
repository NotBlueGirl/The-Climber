package net.mcreator.climber.mixin;

import com.mojang.blaze3d.audio.SoundBuffer;
import java.util.*;
import java.util.concurrent.*;
import net.mcreator.climber.client.ClimberSoundPreloader;
import net.minecraft.client.sounds.SoundBufferLibrary;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Uses vanilla cache/cleanup lifecycle, but reads only locally selected files. */
@Mixin(SoundBufferLibrary.class)
public class LocalSoundBufferMixin {
  @Shadow @Final private Map<ResourceLocation, CompletableFuture<SoundBuffer>> cache;

  @Inject(method = "getCompleteBuffer", at = @At("HEAD"), cancellable = true)
  private void climber$localBuffer(
      ResourceLocation id, CallbackInfoReturnable<CompletableFuture<SoundBuffer>> cir) {
    if (ClimberSoundPreloader.handles(id))
      cir.setReturnValue(cache.computeIfAbsent(id, ClimberSoundPreloader::decode));
  }
}
