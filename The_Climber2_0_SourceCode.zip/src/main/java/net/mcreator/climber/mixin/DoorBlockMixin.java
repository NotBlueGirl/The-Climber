package net.mcreator.climber.mixin;

import net.mcreator.climber.door.DoorClientHooks;
import net.mcreator.climber.door.DoorGrabManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(DoorBlock.class)
public abstract class DoorBlockMixin {

  /** RMB on a wooden door = grab & drag it. Shift+RMB = vanilla toggle. Iron doors stay vanilla. */
  @Inject(method = "use", at = @At("HEAD"), cancellable = true)
  private void climber$onUse(
      BlockState state,
      Level level,
      BlockPos pos,
      Player player,
      InteractionHand hand,
      BlockHitResult hit,
      CallbackInfoReturnable<InteractionResult> cir) {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()) return;
    if (player.isShiftKeyDown()) return;
    if (!DoorGrabManager.canOpenByHand(state)) return;

    if (level.isClientSide()) {
      DoorClientHooks.grabPress.accept(pos, hit.getLocation());
    } else if (player instanceof ServerPlayer sp) {
      DoorGrabManager.start(sp, pos, hit.getLocation());
    }
    cir.setReturnValue(InteractionResult.sidedSuccess(level.isClientSide()));
  }

  /** Shift+RMB vanilla toggle -> animate the physics door to the new vanilla pose. */
  @Inject(method = "use", at = @At("RETURN"))
  private void climber$afterUse(
      BlockState state,
      Level level,
      BlockPos pos,
      Player player,
      InteractionHand hand,
      BlockHitResult hit,
      CallbackInfoReturnable<InteractionResult> cir) {
    if (!level.isClientSide()) DoorGrabManager.onVanillaStateChanged(level, pos);
  }

  /** Villagers, raids, other mods. */
  @Inject(method = "setOpen", at = @At("RETURN"))
  private void climber$afterSetOpen(
      Entity entity, Level level, BlockState state, BlockPos pos, boolean open, CallbackInfo ci) {
    if (!level.isClientSide()) DoorGrabManager.onVanillaStateChanged(level, pos);
  }

  /** Redstone. */
  @Inject(method = "neighborChanged", at = @At("RETURN"))
  private void climber$afterNeighborChanged(
      BlockState state,
      Level level,
      BlockPos pos,
      Block block,
      BlockPos fromPos,
      boolean isMoving,
      CallbackInfo ci) {
    if (!level.isClientSide()) DoorGrabManager.onVanillaStateChanged(level, pos);
  }
}
