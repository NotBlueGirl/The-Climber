package net.mcreator.climber.config;

import com.google.gson.JsonObject;
import java.util.*;
import net.minecraft.nbt.CompoundTag;

/** Server-authoritative, synchronized gameplay controls. Dimensions are door-local blocks. */
public final class GameplaySettings {
  public record Option(String key, double initial, double min, double max, String unit) {}

  public static final List<Option> OPTIONS =
      List.of(
          new Option("RebarKnockback", 3, 0, 32, "blocks"),
          new Option("MaxTimeCrackLight", 78, .05, 36000, "seconds"),
          new Option("ClickCrankRegen", 10, 0, 36000, "seconds / crank"),
          new Option("ClimberGravity", 1, 0, 10, "multiplier"),
          new Option("RopeSwingStrenght", 1, 0, 10, "multiplier"),
          new Option("DoorHitboxX", 1, .0625, 2, "width blocks"),
          new Option("DoorHitboxY", 2, .125, 3, "height blocks"),
          new Option("DoorHitboxZ", .1875, .03125, 2, "depth blocks"),
          new Option("DoorHitboxPosX", 0, -.5, .5, "local width offset blocks"),
          new Option("DoorHitboxPosY", 0, -.5, .5, "vertical offset blocks"),
          new Option("DoorHitboxPosZ", 0, -.5, .5, "local depth offset blocks"));
  private final Map<String, Double> values = new LinkedHashMap<>();
  private boolean doorPhysics = true;

  public GameplaySettings() {
    reset();
  }

  public void reset() {
    values.clear();
    OPTIONS.forEach(o -> values.put(o.key, o.initial));
    doorPhysics = true;
  }

  public double number(String key) {
    var v = values.get(key);
    if (v == null) throw new IllegalArgumentException("Unknown gameplay setting: " + key);
    return v;
  }

  public boolean doorPhysics() {
    return doorPhysics;
  }

  public static void validate(CompoundTag t) {
    if (t.contains("DoorPhysics")
        && (!t.contains("DoorPhysics", 1)
            || (t.getByte("DoorPhysics") != 0 && t.getByte("DoorPhysics") != 1)))
      throw new IllegalArgumentException("DoorPhysics must be boolean");
    for (var o : OPTIONS)
      if (t.contains(o.key)) {
        if (!t.contains(o.key, 99)) throw new IllegalArgumentException(o.key + " must be numeric");
        double v = t.getDouble(o.key);
        if (!Double.isFinite(v) || v < o.min || v > o.max)
          throw new IllegalArgumentException(
              o.key + " must be " + o.min + ".." + o.max + " " + o.unit);
      }
  }

  public void read(CompoundTag t) {
    validate(t);
    for (var o : OPTIONS) if (t.contains(o.key)) values.put(o.key, t.getDouble(o.key));
    if (t.contains("DoorPhysics")) doorPhysics = t.getBoolean("DoorPhysics");
  }

  public void write(CompoundTag t) {
    values.forEach(t::putDouble);
    t.putBoolean("DoorPhysics", doorPhysics);
  }

  public void json(JsonObject t) {
    values.forEach(t::addProperty);
    t.addProperty("DoorPhysics", doorPhysics);
  }

  public void load(JsonObject t) {
    CompoundTag tag = new CompoundTag();
    for (var o : OPTIONS) if (t.has(o.key)) tag.putDouble(o.key, t.get(o.key).getAsDouble());
    if (t.has("DoorPhysics")) tag.putBoolean("DoorPhysics", t.get("DoorPhysics").getAsBoolean());
    read(tag);
  }
}
