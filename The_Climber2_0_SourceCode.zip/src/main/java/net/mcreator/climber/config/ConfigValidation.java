package net.mcreator.climber.config;

import java.nio.file.*;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

/** Shared validation for the settings screen and its authoritative server update. */
public final class ConfigValidation {
  private ConfigValidation() {}

  public static final String[] NUMBERS = {
    "staminaMax",
    "staminaDrainRate",
    "staminaRegenRate",
    "strengthJumpBothHands",
    "strengthJumpOneHand"
  };

  public static boolean filePath(String s) {
    return s.contains("\\")
        || s.startsWith("/")
        || s.startsWith("./")
        || s.startsWith("../")
        || s.length() > 1 && s.charAt(1) == ':';
  }

  public static List<String> blockIds(String text) {
    if (text.length() > 32767) throw new IllegalArgumentException("Block list is too long");
    TreeSet<String> ids = new TreeSet<>();
    for (String token : text.split("[,;\\s]+"))
      if (!token.isBlank()) {
        if (token.length() > 256
            || ResourceLocation.tryParse(token) == null
            || !token.contains(":"))
          throw new IllegalArgumentException("Block ID must be namespace:block: " + token);
        ids.add(token);
      }
    if (ids.size() > 512) throw new IllegalArgumentException("Use at most 512 block IDs per list");
    return new ArrayList<>(ids);
  }

  public static ListTag list(Collection<String> ids) {
    ListTag t = new ListTag();
    ids.stream().sorted().forEach(s -> t.add(StringTag.valueOf(s)));
    return t;
  }

  public static String listText(CompoundTag t, String key) {
    ListTag list = t.getList(key, Tag.TAG_STRING);
    List<String> ids = new ArrayList<>();
    for (int i = 0; i < list.size(); i++) ids.add(list.getString(i));
    return String.join(", ", ids);
  }

  public static void validate(CompoundTag t, boolean serverFiles) {
    GameplaySettings.validate(t);
    for (String k : NUMBERS)
      if (t.contains(k)) {
        double v = t.getDouble(k);
        if (!Double.isFinite(v) || v < (k.equals("staminaMax") ? 1 : 0) || v > Float.MAX_VALUE)
          throw new IllegalArgumentException("Invalid number: " + k);
        if (k.equals("staminaMax") && (v != Math.rint(v) || v > Integer.MAX_VALUE))
          throw new IllegalArgumentException("Max stamina must be a positive integer");
      }
    for (String k : new String[] {"idleHandX", "idleHandY", "idleHandZ"})
      if (t.contains(k)
          && (!Double.isFinite(t.getDouble(k)) || Math.abs(t.getDouble(k)) > Float.MAX_VALUE))
        throw new IllegalArgumentException("Hand position must be finite");
    for (String key : new String[] {"includeList", "excludeList"})
      if (t.contains(key)) {
        List<String> ids = blockIds(listText(t, key));
        if (serverFiles)
          for (String id : ids)
            if (!ForgeRegistries.BLOCKS.containsKey(new ResourceLocation(id)))
              throw new IllegalArgumentException("Unknown block: " + id);
      }
    for (String key : new String[] {"grabHitSound", "grabJumpSound"})
      if (t.contains(key)) {
        String sound = t.getString(key).trim();
        if (sound.isEmpty()) continue;
        if (sound.length() > 1024) throw new IllegalArgumentException("Sound path too long");
        if (filePath(sound)) {
          String lower = sound.toLowerCase(Locale.ROOT);
          if (!(lower.endsWith(".ogg") || lower.endsWith(".wav") || lower.endsWith(".mp3")))
            throw new IllegalArgumentException("Sound file must be .ogg, .wav or .mp3");
          if (serverFiles && !Files.isRegularFile(Path.of(sound)))
            throw new IllegalArgumentException("Sound file is not on server: " + sound);
        } else {
          ResourceLocation id = ResourceLocation.tryParse(sound);
          if (id == null || !sound.contains(":"))
            throw new IllegalArgumentException("Sound must be namespace:sound or a file path");
          if (serverFiles && !ForgeRegistries.SOUND_EVENTS.containsKey(id))
            throw new IllegalArgumentException("Unknown sound: " + sound);
        }
      }
  }
}
