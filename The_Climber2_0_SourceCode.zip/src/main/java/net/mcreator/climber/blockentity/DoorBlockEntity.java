package net.mcreator.climber.blockentity;

import net.mcreator.climber.init.ClimberModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Empty marker block entity attached (through a mixin) to every door so that
 * {@link net.mcreator.climber.client.renderer.DoorBlockEntityRenderer} can draw
 * physics doors every frame. It stores nothing.
 */
public class DoorBlockEntity extends BlockEntity {
    public DoorBlockEntity(BlockPos pos, BlockState state) {
        super(ClimberModBlockEntities.DOOR_ANIMATOR.get(), pos, state);
    }

    /** A swung door reaches into neighbouring blocks: don't frustum-cull it too early. */
    @Override
    public AABB getRenderBoundingBox() {
        BlockPos p = getBlockPos();
        return new AABB(p).inflate(1.0, 0.0, 1.0);
    }
}
