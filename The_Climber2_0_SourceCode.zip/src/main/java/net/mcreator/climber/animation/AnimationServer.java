package net.mcreator.climber.animation;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.network.AnimationRequestPacket;
import net.mcreator.climber.network.AnimationSyncPacket;
import net.mcreator.climber.network.ConfigUpdatePacket;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Server owns definitions, permission checks, held-item filters and playback clocks. No client render code. */
public final class AnimationServer {
    private static final Map<String, RigAnimation> CLIPS = new TreeMap<>();
    private record Playing(String id, long started) {}
    private static final Map<UUID, Playing> ACTIVE = new HashMap<>();
    private static final Map<UUID, Map<String, Long>> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Long> INPUT_TIME = new HashMap<>(), EDIT_TIME = new HashMap<>();
    private static Path folder() { return FMLPaths.CONFIGDIR.get().resolve("climber_animations"); }
    private static long now(ServerPlayer p) { return p.server.overworld().getGameTime(); }
    private static void send(ServerPlayer p, AnimationSyncPacket packet) { ClimberMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> p), packet); }
    private static void all(AnimationSyncPacket packet) { ClimberMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), packet); }
    private static void message(ServerPlayer p, String text) { send(p, AnimationSyncPacket.text(AnimationSyncPacket.MESSAGE, text)); p.sendSystemMessage(Component.literal("[Animation] " + text)); }
    private static void validateItem(RigAnimation a) {
        if (!a.item.equals("*") && !ForgeRegistries.ITEMS.containsKey(new ResourceLocation(a.item))) throw new IllegalArgumentException("Unknown item: " + a.item);
    }
    public static boolean matches(RigAnimation a, ServerPlayer p) {
        if (a.item.equals("*")) return true;
        boolean main = id(p.getMainHandItem()).equals(a.item), off = id(p.getOffhandItem()).equals(a.item);
        return switch (a.hand) { case MAIN_HAND -> main; case OFF_HAND -> off; case EITHER -> main || off; };
    }
    private static String id(ItemStack s) { return String.valueOf(ForgeRegistries.ITEMS.getKey(s.getItem())); }
    private static void syncLibrary(ServerPlayer p) {
        send(p, AnimationSyncPacket.text(AnimationSyncPacket.RESET, ""));
        CLIPS.values().forEach(a -> send(p, AnimationSyncPacket.text(AnimationSyncPacket.DEFINITION, a.toJson())));
        long n = now(p);
        ACTIVE.forEach((uuid, playing) -> send(p, new AnimationSyncPacket(AnimationSyncPacket.PLAY, uuid, playing.id, Math.max(0, n - playing.started))));
    }
    private static int reload(MinecraftServer server) {
        CLIPS.clear(); ACTIVE.clear(); COOLDOWNS.clear(); INPUT_TIME.clear(); EDIT_TIME.clear();
        try {
            Files.createDirectories(folder());
            try (var files = Files.list(folder())) {
                for (Path path : files.filter(p -> p.getFileName().toString().endsWith(".json")).sorted().limit(RigAnimation.MAX_CLIPS).toList()) {
                    try {
                        if (Files.size(path) > RigAnimation.MAX_JSON * 3L) throw new IllegalArgumentException("File too large");
                        RigAnimation a = RigAnimation.fromJson(Files.readString(path)); validateItem(a);
                        if (CLIPS.containsKey(a.id)) throw new IllegalArgumentException("Duplicate animation ID");
                        CLIPS.put(a.id, a);
                    } catch (Exception e) { ClimberMod.LOGGER.warn("[Animation] Skipped {}: {}", path.getFileName(), e.getMessage()); }
                }
            }
        } catch (Exception e) { ClimberMod.LOGGER.error("[Animation] Load failed", e); }
        server.getPlayerList().getPlayers().forEach(AnimationServer::syncLibrary); return CLIPS.size();
    }
    @SubscribeEvent public void started(ServerStartedEvent e) { reload(e.getServer()); }
    @SubscribeEvent public void stopped(ServerStoppedEvent e) { CLIPS.clear(); ACTIVE.clear(); COOLDOWNS.clear(); INPUT_TIME.clear(); EDIT_TIME.clear(); }
    @SubscribeEvent public void login(PlayerEvent.PlayerLoggedInEvent e) { if (e.getEntity() instanceof ServerPlayer p) syncLibrary(p); }
    @SubscribeEvent public void logout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { stop(p); COOLDOWNS.remove(p.getUUID()); INPUT_TIME.remove(p.getUUID()); EDIT_TIME.remove(p.getUUID()); }
    }
    @SubscribeEvent public void respawn(PlayerEvent.PlayerRespawnEvent e) { if (e.getEntity() instanceof ServerPlayer p) { stop(p); syncLibrary(p); } }
    @SubscribeEvent public void dimension(PlayerEvent.PlayerChangedDimensionEvent e) { if (e.getEntity() instanceof ServerPlayer p) { stop(p); syncLibrary(p); } }
    @SubscribeEvent public void jump(LivingEvent.LivingJumpEvent e) { if (e.getEntity() instanceof ServerPlayer p) trigger(p, RigAnimation.Trigger.Jump, -1, null); }
    @SubscribeEvent public void attack(AttackEntityEvent e) { if (e.getEntity() instanceof ServerPlayer p) trigger(p, RigAnimation.Trigger.AttackEntity, -1, InteractionHand.MAIN_HAND); }
    @SubscribeEvent public void use(LivingEntityUseItemEvent.Start e) { if (e.getEntity() instanceof ServerPlayer p) trigger(p, RigAnimation.Trigger.ItemUseStart, -1, e.getItem() == p.getOffhandItem() ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND); }
    @SubscribeEvent public void rightClickItem(PlayerInteractEvent.RightClickItem e) {
        if (e.getEntity() instanceof ServerPlayer p) trigger(p, RigAnimation.Trigger.ItemRightClicked, -1, e.getHand());
    }
    @SubscribeEvent public void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("climbanim")
            .then(Commands.literal("reload").requires(s -> s.hasPermission(2)).executes(c -> {
                int n = reload(c.getSource().getServer()); c.getSource().sendSuccess(() -> Component.literal("Loaded " + n + " animations."), false); return n;
            }))
            .then(Commands.literal("list").executes(c -> { c.getSource().sendSuccess(() -> Component.literal("Animations: " + String.join(", ", CLIPS.keySet())), false); return CLIPS.size(); }))
            .then(Commands.literal("stop").executes(c -> { stop(c.getSource().getPlayerOrException()); return 1; }))
            .then(Commands.literal("play").requires(s -> s.hasPermission(2)).then(Commands.argument("id", StringArgumentType.word()).executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException(); RigAnimation a = CLIPS.get(StringArgumentType.getString(c, "id"));
                if (a == null) { message(p, "Unknown animation ID"); return 0; } return play(p, a, true) ? 1 : 0;
            }))));
    }
    public static void request(ServerPlayer p, AnimationRequestPacket m) {
        if (m.action() == AnimationRequestPacket.STOP) { stop(p); return; }
        if (m.action() == AnimationRequestPacket.RELEASE) { release(p, m.text(), m.key()); return; }
        if (m.action() == AnimationRequestPacket.INPUT) {
            // Clients cannot forge server-side Jump / Attack / Use events or address another player.
            RigAnimation.Trigger t;
            try { t = RigAnimation.Trigger.valueOf(m.text()); } catch (Exception e) { return; }
            if (t != RigAnimation.Trigger.Mouse1Clicked && t != RigAnimation.Trigger.Mouse2Clicked && t != RigAnimation.Trigger.KeyClicked && t != RigAnimation.Trigger.KeyReleased) return;
            long n = now(p); if (n - INPUT_TIME.getOrDefault(p.getUUID(), Long.MIN_VALUE / 2) < 2) return;
            INPUT_TIME.put(p.getUUID(), n); trigger(p, t, m.key(), null); return;
        }
        if (m.action() != AnimationRequestPacket.PUBLISH && m.action() != AnimationRequestPacket.PLAY) return;
        if (!ConfigUpdatePacket.canEdit(p)) { message(p, "Only an operator / single-player host may publish or force-play animations."); return; }
        long n = now(p); if (n - EDIT_TIME.getOrDefault(p.getUUID(), Long.MIN_VALUE / 2) < 10) return;
        EDIT_TIME.put(p.getUUID(), n);
        if (m.action() == AnimationRequestPacket.PLAY) {
            RigAnimation a = CLIPS.get(m.text());
            if (a == null) message(p, "Publish this clip first (or reload it on the server).");
            else if (!play(p, a, true)) message(p, "Animation needs its linked item; cannot play while dead or spectating.");
            return;
        }
        try {
            RigAnimation a = RigAnimation.fromJson(m.text()); validateItem(a);
            if (!CLIPS.containsKey(a.id) && CLIPS.size() >= RigAnimation.MAX_CLIPS) throw new IllegalArgumentException("Server animation library is full (64)");
            Files.createDirectories(folder()); Path target = folder().resolve(a.id + ".json");
            Path temp = Files.createTempFile(folder(), "clip-", ".tmp");
            try {
                Files.writeString(temp, a.toJson(), StandardCharsets.UTF_8);
                try { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (AtomicMoveNotSupportedException ex) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
            } finally { Files.deleteIfExists(temp); }
            // Stop an old revision before replacing its shared definition.
            p.server.getPlayerList().getPlayers().stream().filter(sp -> { Playing q = ACTIVE.get(sp.getUUID()); return q != null && q.id.equals(a.id); }).forEach(AnimationServer::stop);
            CLIPS.put(a.id, a); all(AnimationSyncPacket.text(AnimationSyncPacket.DEFINITION, a.toJson())); message(p, "Published: " + a.id);
        } catch (Exception e) { message(p, "Publish rejected: " + e.getMessage()); }
    }
    private static void release(ServerPlayer p, String event, int key) {
        Playing playing = ACTIVE.get(p.getUUID()); if (playing == null) return;
        RigAnimation a = CLIPS.get(playing.id); if (a == null || !a.stopOnRelease) return;
        boolean mouse = (a.event == RigAnimation.Trigger.Mouse1Clicked && event.equals("Mouse1Clicked")) || (a.event == RigAnimation.Trigger.Mouse2Clicked && event.equals("Mouse2Clicked"));
        boolean keyboard = a.event == RigAnimation.Trigger.KeyClicked && event.equals("KeyClicked") && key == a.keyCode;
        if (mouse || keyboard) stop(p);
    }
    private static void trigger(ServerPlayer p, RigAnimation.Trigger event, int key, InteractionHand usedHand) {
        for (RigAnimation a : CLIPS.values()) {
            if (a.event != event || ((event == RigAnimation.Trigger.KeyClicked || event == RigAnimation.Trigger.KeyReleased) && a.keyCode != key)) continue;
            if (usedHand != null && a.hand != RigAnimation.Hand.EITHER && !a.hand.name().equals(usedHand.name())) continue;
            if (usedHand != null && !a.item.equals("*") && !id(p.getItemInHand(usedHand)).equals(a.item)) continue;
            if (play(p, a, false)) return; // deterministic, one active full-body clip per player
        }
    }
    private static boolean play(ServerPlayer p, RigAnimation a, boolean force) {
        if (!p.isAlive() || p.isSpectator() || !matches(a, p)) return false;
        long n = now(p); Map<String, Long> cd = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new HashMap<>());
        if (!force && n < cd.getOrDefault(a.id, Long.MIN_VALUE)) return false;
        Playing old = ACTIVE.get(p.getUUID()); if (!force && old != null && old.id.equals(a.id) && a.loop) return false;
        cd.put(a.id, n + Math.max(a.cooldownTicks, a.loop ? 1 : a.durationTicks));
        ACTIVE.put(p.getUUID(), new Playing(a.id, n)); all(new AnimationSyncPacket(AnimationSyncPacket.PLAY, p.getUUID(), a.id, 0)); return true;
    }
    private static void stop(ServerPlayer p) { if (ACTIVE.remove(p.getUUID()) != null) all(new AnimationSyncPacket(AnimationSyncPacket.STOP, p.getUUID(), "", 0)); }
    @SubscribeEvent public void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        Playing q = ACTIVE.get(p.getUUID()); if (q == null) return; RigAnimation a = CLIPS.get(q.id);
        if (a == null || !p.isAlive() || p.isSpectator() || !matches(a, p) || (!a.loop && now(p) - q.started >= a.durationTicks)) stop(p);
    }
}
