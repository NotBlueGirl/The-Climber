package net.mcreator.climber.animation;

import com.google.gson.*;
import java.util.*;

/** Bounded, side-neutral animation format. Degrees; pivot offsets in Minecraft model pixels. */
public final class RigAnimation {
    public static final int FORMAT = 1, MAX_JSON = 65536, MAX_FRAMES = 64, MAX_CLIPS = 64;
    public static final String[] BONES = { "head", "body", "right_arm", "left_arm", "right_leg", "left_leg" };
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public enum Trigger { Manual, Mouse1Clicked, Mouse2Clicked, KeyClicked, KeyReleased, Jump, AttackEntity, ItemUseStart, ItemRightClicked }
    public enum Hand { MAIN_HAND, OFF_HAND, EITHER }
    public String id = "new_animation";
    public int durationTicks = 20, cooldownTicks = 20, keyCode = 82;
    public boolean loop = false, additive = true, stopOnRelease = false;
    public Trigger event = Trigger.Manual;
    public Hand hand = Hand.MAIN_HAND;
    public String item = "*";
    /** Sparse bone tracks. Every array: rotX, rotY, rotZ, offsetX, offsetY, offsetZ. */
    public final NavigableMap<Integer, Map<String, float[]>> frames = new TreeMap<>();

    public static RigAnimation blank() {
        RigAnimation a = new RigAnimation();
        a.frames.put(0, new LinkedHashMap<>()); a.frames.put(20, new LinkedHashMap<>());
        return a;
    }
    public static boolean validId(String id) { return id != null && id.matches("[a-z0-9_]{1,48}"); }
    public RigAnimation copy() { return fromJson(toJson()); }
    public static boolean bone(String b) { return Arrays.asList(BONES).contains(b); }
    public float[] sample(String bone, float tick) {
        Map.Entry<Integer, float[]> before = null, after = null;
        for (var e : frames.entrySet()) {
            float[] v = e.getValue().get(bone); if (v == null) continue;
            if (e.getKey() <= tick) before = Map.entry(e.getKey(), v);
            if (e.getKey() >= tick) { after = Map.entry(e.getKey(), v); break; }
        }
        if (before == null && after == null) return null; // leave unkeyed vanilla bones alone
        if (before == null) return after.getValue().clone();
        if (after == null) return before.getValue().clone();
        float f = before.getKey().equals(after.getKey()) ? 0f : (tick - before.getKey()) / (after.getKey() - before.getKey());
        float[] v = new float[6];
        // Deliberately linear, unwrapped Euler interpolation: supports intentional full turns.
        for (int i = 0; i < 6; i++) v[i] = before.getValue()[i] + (after.getValue()[i] - before.getValue()[i]) * f;
        return v;
    }
    public Map<String, float[]> pose(float tick) {
        Map<String, float[]> p = new LinkedHashMap<>();
        for (String b : BONES) { float[] v = sample(b, tick); if (v != null) p.put(b, v); }
        return p;
    }
    public String toJson() {
        JsonObject o = new JsonObject(); o.addProperty("format_version", FORMAT); o.addProperty("id", id);
        o.addProperty("rig", "minecraft_player_6_bone"); o.addProperty("duration_ticks", durationTicks);
        o.addProperty("loop", loop); o.addProperty("mode", additive ? "additive" : "replace");
        JsonObject b = new JsonObject(); b.addProperty("event", event.name()); b.addProperty("key_code", keyCode);
        b.addProperty("item", item); b.addProperty("hand", hand.name()); b.addProperty("cooldown_ticks", cooldownTicks);
        b.addProperty("stop_on_release", stopOnRelease); o.add("binding", b);
        JsonArray fs = new JsonArray();
        for (var e : frames.entrySet()) {
            JsonObject f = new JsonObject(); f.addProperty("tick", e.getKey()); JsonObject bones = new JsonObject();
            for (var p : e.getValue().entrySet()) {
                JsonObject t = new JsonObject(); JsonArray rot = new JsonArray(), pos = new JsonArray();
                for (int i = 0; i < 3; i++) { rot.add(p.getValue()[i]); pos.add(p.getValue()[i + 3]); }
                t.add("rotation", rot); t.add("position", pos); bones.add(p.getKey(), t);
            }
            f.add("bones", bones); fs.add(f);
        }
        o.add("keyframes", fs); return GSON.toJson(o);
    }
    private static void require(boolean ok, String message) { if (!ok) throw new IllegalArgumentException(message); }
    private static int integer(JsonObject o, String key, int min, int max) {
        double d = o.get(key).getAsDouble(); require(Double.isFinite(d) && d == Math.rint(d) && d >= min && d <= max, "Invalid " + key); return (int) d;
    }
    public static RigAnimation fromJson(String text) {
        require(text != null && text.length() <= MAX_JSON, "Animation JSON too large");
        try {
            JsonObject o = JsonParser.parseString(text).getAsJsonObject(); RigAnimation a = new RigAnimation();
            require(integer(o, "format_version", 1, 1) == FORMAT, "Unsupported animation version");
            require("minecraft_player_6_bone".equals(o.get("rig").getAsString()), "Unsupported player rig");
            a.id = o.get("id").getAsString(); require(validId(a.id), "ID: use 1-48 lowercase letters, digits or underscores");
            a.durationTicks = integer(o, "duration_ticks", 1, 1200); a.loop = o.get("loop").getAsBoolean();
            String mode = o.get("mode").getAsString(); require(mode.equals("additive") || mode.equals("replace"), "Invalid mode"); a.additive = mode.equals("additive");
            JsonObject b = o.getAsJsonObject("binding"); a.event = Trigger.valueOf(b.get("event").getAsString());
            a.keyCode = integer(b, "key_code", 32, 348); a.cooldownTicks = integer(b, "cooldown_ticks", 1, 12000);
            a.hand = Hand.valueOf(b.get("hand").getAsString()); a.item = b.get("item").getAsString();
            require(a.item.equals("*") || a.item.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"), "Item must be * or namespace:item");
            require(a.item.length() <= 128, "Item ID too long"); a.stopOnRelease = b.has("stop_on_release") && b.get("stop_on_release").getAsBoolean();
            JsonArray fs = o.getAsJsonArray("keyframes"); require(fs.size() > 0 && fs.size() <= MAX_FRAMES, "Use 1-64 keyframes");
            for (JsonElement fe : fs) {
                JsonObject f = fe.getAsJsonObject(); int tick = integer(f, "tick", 0, a.durationTicks);
                require(!a.frames.containsKey(tick), "Duplicate keyframe tick"); Map<String, float[]> p = new LinkedHashMap<>();
                JsonObject bones = f.getAsJsonObject("bones"); require(bones.size() <= BONES.length, "Too many bones");
                for (var be : bones.entrySet()) {
                    require(bone(be.getKey()), "Unknown bone: " + be.getKey()); JsonObject t = be.getValue().getAsJsonObject();
                    JsonArray rot = t.getAsJsonArray("rotation"), pos = t.getAsJsonArray("position");
                    require(rot.size() == 3 && pos.size() == 3, "Each transform needs rotation[3] and position[3]");
                    float[] v = new float[6];
                    for (int i = 0; i < 6; i++) {
                        v[i] = (i < 3 ? rot : pos).get(i % 3).getAsFloat();
                        require(Float.isFinite(v[i]) && Math.abs(v[i]) <= (i < 3 ? 720 : 32), "Transform out of bounds");
                    }
                    p.put(be.getKey(), v);
                }
                a.frames.put(tick, p);
            }
            return a;
        } catch (IllegalArgumentException e) { throw e; }
        catch (RuntimeException e) { throw new IllegalArgumentException("Malformed animation JSON", e); }
    }
}
