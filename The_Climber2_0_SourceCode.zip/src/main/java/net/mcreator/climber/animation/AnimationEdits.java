package net.mcreator.climber.animation;
import java.util.*;

/** Side-neutral editing operations, also used by the smoke tests. */
public final class AnimationEdits {
    private AnimationEdits() {}
    public static RigAnimation copy(RigAnimation a) {
        RigAnimation b=new RigAnimation();b.id=a.id;b.durationTicks=a.durationTicks;b.cooldownTicks=a.cooldownTicks;b.keyCode=a.keyCode;b.loop=a.loop;b.additive=a.additive;b.stopOnRelease=a.stopOnRelease;b.event=a.event;b.hand=a.hand;b.item=a.item;
        a.frames.forEach((t,p)->b.frames.put(t,copyPose(p)));return b;
    }
    public static Map<String,float[]> copyPose(Map<String,float[]> p){Map<String,float[]> c=new LinkedHashMap<>();p.forEach((b,v)->c.put(b,v.clone()));return c;}
    public static Map<String,float[]> fullPose(RigAnimation a,float tick){var p=a.pose(tick);for(String b:RigAnimation.BONES)p.putIfAbsent(b,new float[6]);return p;}
    public static Map<String,float[]> mirror(Map<String,float[]> p){Map<String,float[]> out=new LinkedHashMap<>();p.forEach((b,v)->{String dest=b.startsWith("right_")?"left_"+b.substring(6):b.startsWith("left_")?"right_"+b.substring(5):b;float[] n=v.clone();n[1]=-n[1];n[2]=-n[2];n[3]=-n[3];out.put(dest,n);});return out;}
    public static void paste(RigAnimation a,int tick,Map<String,float[]> p){if(tick<0||tick>a.durationTicks)throw new IllegalArgumentException("Tick is outside the clip");if(!a.frames.containsKey(tick)&&a.frames.size()>=RigAnimation.MAX_FRAMES)throw new IllegalArgumentException("Maximum 64 keyframes");a.frames.put(tick,copyPose(p));}
    public static void move(RigAnimation a,int from,int to){if(!a.frames.containsKey(from))throw new IllegalArgumentException("Select an existing keyframe");if(to<0||to>a.durationTicks)throw new IllegalArgumentException("Target tick is outside the clip");if(from==to)return;if(a.frames.containsKey(to))throw new IllegalArgumentException("A keyframe already exists at the target tick");a.frames.put(to,a.frames.remove(from));}
    public static void stretch(RigAnimation a,int duration){if(duration<1||duration>1200)throw new IllegalArgumentException("Duration must be 1-1200 ticks");NavigableMap<Integer,Map<String,float[]>> frames=new TreeMap<>();for(var e:a.frames.entrySet()){int t=Math.round((float)e.getKey()*duration/a.durationTicks);if(frames.put(t,copyPose(e.getValue()))!=null)throw new IllegalArgumentException("Stretch would merge keyframes; choose a longer duration");}a.frames.clear();a.frames.putAll(frames);a.durationTicks=duration;}
    public static final class History {
        private final Deque<RigAnimation> undo=new ArrayDeque<>(),redo=new ArrayDeque<>();private String group="";private long last;
        public void record(RigAnimation clip,String operation,long now){if(!operation.equals(group)||now-last>450||undo.isEmpty()){undo.push(copy(clip));while(undo.size()>64)undo.removeLast();}group=operation;last=now;redo.clear();}
        public RigAnimation undo(RigAnimation current){if(undo.isEmpty())return current;redo.push(copy(current));group="";return undo.pop();}
        public RigAnimation redo(RigAnimation current){if(redo.isEmpty())return current;undo.push(copy(current));group="";return redo.pop();}
        public boolean canUndo(){return !undo.isEmpty();}public boolean canRedo(){return !redo.isEmpty();}
    }
}
