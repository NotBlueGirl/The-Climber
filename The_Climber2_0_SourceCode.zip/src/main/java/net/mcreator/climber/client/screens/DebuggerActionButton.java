package net.mcreator.climber.client.screens;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Text-only debugger actions: no vanilla stone or filled button background. */
public final class DebuggerActionButton extends Button {
  public DebuggerActionButton(String label, int x, int y, int width, Runnable action) {
    super(x, y, width, 20, Component.literal(label), b -> action.run(), DEFAULT_NARRATION);
  }

  @Override
  protected void renderWidget(GuiGraphics g, int mx, int my, float partial) {
    int color = !active ? 0x66747D : isHoveredOrFocused() ? 0x70B7F0 : 0xD6DDE2;
    var font = Minecraft.getInstance().font;
    g.drawString(
        font,
        font.plainSubstrByWidth(getMessage().getString(), getWidth() - 8),
        getX() + 4,
        getY() + 6,
        color,
        false);
    if (isHoveredOrFocused())
      g.fill(
          getX() + 4,
          getY() + getHeight() - 2,
          getX() + getWidth() - 4,
          getY() + getHeight() - 1,
          0xFF70B7F0);
  }
}
