package net.mcreator.climber.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mcreator.climber.door.DoorGeometry;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.network.DoorPushPacket;

@OnlyIn(Dist.CLIENT)
public class DoorClientHandler {

    // ------------------------------------------------------------------
    // Server is authoritative for door angles (no client prediction -> no desync / jitter).
    // Here we only advance interpolation and detect the local player walking into doors.
    // ------------------------------------------------------------------
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        ClientDoorAngles.beginTick();

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        BlockPos held = ClientDoorGrab.currentLower;
        if (held != null && !(mc.level.getBlockState(held).getBlock() instanceof DoorBlock)) {
            ClientDoorGrab.currentLower = null;
            held = null;
        }

        detectPush(mc, held);
    }

    /** Walking into a wooden door pushes it (White Knuckle style). */
    private void detectPush(Minecraft mc, BlockPos held) {
        LocalPlayer p = mc.player;
        if (p.input == null || p.isSpectator() || p.noPhysics) return;
        float fwd = p.input.forwardImpulse, strafe = p.input.leftImpulse;
        if (Math.abs(fwd) < 1.0e-3 && Math.abs(strafe) < 1.0e-3) return;

        double yaw = Math.toRadians(p.getYRot());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double wx = strafe * cos - fwd * sin;
        double wz = fwd * cos + strafe * sin;
        double len = Math.sqrt(wx * wx + wz * wz);
        if (len < 1.0e-4) return;
        double speed = p.isSprinting() ? 0.28 : (p.isCrouching() ? 0.08 : 0.2);
        wx = wx / len * speed;
        wz = wz / len * speed;

        AABB bb = p.getBoundingBox().inflate(0.12, -0.05, 0.12);
        java.util.Set<BlockPos> sent = new java.util.HashSet<>();
        for (BlockPos bp : BlockPos.betweenClosed(
                Mth.floor(bb.minX), Mth.floor(bb.minY), Mth.floor(bb.minZ),
                Mth.floor(bb.maxX), Mth.floor(bb.maxY), Mth.floor(bb.maxZ))) {
            BlockState st = mc.level.getBlockState(bp);
            if (!(st.getBlock() instanceof DoorBlock door) || !door.type().canOpenByHand()) continue;
            BlockPos lower = st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? bp.below() : bp.immutable();
            if (lower.equals(held) || sent.contains(lower)) continue;
            VoxelShape shape = st.getCollisionShape(mc.level, bp);
            boolean touching = false;
            for (AABB box : shape.toAabbs()) {
                if (box.move(bp).intersects(bb)) { touching = true; break; }
            }
            if (!touching) continue;
            sent.add(lower);
            ClimberMod.PACKET_HANDLER.sendToServer(new DoorPushPacket(lower, (float) wx, (float) wz));
        }
    }

    @SubscribeEvent
    public void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientDoorAngles.clear();
        ClientDoorGrab.currentLower = null;
    }

    @SubscribeEvent
    public void onRespawnOrDimension(ClientPlayerNetworkEvent.Clone event) {
        ClientDoorAngles.clear();
        ClientDoorGrab.currentLower = null;
    }

    @SubscribeEvent
    public void onChunkUnload(ChunkEvent.Unload event) {
        if (event.getLevel().isClientSide()) {
            ClientDoorAngles.removeInChunk(event.getChunk().getPos());
        }
    }

    // ------------------------------------------------------------------
    // Рука в первом лице, прикреплённая к двери (камерное пространство!)
    // ------------------------------------------------------------------
    @SubscribeEvent(priority = EventPriority.HIGH)
public void onRenderHand(RenderHandEvent event) {
    if (ClientDoorGrab.currentLower == null) return;
    if (event.getHand() != InteractionHand.MAIN_HAND) return;

    Minecraft mc = Minecraft.getInstance();
    if (mc.player == null || mc.level == null) return;

    BlockPos lower = ClientDoorGrab.currentLower;

    BlockState lowerState = mc.level.getBlockState(lower);
    if (!(lowerState.getBlock() instanceof DoorBlock)) return;

    event.setCanceled(true);

    Direction facing = lowerState.getValue(DoorBlock.FACING);
    boolean hingeRight = lowerState.getValue(DoorBlock.HINGE) == DoorHingeSide.RIGHT;

    float partial = event.getPartialTick();
    Float known = ClientDoorAngles.getFor(mc.level, lower);
    float angle = known != null ? ClientDoorAngles.getInterpolated(mc.level, lower, partial)
            : (lowerState.getValue(DoorBlock.OPEN) ? DoorGeometry.vanillaOpenAngle(hingeRight) : 0f);

    double[] h = DoorGeometry.hingeXZ(lower, facing, hingeRight);
    double[] d = DoorGeometry.getPlankDirection(facing, hingeRight, angle);

    double grip = ClientDoorGrab.grabRadius;
    Vec3 grab = new Vec3(
        h[0] + d[0] * grip,
        ClientDoorGrab.grabY,
        h[1] + d[1] * grip
    );

    Vec3 playerPos = mc.player.getPosition(partial);
    Vec3 shoulder = playerPos.add(0.0D, mc.player.getEyeHeight() * 0.5D, 0.0D);

    Vec3 toShoulder = shoulder.subtract(grab);
    double len = toShoulder.length();
    Vec3 dir = len > 0.001D ? toShoulder.scale(1.0D / len) : new Vec3(0.0D, 1.0D, 0.0D);

    Vec3 shoulderPos = grab.add(dir.scale(0.75D));

    Camera camera = mc.gameRenderer.getMainCamera();
    Vec3 camPos = camera.getPosition();

    float yawRad = (float) Math.toRadians(camera.getYRot());
    float pitchRad = (float) Math.toRadians(camera.getXRot());

    float cosPitch = Mth.cos(pitchRad);
    float sinPitch = Mth.sin(pitchRad);
    float cosYaw = Mth.cos(yawRad);
    float sinYaw = Mth.sin(yawRad);

    Vec3 lookV = new Vec3(-sinYaw * cosPitch, -sinPitch, cosYaw * cosPitch);
    Vec3 rightV = new Vec3(-cosYaw, 0.0D, -sinYaw);
    Vec3 upV = new Vec3(-sinYaw * sinPitch, cosPitch, cosYaw * sinPitch);

    Vec3 rel = shoulderPos.subtract(camPos);

    double sx = rel.dot(rightV);
    double sy = rel.dot(upV);
    double sz = -rel.dot(lookV);

    Vec3 down = dir.scale(-1.0D);

    double dx = down.dot(rightV);
    double dy = down.dot(upV);
    double dz = -down.dot(lookV);

    float yaw = (float) Math.toDegrees(Math.atan2(dx, dz));
    float pitch = (float) Math.toDegrees(Math.asin(Mth.clamp(-dy, -1.0D, 1.0D)));

    PoseStack ps = event.getPoseStack();
    MultiBufferSource buf = event.getMultiBufferSource();
    int light = event.getPackedLight();

    ps.pushPose();

    ps.translate(sx, sy, sz);
    ps.mulPose(Axis.YP.rotationDegrees(yaw));
    ps.mulPose(Axis.XP.rotationDegrees(pitch + 90.0F));

    PlayerRenderer renderer = (PlayerRenderer) mc.getEntityRenderDispatcher().getRenderer(mc.player);
    var model = renderer.getModel();
    model.setupAnim(mc.player, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);

    boolean headV = model.head.visible;
    boolean hatV = model.hat.visible;
    boolean bodyV = model.body.visible;
    boolean rLegV = model.rightLeg.visible;
    boolean lLegV = model.leftLeg.visible;
    boolean rArmV = model.rightArm.visible;
    boolean lArmV = model.leftArm.visible;
    boolean rSlV = model.rightSleeve.visible;
    boolean lSlV = model.leftSleeve.visible;

    model.head.visible = false;
    model.hat.visible = false;
    model.body.visible = false;
    model.rightLeg.visible = false;
    model.leftLeg.visible = false;
    model.leftArm.visible = false;
    model.leftSleeve.visible = false;

    model.rightArm.visible = true;

    VertexConsumer vcSolid = buf.getBuffer(RenderType.entitySolid(mc.player.getSkinTextureLocation()));
    VertexConsumer vcCutout = buf.getBuffer(RenderType.entityCutoutNoCull(mc.player.getSkinTextureLocation()));

    model.rightArm.render(ps, vcSolid, light, OverlayTexture.NO_OVERLAY);

    model.rightSleeve.visible = true;
    model.rightSleeve.render(ps, vcCutout, light, OverlayTexture.NO_OVERLAY);

    model.head.visible = headV;
    model.hat.visible = hatV;
    model.body.visible = bodyV;
    model.rightLeg.visible = rLegV;
    model.leftLeg.visible = lLegV;
    model.rightArm.visible = rArmV;
    model.leftArm.visible = lArmV;
    model.rightSleeve.visible = rSlV;
    model.leftSleeve.visible = lSlV;

    ps.popPose();
}
}