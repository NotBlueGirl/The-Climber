package net.mcreator.climber.client;

import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.entity.HandholdEntity;
import net.mcreator.climber.grip.GripMode;
import net.mcreator.climber.init.ClimberModSounds;
import net.mcreator.climber.network.HandGrabPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;
import org.lwjgl.glfw.GLFW;

@OnlyIn(Dist.CLIENT)
public class ClimberInputHandler {

  private net.minecraft.world.item.Item lastMain, lastOff;
  private int selectedSlot = -1, recoverTicks;

  @SubscribeEvent
  public void onSwapKey(InputEvent.Key event) {
    var mc = Minecraft.getInstance();
    if (event.getAction() != GLFW.GLFW_PRESS
        || mc.player == null
        || mc.screen != null
        || !ClimberClientData.climbEnabled
        || !mc.options.keySwapOffhand.matches(event.getKey(), event.getScanCode())) return;
    if (mc.gameMode != null && mc.player.isUsingItem()) mc.gameMode.releaseUsingItem(mc.player);
    resetHands(mc);
    recoverTicks = 3;
  }

  private static void resetHands(Minecraft mc) {
    for (byte hand : new byte[] {HandGrabPacket.HAND_RIGHT, HandGrabPacket.HAND_LEFT}) {
      releaseLocal(hand);
      ClimberMod.PACKET_HANDLER.sendToServer(new HandGrabPacket(hand, false));
    }
    mc.options.keyUse.setDown(false);
    mc.options.keyAttack.setDown(false);
  }

  @SubscribeEvent
  public void onInputTick(net.minecraftforge.event.TickEvent.ClientTickEvent event) {
    var mc = Minecraft.getInstance();
    if (event.phase == net.minecraftforge.event.TickEvent.Phase.START) {
      // Mouse PRE is cancelled for independent hands, so vanilla never updates keyUse.
      // Keep its single active-use state alive only while that physical button is held.
      if (mc.player != null && mc.screen == null && ClimberClientData.climbEnabled) {
        boolean held = false;
        if (mc.player.isUsingItem()) {
          boolean right = mc.player.getUsedItemHand() == itemHand(mc.player, true);
          held =
              GLFW.glfwGetMouseButton(
                      mc.getWindow().getWindow(),
                      right ? GLFW.GLFW_MOUSE_BUTTON_RIGHT : GLFW.GLFW_MOUSE_BUTTON_LEFT)
                  == GLFW.GLFW_PRESS;
        }
        mc.options.keyUse.setDown(held);
      }
      return;
    }
    if (mc.player == null || mc.level == null) {
      lastMain = lastOff = null;
      selectedSlot = -1;
      recoverTicks = 0;
      return;
    }
    var main = mc.player.getMainHandItem().getItem();
    var off = mc.player.getOffhandItem().getItem();
    int slot = mc.player.getInventory().selected;
    if (ClimberClientData.climbEnabled
        && lastMain != null
        && (main != lastMain || off != lastOff || slot != selectedSlot)) {
      if (mc.player.isUsingItem()
          && mc.player.getUseItem().getItem()
              != mc.player.getItemInHand(mc.player.getUsedItemHand()).getItem()
          && mc.gameMode != null) mc.gameMode.releaseUsingItem(mc.player);
      resetHands(mc);
      recoverTicks = 3;
    }
    lastMain = main;
    lastOff = off;
    selectedSlot = slot;
    if (mc.screen == null) {
      long window = mc.getWindow().getWindow();
      ClimberClientData.rightMouseDown =
          GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
      ClimberClientData.leftMouseDown =
          GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }
    if (recoverTicks > 0
        && --recoverTicks == 0
        && mc.screen == null
        && ClimberClientData.climbEnabled) {
      if (ClimberClientData.rightMouseDown && !ClimberClientData.rightExhausted)
        tryGrab(mc, HandGrabPacket.HAND_RIGHT);
      if (ClimberClientData.leftMouseDown && !ClimberClientData.leftExhausted)
        tryGrab(mc, HandGrabPacket.HAND_LEFT);
    }
  }

  @SubscribeEvent
  public void onMouseButton(InputEvent.MouseButton.Pre event) {
    Minecraft mc = Minecraft.getInstance();
    if (mc.player == null || mc.screen != null) return;

    // physical mouse state (auto grip), independent of climbEnabled
    if (event.getAction() == GLFW.GLFW_PRESS || event.getAction() == GLFW.GLFW_RELEASE) {
      boolean down = event.getAction() == GLFW.GLFW_PRESS;
      if (event.getButton() == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
        ClimberClientData.rightMouseDown = down;
      } else if (event.getButton() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
        ClimberClientData.leftMouseDown = down;
      }
    }

    // RMB released -> let go of the door (works even with climbing disabled)
    if (event.getButton() == GLFW.GLFW_MOUSE_BUTTON_RIGHT
        && event.getAction() == GLFW.GLFW_RELEASE) {
      ClientDoorGrab.releaseIfGrabbing();
    }

    if (!ClimberClientData.climbEnabled) return;

    int button = event.getButton();
    int action = event.getAction();
    if (button != GLFW.GLFW_MOUSE_BUTTON_RIGHT && button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return;

    if (action == GLFW.GLFW_RELEASE && mc.player.isUsingItem() && mc.gameMode != null) {
      boolean usedRight = mc.player.getUsedItemHand() == itemHand(mc.player, true);
      if (usedRight == (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT)
          || mc.player.getItemInHand(mc.player.getUsedItemHand()).isEmpty())
        mc.gameMode.releaseUsingItem(mc.player);
    }
    HitResult hit = mc.hitResult;

    var itemHand = itemHand(mc.player, button == GLFW.GLFW_MOUSE_BUTTON_RIGHT);
    byte physicalHand =
        button == GLFW.GLFW_MOUSE_BUTTON_RIGHT
            ? HandGrabPacket.HAND_RIGHT
            : HandGrabPacket.HAND_LEFT;
    if (action == GLFW.GLFW_PRESS
        && button == GLFW.GLFW_MOUSE_BUTTON_LEFT
        && mc.player.isCreative()
        && mc.player.isShiftKeyDown()
        && (mc.player.getMainHandItem().getItem()
                instanceof net.mcreator.climber.item.DebuggerToolItem
            || mc.player.getOffhandItem().getItem()
                instanceof net.mcreator.climber.item.DebuggerToolItem)
        && hit instanceof EntityHitResult ehr
        && ehr.getEntity() instanceof net.mcreator.climber.mechanism.MechanismEntity obj) {
      var root = obj.authoringRoot();
      ClimberMod.PACKET_HANDLER.sendToServer(
          new net.mcreator.climber.network.MechanismEditPacket(
              root.spec().save(), root.getId(), 1));
      event.setCanceled(true);
      return;
    }
    if (!mc.player.getItemInHand(itemHand).isEmpty()) {
      event.setCanceled(true);
      if (action == GLFW.GLFW_PRESS) {
        releaseLocal(physicalHand);
        ClimberMod.PACKET_HANDLER.sendToServer(new HandGrabPacket(physicalHand, false));
        useHand(mc, itemHand);
      } else if (action == GLFW.GLFW_RELEASE
          && mc.player.isUsingItem()
          && mc.player.getUsedItemHand() == itemHand
          && mc.gameMode != null) mc.gameMode.releaseUsingItem(mc.player);
      return;
    }
    if (action == GLFW.GLFW_PRESS
        && hit instanceof EntityHitResult ehr
        && ehr.getEntity() instanceof net.mcreator.climber.mechanism.MechanismEntity mechanism
        && (mechanism.spec().kind == net.mcreator.climber.mechanism.MechanismSpec.Kind.VALVE
            || mechanism.spec().kind
                == net.mcreator.climber.mechanism.MechanismSpec.Kind.PLATFORM)) {
      useHand(mc, itemHand);
      event.setCanceled(true);
      return;
    }
    if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
      if (action == GLFW.GLFW_PRESS
          && hit instanceof BlockHitResult bhr
          && hit.getType() == HitResult.Type.BLOCK
          && mc.level != null
          && mc.level.getBlockState(bhr.getBlockPos()).getBlock() instanceof DoorBlock) {
        useHand(mc, itemHand);
        event.setCanceled(true);
        return;
      }
      if (action == GLFW.GLFW_PRESS && InteractableCrosshair.lookingAtInterface(mc)) return;
      if (action == GLFW.GLFW_PRESS
          && mc.player.isShiftKeyDown()
          && hit instanceof EntityHitResult ehr
          && ehr.getEntity() instanceof HandholdEntity) {
        useHand(mc, itemHand);
        event.setCanceled(true);
        return;
      }
    }

    byte hand =
        button == GLFW.GLFW_MOUSE_BUTTON_RIGHT
            ? HandGrabPacket.HAND_RIGHT
            : HandGrabPacket.HAND_LEFT;
    if (action == GLFW.GLFW_PRESS) {
      boolean exhausted =
          hand == HandGrabPacket.HAND_RIGHT
              ? ClimberClientData.rightExhausted
              : ClimberClientData.leftExhausted;
      // Only predict a grab the server will accept: an invalid target in Realistic mode used to
      // yank the player towards the wall for a moment and then snap back.
      if (!exhausted) tryGrab(mc, hand);
      event.setCanceled(true);
    } else if (action == GLFW.GLFW_RELEASE) {
      releaseLocal(hand);
      ClimberMod.PACKET_HANDLER.sendToServer(new HandGrabPacket(hand, false));
      event.setCanceled(true);
    }
  }

  public static net.minecraft.world.InteractionHand itemHand(
      net.minecraft.world.entity.player.Player p, boolean right) {
    return right == (p.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT)
        ? net.minecraft.world.InteractionHand.MAIN_HAND
        : net.minecraft.world.InteractionHand.OFF_HAND;
  }

  private static void useHand(Minecraft mc, net.minecraft.world.InteractionHand hand) {
    if (mc.gameMode == null || mc.player == null || mc.player.isUsingItem()) return;
    var p = mc.player;
    var held = p.getItemInHand(hand);
    if (!held.isEmpty() && p.getCooldowns().isOnCooldown(held.getItem())) return;
    net.minecraft.world.InteractionResult result = net.minecraft.world.InteractionResult.PASS;
    if (mc.hitResult instanceof EntityHitResult hit) {
      result = mc.gameMode.interactAt(p, hit.getEntity(), hit, hand);
      if (!result.consumesAction()) result = mc.gameMode.interact(p, hit.getEntity(), hand);
    } else if (mc.hitResult instanceof BlockHitResult hit
        && mc.hitResult.getType() == HitResult.Type.BLOCK) {
      boolean useInAir =
          held.getItem() instanceof net.mcreator.climber.item.ClimberTool
              && !(held.getItem() instanceof net.mcreator.climber.item.DebuggerToolItem)
              && !(held.getItem() instanceof net.mcreator.climber.item.PitonItem);
      if (!useInAir) result = mc.gameMode.useItemOn(p, hand, hit);
    }
    if (!result.consumesAction()) result = mc.gameMode.useItem(p, hand);
    if (p.isUsingItem()) mc.options.keyUse.setDown(true);
    if (result.shouldSwing()) p.swing(hand);
  }

  /**
   * Grab whatever the crosshair points at, if it is a valid hold. Shared with {@link
   * AutoGripScanner}.
   */
  static boolean tryGrab(Minecraft mc, byte hand) {
    if (mc.player == null || mc.level == null) return false;
    if (!mc.player.getItemInHand(itemHand(mc.player, hand == HandGrabPacket.HAND_RIGHT)).isEmpty())
      return false;
    HitResult hit = mc.hitResult;
    if (hit == null) return false;

    if (hit.getType() == HitResult.Type.ENTITY
        && hit instanceof EntityHitResult ehr
        && ehr.getEntity() instanceof HandholdEntity h
        && h.canBeGrabbed()) {
      Vec3 anchor = h.getGripPoint();
      if (anchor.distanceToSqr(mc.player.getEyePosition()) > 25.0) return false;
      predict(mc, hand, anchor);
      if (hand == HandGrabPacket.HAND_RIGHT)
        ClimberClientData.rightHoldEntity = ehr.getEntity().getId();
      else ClimberClientData.leftHoldEntity = ehr.getEntity().getId();
      ClimberMod.PACKET_HANDLER.sendToServer(
          HandGrabPacket.entity(hand, anchor, ehr.getEntity().getId()));
      mc.player.playSound(SoundEvents.CHAIN_HIT, 0.6f, 1.2f);
      return true;
    }

    if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult bhr) {
      BlockPos pos = bhr.getBlockPos();
      if (mc.level.getBlockState(pos).getBlock() instanceof DoorBlock) return false;
      Vec3 anchor = bhr.getLocation();
      GripMode mode = ClimberClientData.gripModeRealistic ? GripMode.REALISTIC : GripMode.LIP_HANDS;
      if (!HandGrabPacket.isGrabbableCandidate(mc.level, anchor, pos, bhr.getDirection(), mode))
        return false;
      predict(mc, hand, anchor);
      ClimberMod.PACKET_HANDLER.sendToServer(
          HandGrabPacket.block(hand, anchor, bhr.getDirection(), pos));
      playGrabHitSound(mc, pos);
      return true;
    }
    return false;
  }

  private static void predict(Minecraft mc, byte hand, Vec3 anchor) {
    Vec3 frozenDir = computeAnchorDir(mc, anchor);
    if (hand == HandGrabPacket.HAND_RIGHT) {
      ClimberClientData.rightGrabbing = true;
      ClimberClientData.rightAnchor = anchor;
      ClimberClientData.rightAnchorDir = frozenDir;
    } else {
      ClimberClientData.leftGrabbing = true;
      ClimberClientData.leftAnchor = anchor;
      ClimberClientData.leftAnchorDir = frozenDir;
    }
  }

  static void releaseLocal(byte hand) {
    if (hand == HandGrabPacket.HAND_RIGHT) {
      ClimberClientData.rightGrabbing = false;
      ClimberClientData.rightHoldEntity = -1;
      ClimberClientData.rightAnchor = null;
      ClimberClientData.rightAnchorDir = null;
    } else {
      ClimberClientData.leftGrabbing = false;
      ClimberClientData.leftHoldEntity = -1;
      ClimberClientData.leftAnchor = null;
      ClimberClientData.leftAnchorDir = null;
    }
  }

  // FIX: accept BlockPos so we don't re-derive it from the face-boundary Vec3
  static void playGrabHitSound(Minecraft mc, BlockPos soundPos) {
    String customPath =
        ClientSoundChoices.get("grabHitSound", ClimberConfig.INSTANCE.getGrabHitSound());

    if (customPath != null && !customPath.isEmpty()) {
      if (ClimberSoundPreloader.isFilePath(customPath)) {
        ClimberSoundPreloader.playAt(customPath, 0.6f, 0.8f, Vec3.atCenterOf(soundPos));
        return;
      }
      try {
        ResourceLocation rl = new ResourceLocation(customPath);
        SoundEvent ev = ForgeRegistries.SOUND_EVENTS.getValue(rl);
        if (ev != null) {
          mc.player.playSound(ev, 0.6f, 1.0f);
          return;
        }
      } catch (Exception e) {
        ClimberMod.LOGGER.warn("[Climber] Invalid grab-hit registry ID: '{}'", customPath);
      }
    }

    // Default: break sound of the pinned block
    BlockState state = mc.level.getBlockState(soundPos);
    if (!state.isAir()) {
      SoundType st = state.getSoundType();
      mc.player.playSound(st.getBreakSound(), st.getVolume() * 0.6f, st.getPitch() * 0.8f);
      return;
    }

    // Ultimate fallback
    mc.player.playSound(ClimberModSounds.GRAB_HIT.get(), 0.6f, 1.0f);
  }

  private static Vec3 computeAnchorDir(Minecraft mc, Vec3 anchor) {
    Vec3 shoulder = mc.player.position().add(0, mc.player.getEyeHeight() * 0.5, 0);
    Vec3 toShoulder = shoulder.subtract(anchor);
    double len = toShoulder.length();
    return len > 0.001 ? toShoulder.scale(1.0 / len) : new Vec3(0, 1, 0);
  }
}
