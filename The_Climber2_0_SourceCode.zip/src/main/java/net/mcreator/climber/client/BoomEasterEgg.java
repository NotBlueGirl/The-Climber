package net.mcreator.climber.client;

import net.minecraft.client.Minecraft;
import net.minecraft.commands.Commands;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;

/**
 * Easter egg: {@code /boom}. Purely client-side and harmless - a fake explosion (particles, sound,
 * a firework) in front of the player, and a joke "AI weights" text file written into the game folder
 * (.minecraft/the_climber_ai_weights.txt). Nothing is downloaded and the world is not touched.
 */
@OnlyIn(Dist.CLIENT)
public final class BoomEasterEgg {
    private BoomEasterEgg() {}

    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("boom").executes(ctx -> {
            Minecraft mc = Minecraft.getInstance();
            mc.execute(BoomEasterEgg::boom);
            return 1;
        }));
    }

    private static void boom() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        Vec3 p = mc.player.getEyePosition().add(mc.player.getViewVector(1f).scale(4.0));
        mc.level.addParticle(ParticleTypes.EXPLOSION_EMITTER, p.x, p.y, p.z, 0, 0, 0);
        mc.level.playLocalSound(p.x, p.y, p.z, SoundEvents.GENERIC_EXPLODE, net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 1.0f, false);

        CompoundTag explosion = new CompoundTag();
        explosion.putByte("Type", (byte) 1);          // large ball
        explosion.put("Colors", new IntArrayTag(new int[] { 0xFFD21E, 0xFF5A1E, 0xFFFFFF }));
        explosion.put("FadeColors", new IntArrayTag(new int[] { 0x8B0A16 }));
        explosion.putBoolean("Flicker", true);
        ListTag list = new ListTag();
        list.add(explosion);
        CompoundTag fw = new CompoundTag();
        fw.put("Explosions", list);
        mc.level.createFireworks(p.x, p.y + 1.5, p.z, 0, 0, 0, fw);

        java.nio.file.Path file = mc.gameDirectory.toPath().resolve("the_climber_ai_weights.txt");
        try {
            java.nio.file.Files.writeString(file, weightsText(), java.nio.charset.StandardCharsets.UTF_8);
            Component link = Component.literal("the_climber_ai_weights.txt").withStyle(st -> st
                    .withColor(net.minecraft.ChatFormatting.AQUA).withUnderlined(true)
                    .withClickEvent(new net.minecraft.network.chat.ClickEvent(
                            net.minecraft.network.chat.ClickEvent.Action.OPEN_FILE, file.toAbsolutePath().toString())));
            mc.player.displayClientMessage(Component.literal("\u00a76[The Climber] \u00a7eBOOM! \u00a77AI weights downloaded: ")
                    .append(link), false);
        } catch (java.io.IOException ex) {
            mc.player.displayClientMessage(Component.literal("\u00a76[The Climber] \u00a7eBOOM! \u00a77(the weights blew up before landing)"), false);
        }
    }

    /** 100% genuine, artisanal, hand-made weights. */
    private static String weightsText() {
        StringBuilder b = new StringBuilder();
        b.append("=====================================================================\n");
        b.append("  THE CLIMBER x AI  -  OFFICIAL MODEL WEIGHTS  (super secret, shhh)\n");
        b.append("=====================================================================\n");
        b.append("format    : pure vibes, 1 byte per feeling\n");
        b.append("params    : 64 (the rest fell off the wall - should have hammered the piton 3 times)\n");
        b.append("checksum  : if (block === true) { return block; }\n\n");
        b.append("[layer 0 - provided by the modder]\n16 78 93 08 32 77 109 31\n\n");
        java.util.Random r = new java.util.Random(0xC11B3E5L);
        String[] names = { "grip", "stamina", "rebar_aim", "piton_trust", "fear_of_heights", "crank_arm" };
        for (String n : names) {
            b.append("[layer ").append(n).append("]\n");
            for (int row = 0; row < 4; row++) {
                for (int i = 0; i < 8; i++) b.append(String.format(java.util.Locale.ROOT, "%+.4f ", r.nextGaussian() * 0.5));
                b.append("\n");
            }
            b.append("\n");
        }
        b.append("---------------------------------------------------------------------\n");
        b.append("Honest footnote: real AI weights are not something a mod can download -\n");
        b.append("they are not mine to hand out and would be hundreds of gigabytes anyway.\n");
        b.append("So you got these. Keep climbing!  - your friendly AI coder\n");
        return b.toString();
    }
}
