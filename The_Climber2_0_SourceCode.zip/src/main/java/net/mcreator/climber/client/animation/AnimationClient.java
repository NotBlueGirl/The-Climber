package net.mcreator.climber.client.animation;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.animation.RigAnimation;
import net.mcreator.climber.client.screens.AnimationEditorScreen;
import net.mcreator.climber.network.AnimationRequestPacket;
import net.mcreator.climber.network.AnimationSyncPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;
import java.util.*;

/** Samples server-approved playback. Only operators publish; all installed clients render synced poses. */
@OnlyIn(Dist.CLIENT)
public final class AnimationClient {
    public static final NavigableMap<String, RigAnimation> CLIPS = new TreeMap<>();
    public static String status = "Local edits are private until published by an operator.";
    private record Playing(String id, long received, long elapsed) {}
    private static final Map<UUID, Playing> ACTIVE = new HashMap<>();
    private static final Map<PlayerModel<?>, PartPose[]> RESTORE = new WeakHashMap<>();
    public static RigAnimation preview;
    public static float previewTick;
    public static boolean previewRendering;
    private static long time() { var level = Minecraft.getInstance().level; return level == null ? 0 : level.getGameTime(); }
    public static void receive(AnimationSyncPacket m) {
        try {
            switch (m.kind()) {
                case AnimationSyncPacket.RESET -> { CLIPS.clear(); ACTIVE.clear(); }
                case AnimationSyncPacket.DEFINITION -> { RigAnimation a = RigAnimation.fromJson(m.text()); CLIPS.put(a.id, a); }
                case AnimationSyncPacket.PLAY -> { if (CLIPS.containsKey(m.text())) ACTIVE.put(m.player(), new Playing(m.text(), time(), Math.max(0, m.elapsed()))); }
                case AnimationSyncPacket.STOP -> ACTIVE.remove(m.player());
                case AnimationSyncPacket.MESSAGE -> status = m.text();
                default -> { }
            }
        } catch (Exception e) { ClimberMod.LOGGER.warn("[Animation] Invalid server animation: {}", e.getMessage()); }
    }
    private record Sample(RigAnimation clip, float tick, float weight) {}
    private static Sample current(Player p) {
        var mc = Minecraft.getInstance();
        if (previewRendering && preview != null && p == mc.player) return new Sample(preview, Math.max(0, Math.min(preview.durationTicks, previewTick)), 1);
        Playing playing = ACTIVE.get(p.getUUID()); if (playing == null) return null;
        RigAnimation a = CLIPS.get(playing.id); if (a == null) return null;
        float age = playing.elapsed + Math.max(0, time() - playing.received) + mc.getFrameTime();
        if (!a.loop && age >= a.durationTicks) return null;
        float tick = a.loop ? age % a.durationTicks : age;
        float weight = Math.min(1, age / 2f);
        if (!a.loop) weight = Math.min(weight, (a.durationTicks - age) / Math.min(2f, a.durationTicks));
        return new Sample(a, tick, Math.max(0, weight));
    }
    public static boolean armAnimated(Player p, boolean right) {
        Sample s = current(p); return s != null && s.clip.sample(right ? "right_arm" : "left_arm", s.tick) != null;
    }
    private static ModelPart[] parts(PlayerModel<?> m) {
        return new ModelPart[] { m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg,
                m.hat, m.jacket, m.rightSleeve, m.leftSleeve, m.rightPants, m.leftPants };
    }
    /** Called at setupAnim HEAD: restores the prior frame before vanilla posing (no accumulating offsets). */
    public static void restore(PlayerModel<?> model) {
        PartPose[] old = RESTORE.remove(model); if (old == null) return;
        ModelPart[] parts = parts(model); for (int i = 0; i < parts.length; i++) parts[i].loadPose(old[i]);
    }
    /** Called at setupAnim TAIL: layers authored transforms on vanilla animation; overlays follow their bones. */
    public static void apply(Player player, PlayerModel<?> model) {
        Sample s = current(player); if (s == null) return;
        ModelPart[] parts = parts(model); PartPose[] save = new PartPose[parts.length];
        for (int i = 0; i < parts.length; i++) save[i] = parts[i].storePose(); RESTORE.put(model, save);
        for (int i = 0; i < RigAnimation.BONES.length; i++) {
            float[] v = s.clip.sample(RigAnimation.BONES[i], s.tick); if (v == null) continue;
            ModelPart p = parts[i]; float w = s.weight, rad = (float) (Math.PI / 180);
            if (s.clip.additive) { p.xRot += v[0] * rad * w; p.yRot += v[1] * rad * w; p.zRot += v[2] * rad * w; }
            else { p.xRot += (v[0] * rad - p.xRot) * w; p.yRot += (v[1] * rad - p.yRot) * w; p.zRot += (v[2] * rad - p.zRot) * w; }
            p.x += v[3] * w; p.y += v[4] * w; p.z += v[5] * w;
        }
        model.hat.copyFrom(model.head); model.jacket.copyFrom(model.body);
        model.rightSleeve.copyFrom(model.rightArm); model.leftSleeve.copyFrom(model.leftArm);
        model.rightPants.copyFrom(model.rightLeg); model.leftPants.copyFrom(model.leftLeg);
    }
    /** Vanilla first-person meshes zero their X angle after setupAnim; pose them at draw time. */
    public static void firstPerson(Player player, PlayerModel<?> model, ModelPart part, boolean right) {
        Sample s = current(player); if (s == null) return;
        float[] v = s.clip.sample(right ? "right_arm" : "left_arm", s.tick); if (v == null) return;
        PartPose[] base = RESTORE.get(model); if (base == null) return;
        PartPose p = base[right ? 2 : 3]; float w = s.weight, rad = (float)(Math.PI / 180);
        part.xRot = v[0] * rad * w;
        part.yRot = s.clip.additive ? p.yRot + v[1] * rad * w : p.yRot + (v[1] * rad - p.yRot) * w;
        part.zRot = s.clip.additive ? p.zRot + v[2] * rad * w : p.zRot + (v[2] * rad - p.zRot) * w;
        part.x = p.x + v[3] * w; part.y = p.y + v[4] * w; part.z = p.z + v[5] * w;
    }
    private static boolean has(RigAnimation.Trigger t, int key) {
        return CLIPS.values().stream().anyMatch(a -> a.event == t && (t != RigAnimation.Trigger.KeyClicked && t != RigAnimation.Trigger.KeyReleased || a.keyCode == key));
    }
    private static void input(RigAnimation.Trigger t, int key) {
        if (has(t, key)) ClimberMod.PACKET_HANDLER.sendToServer(new AnimationRequestPacket(AnimationRequestPacket.INPUT, t.name(), key));
    }
    private static void release(RigAnimation.Trigger t, int key) {
        if (CLIPS.values().stream().anyMatch(a -> a.stopOnRelease && a.event == t && (t != RigAnimation.Trigger.KeyClicked || a.keyCode == key)))
            ClimberMod.PACKET_HANDLER.sendToServer(new AnimationRequestPacket(AnimationRequestPacket.RELEASE, t.name(), key));
    }
    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public void mouse(InputEvent.MouseButton.Pre e) {
        var mc = Minecraft.getInstance(); if (mc.player == null) return;
        RigAnimation.Trigger t = e.getButton() == GLFW.GLFW_MOUSE_BUTTON_LEFT ? RigAnimation.Trigger.Mouse1Clicked : e.getButton() == GLFW.GLFW_MOUSE_BUTTON_RIGHT ? RigAnimation.Trigger.Mouse2Clicked : null;
        if (t == null) return;
        if (e.getAction() == GLFW.GLFW_RELEASE) release(t, -1);
        else if (mc.screen == null && e.getAction() == GLFW.GLFW_PRESS) input(t, -1);
    }
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void key(InputEvent.Key e) {
        var mc = Minecraft.getInstance(); if (mc.player == null) return;
        if (e.getAction() == GLFW.GLFW_RELEASE) {
            release(RigAnimation.Trigger.KeyClicked, e.getKey());
            if (mc.screen == null) input(RigAnimation.Trigger.KeyReleased, e.getKey());
        } else if (mc.screen == null && e.getAction() == GLFW.GLFW_PRESS) input(RigAnimation.Trigger.KeyClicked, e.getKey());
    }
    @SubscribeEvent public void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return; var mc = Minecraft.getInstance(); if (mc.level == null) return;
        if (mc.player != null && mc.screen != null) {
            Playing own = ACTIVE.get(mc.player.getUUID());
            RigAnimation a = own == null ? null : CLIPS.get(own.id);
            if (a != null && a.stopOnRelease && (a.event == RigAnimation.Trigger.KeyClicked || a.event == RigAnimation.Trigger.Mouse1Clicked || a.event == RigAnimation.Trigger.Mouse2Clicked))
                ClimberMod.PACKET_HANDLER.sendToServer(new AnimationRequestPacket(AnimationRequestPacket.STOP, "", 0));
        }
        ACTIVE.entrySet().removeIf(entry -> { var p = entry.getValue(); var a = CLIPS.get(p.id); return a == null || (!a.loop && p.elapsed + time() - p.received > a.durationTicks + 2); });
    }
    @SubscribeEvent public void logout(ClientPlayerNetworkEvent.LoggingOut e) {
        CLIPS.clear(); ACTIVE.clear(); RESTORE.forEach((m, old) -> { ModelPart[] parts = parts(m); for (int i = 0; i < parts.length; i++) parts[i].loadPose(old[i]); }); RESTORE.clear();
        preview = null; previewRendering = false; status = "Disconnected; local clips can be imported again.";
    }
}
