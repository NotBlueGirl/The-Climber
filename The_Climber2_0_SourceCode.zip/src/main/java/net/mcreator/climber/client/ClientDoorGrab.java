package net.mcreator.climber.client;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.door.DoorGeometry;
import net.mcreator.climber.network.DoorGrabPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Client side of door grabbing. The server is authoritative for the angle (see DoorGrabManager);
 * the client only remembers which door it holds (for the hand renderer / release on RMB-up).
 */
@OnlyIn(Dist.CLIENT)
public class ClientDoorGrab {
    public static BlockPos currentLower = null;
    /** Distance pivot -> grabbed point along the plank. */
    public static double grabRadius = 0.65;
    /** World Y of the grabbed point. */
    public static double grabY = 0;

    public static void press(BlockPos anyDoorPos, Vec3 hit) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        BlockState st = mc.level.getBlockState(anyDoorPos);
        if (!(st.getBlock() instanceof DoorBlock)) return;
        BlockPos lower = st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? anyDoorPos.below() : anyDoorPos;
        if (lower.equals(currentLower)) return; // RMB auto-repeat

        BlockState ls = mc.level.getBlockState(lower);
        if (!(ls.getBlock() instanceof DoorBlock)) return;
        boolean hingeRight = ls.getValue(DoorBlock.HINGE) == DoorHingeSide.RIGHT;
        Float cur = ClientDoorAngles.getFor(mc.level, lower);
        float angle = cur != null ? cur : (ls.getValue(DoorBlock.OPEN) ? DoorGeometry.vanillaOpenAngle(hingeRight) : 0f);
        double[] h = DoorGeometry.hingeXZ(lower, ls.getValue(DoorBlock.FACING), hingeRight);
        double[] d = DoorGeometry.getPlankDirection(ls.getValue(DoorBlock.FACING), hingeRight, angle);
        Vec3 p = hit != null ? hit : Vec3.atCenterOf(anyDoorPos);
        grabRadius = Mth.clamp((p.x - h[0]) * d[0] + (p.z - h[1]) * d[1], 0.25, DoorGeometry.PLANK_LEN);
        grabY = Mth.clamp(p.y, lower.getY() + 0.1, lower.getY() + 1.9);
        currentLower = lower;
        // the server starts the grab itself from DoorBlock#use; nothing else to send
    }

    public static void releaseIfGrabbing() {
        if (currentLower != null) {
            ClimberMod.PACKET_HANDLER.sendToServer(new DoorGrabPacket(currentLower, false));
            currentLower = null;
        }
    }


}
