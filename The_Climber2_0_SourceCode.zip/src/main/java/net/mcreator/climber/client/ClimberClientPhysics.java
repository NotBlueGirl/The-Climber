package net.mcreator.climber.client;

import net.mcreator.climber.event.ClimberServerEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@OnlyIn(Dist.CLIENT)
public class ClimberClientPhysics {

  @SubscribeEvent
  public void onClientTick(TickEvent.PlayerTickEvent event) {
    if (event.phase != TickEvent.Phase.END) return;

    Player player = event.player;
    Minecraft mc = Minecraft.getInstance();

    // Only apply to our local player
    if (player != mc.player) return;

    // Advance blush smoothing every tick
    ClimberClientData.tickBlush();

    // Auto Grip: continuous-захват по прицелу, пока зажата кнопка (см. /climb autogrip).
    AutoGripScanner.tick(mc);

    if (!ClimberClientData.climbEnabled
        || (!ClimberClientData.rightGrabbing && !ClimberClientData.leftGrabbing)) {
      player.setNoGravity(false);
      return;
    }

    if (mc.level != null) {
      if (ClimberClientData.rightGrabbing
          && mc.level.getEntity(ClimberClientData.rightHoldEntity)
              instanceof net.mcreator.climber.entity.HandholdEntity h)
        ClimberClientData.rightAnchor = h.getGripPoint();
      if (ClimberClientData.leftGrabbing
          && mc.level.getEntity(ClimberClientData.leftHoldEntity)
              instanceof net.mcreator.climber.entity.HandholdEntity h)
        ClimberClientData.leftAnchor = h.getGripPoint();
      if (player.tickCount % 3 == 0
          && mc.screen == null
          && (rope(mc, ClimberClientData.rightHoldEntity)
              || rope(mc, ClimberClientData.leftHoldEntity))) {
        double
            forward = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0),
            side = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
        Vec3 f = Vec3.directionFromRotation(0, player.getYRot()),
            r = new Vec3(-f.z, 0, f.x),
            wish = f.scale(forward).add(r.scale(side));
        if (wish.lengthSqr() > 1) wish = wish.normalize();
        net.mcreator.climber.ClimberMod.PACKET_HANDLER.sendToServer(
            new net.mcreator.climber.network.RopeSwingPacket(
                (float) wish.x, (float) wish.z, mc.options.keySprint.isDown()));
      }
    }
    // Run the same moving-support physics locally.
    ClimberServerEvents.applyClimbPhysics(
        player,
        ClimberClientData.rightGrabbing,
        ClimberClientData.leftGrabbing,
        ClimberClientData.rightAnchor,
        ClimberClientData.leftAnchor,
        ClimberServerEvents.supportVelocity(
            player,
            ClimberClientData.rightGrabbing ? ClimberClientData.rightHoldEntity : -1,
            ClimberClientData.leftGrabbing ? ClimberClientData.leftHoldEntity : -1));
  }

  private static boolean rope(Minecraft mc, int id) {
    return id >= 0
        && mc.level.getEntity(id) instanceof net.mcreator.climber.mechanism.MechanismEntity e
        && e.spec().kind == net.mcreator.climber.mechanism.MechanismSpec.Kind.ROPE;
  }
}
