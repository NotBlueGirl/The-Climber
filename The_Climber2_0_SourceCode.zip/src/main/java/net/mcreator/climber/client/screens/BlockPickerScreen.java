package net.mcreator.climber.client.screens;

import java.util.*;
import java.util.function.Consumer;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Virtualized registry browser, including modded blocks; only visible rows are drawn. */
public final class BlockPickerScreen extends Screen {
  private final Screen parent;
  private final Consumer<Collection<String>> accept;
  private final Set<String> selected = new TreeSet<>();
  private final List<ResourceLocation> all = new ArrayList<>(), filtered = new ArrayList<>();
  private EditBox search;
  private int scroll;
  private boolean onlySelected;
  private String message = "";

  public BlockPickerScreen(
      Screen parent, String title, Collection<String> values, Consumer<Collection<String>> accept) {
    super(Component.literal(title));
    this.parent = parent;
    this.accept = accept;
    selected.addAll(values);
    all.addAll(ForgeRegistries.BLOCKS.getKeys());
    all.sort(Comparator.comparing(ResourceLocation::toString));
  }

  private void filter() {
    String s = search.getValue().trim().toLowerCase(Locale.ROOT);
    filtered.clear();
    for (var id : all) {
      var block = ForgeRegistries.BLOCKS.getValue(id);
      if ((!onlySelected || selected.contains(id.toString()))
          && (id.toString().contains(s)
              || block.getName().getString().toLowerCase(Locale.ROOT).contains(s)))
        filtered.add(id);
    }
    scroll = 0;
  }

  @Override
  protected void init() {
    search = new EditBox(font, 12, 30, width - 24, 20, Component.literal("Search all blocks"));
    search.setMaxLength(128);
    search.setResponder(s -> filter());
    addRenderableWidget(search);
    setInitialFocus(search);
    addRenderableWidget(
        Button.builder(
                Component.literal("Selected / all"),
                b -> {
                  onlySelected = !onlySelected;
                  filter();
                })
            .bounds(12, height - 48, 110, 18)
            .build());
    addRenderableWidget(
        Button.builder(
                Component.literal("Clear selection"),
                b -> {
                  selected.clear();
                  filter();
                })
            .bounds(126, height - 48, 110, 18)
            .build());
    addRenderableWidget(
        Button.builder(
                Component.literal("Use selection"),
                b -> {
                  accept.accept(selected);
                  minecraft.setScreen(parent);
                })
            .bounds(12, height - 26, 110, 18)
            .build());
    addRenderableWidget(
        Button.builder(Component.literal("Cancel"), b -> onClose())
            .bounds(126, height - 26, 110, 18)
            .build());
    filter();
  }

  private int rows() {
    return Math.max(1, (height - 116) / 22);
  }

  @Override
  public boolean mouseClicked(double x, double y, int b) {
    if (b == 0 && y >= 56 && y < 56 + rows() * 22 && x >= 12 && x < width - 12) {
      int i = scroll + (int) (y - 56) / 22;
      if (i < filtered.size()) {
        String id = filtered.get(i).toString();
        if (selected.contains(id)) selected.remove(id);
        else if (selected.size() < 512) selected.add(id);
        else message = "At most 512 selected blocks per list.";
        return true;
      }
    }
    return super.mouseClicked(x, y, b);
  }

  @Override
  public boolean mouseScrolled(double x, double y, double d) {
    scroll = Math.max(0, Math.min(Math.max(0, filtered.size() - rows()), scroll - (int) (d * 3)));
    return true;
  }

  @Override
  public void tick() {
    search.tick();
  }

  @Override
  public void onClose() {
    minecraft.setScreen(parent);
  }

  @Override
  public void render(GuiGraphics g, int x, int y, float p) {
    g.fill(0, 0, width, height, 0xFA0A0A0C);
    g.drawString(
        font, title.getString() + " — " + selected.size() + " selected", 12, 12, 0xFFE8C547);
    for (int r = 0; r < rows() && scroll + r < filtered.size(); r++) {
      var id = filtered.get(scroll + r);
      int yy = 56 + r * 22;
      boolean on = selected.contains(id.toString());
      if (y >= yy && y < yy + 22) g.fill(12, yy, width - 12, yy + 21, 0x20FFFFFF);
      g.drawString(font, on ? "[x]" : "[ ]", 15, yy + 6, on ? 0xFFE8C547 : 0xFF888888);
      g.renderItem(new ItemStack(ForgeRegistries.BLOCKS.getValue(id).asItem()), 42, yy + 2);
      g.drawString(
          font, font.plainSubstrByWidth(id.toString(), width - 82), 64, yy + 6, 0xFFCCCCCC);
    }
    super.render(g, x, y, p);
    String status = filtered.size() + " blocks";
    g.drawString(font, status, width - 12 - font.width(status), height - 22, 0xFFAAAAAA, false);
    if (!message.isEmpty())
      g.drawString(
          font, font.plainSubstrByWidth(message, width - 24), 12, height - 61, 0xFFFF9999, false);
  }
}
