package net.mcreator.climber.client.screens;

import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ValueEntryScreen extends Screen {
  private final Screen parent;
  private final String initial, hint;
  private final Consumer<String> accept;
  private EditBox value;
  private String error = "";

  public ValueEntryScreen(
      Screen parent, String title, String initial, String hint, Consumer<String> accept) {
    super(Component.literal(title));
    this.parent = parent;
    this.initial = initial;
    this.hint = hint;
    this.accept = accept;
  }

  @Override
  protected void init() {
    value = new EditBox(font, 20, height / 2 - 10, width - 40, 20, title);
    value.setMaxLength(1024);
    value.setValue(initial);
    addRenderableWidget(value);
    setInitialFocus(value);
    addRenderableWidget(
        Button.builder(Component.literal("Use value"), b -> save())
            .bounds(20, height / 2 + 18, 100, 20)
            .build());
    addRenderableWidget(
        Button.builder(Component.literal("Cancel"), b -> onClose())
            .bounds(130, height / 2 + 18, 100, 20)
            .build());
  }

  private void save() {
    try {
      accept.accept(value.getValue());
      minecraft.setScreen(parent);
    } catch (RuntimeException e) {
      error = e.getMessage();
    }
  }

  @Override
  public boolean keyPressed(int key, int scan, int mods) {
    if (key == 257 || key == 335) {
      save();
      return true;
    }
    return super.keyPressed(key, scan, mods);
  }

  @Override
  public void onClose() {
    minecraft.setScreen(parent);
  }

  @Override
  public void tick() {
    value.tick();
  }

  @Override
  public void render(GuiGraphics g, int x, int y, float p) {
    g.fill(0, 0, width, height, 0xFA0A0A0C);
    g.drawString(font, title, 20, 20, 0xFFE8C547);
    g.drawWordWrap(font, Component.literal(hint), 20, 42, width - 40, 0xFFAAAAAA);
    super.render(g, x, y, p);
    g.drawWordWrap(
        font,
        Component.literal(error == null ? "Invalid value" : error),
        20,
        height / 2 + 47,
        width - 40,
        0xFFFF9999);
  }
}
