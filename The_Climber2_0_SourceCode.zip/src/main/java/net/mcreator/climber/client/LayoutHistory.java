package net.mcreator.climber.client;

import com.google.gson.Gson;
import java.util.*;

/** Bounded snapshot history shared by dragging, numeric edits, imports and resets. */
public final class LayoutHistory {
  private final List<String> states = new ArrayList<>();
  private int cursor;

  public LayoutHistory(SettingsLayout initial) {
    states.add(json(initial));
  }

  private static String json(SettingsLayout s) {
    return new Gson().toJson(s);
  }

  public void commit(SettingsLayout s) {
    String next = json(s);
    if (next.equals(states.get(cursor))) return;
    while (states.size() > cursor + 1) states.remove(states.size() - 1);
    states.add(next);
    cursor++;
    if (states.size() > 101) {
      states.remove(0);
      cursor--;
    }
  }

  public boolean canUndo() {
    return cursor > 0;
  }

  public boolean canRedo() {
    return cursor + 1 < states.size();
  }

  public SettingsLayout undo() {
    if (canUndo()) cursor--;
    return value();
  }

  public SettingsLayout redo() {
    if (canRedo()) cursor++;
    return value();
  }

  private SettingsLayout value() {
    return new Gson().fromJson(states.get(cursor), SettingsLayout.class);
  }
}
