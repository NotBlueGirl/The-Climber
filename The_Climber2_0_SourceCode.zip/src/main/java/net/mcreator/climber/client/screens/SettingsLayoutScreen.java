package net.mcreator.climber.client.screens;

import com.google.gson.Gson;
import java.nio.file.*;
import java.util.*;
import net.mcreator.climber.client.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.*;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Element browser, draggable schematic canvas, numeric inspector and reversible JSON edits. */
public final class SettingsLayoutScreen extends Screen {
  private final Screen parent;

  private static SettingsLayout seeded(SettingsLayout s) {
    for (var id : SettingsLayout.controls()) s.element(id);
    return s;
  }

  private SettingsLayout draft = seeded(SettingsLayout.get().copy());
  private final LayoutHistory history = new LayoutHistory(draft);
  private String saved = new Gson().toJson(draft),
      selected = "Header",
      filter = "",
      message = "Select an element. Drag to move; arrows nudge. Ctrl+Z / Y undo / redo.";
  private final List<String> ids = SettingsLayout.controls();
  private List<String> filtered = ids;
  private EditBox search, label, xBox, yBox, scaleBox, spacingBox, colorBox;
  private int listScroll, inspectorScroll, view;
  private int lx, lw, px, py, pw, ph, ix, iw, bottom;
  private boolean compact, dragging, grid = true;
  private final List<AbstractWidget> inspector = new ArrayList<>();
  private final List<Caption> captions = new ArrayList<>();

  private record Caption(String text, int x, int y) {}

  public SettingsLayoutScreen(Screen parent) {
    super(Component.literal("Settings layout studio"));
    this.parent = parent;
  }

  private boolean dirty() {
    return !new Gson().toJson(draft).equals(saved);
  }

  private SettingsLayout.Element element() {
    return draft.element(selected);
  }

  private Button button(String text, int x, int y, int w, Runnable action) {
    return addRenderableWidget(new DebuggerActionButton(text, x, y, w, action));
  }

  private void rebuild() {
    clearWidgets();
    init();
  }

  @Override
  protected void init() {
    inspector.clear();
    captions.clear();
    label = null;
    compact = width < 590 || height < 325;
    bottom = height - 48;
    lx = 12;
    lw = 130;
    py = 86;
    ph = Math.max(65, bottom - py - 8);
    ix = width - 160;
    iw = 148;
    px = 154;
    pw = Math.max(80, ix - px - 12);
    button("Undo", 12, 42, 48, () -> undo(false)).active = history.canUndo();
    button("Redo", 64, 42, 48, () -> undo(true)).active = history.canRedo();
    button(
        grid ? "Snap: on" : "Snap: off",
        116,
        42,
        84,
        () -> {
          grid = !grid;
          rebuild();
        });
    button("Import JSON", 204, 42, 94, this::importJson);
    if (compact) {
      button(
          new String[] {"Preview >", "Properties >", "Elements >"}[view],
          width - 110,
          64,
          98,
          () -> {
            if (!applyFields()) return;
            view = (view + 1) % 3;
            rebuild();
          });
      lx = 12;
      lw = width - 24;
      px = 12;
      pw = width - 24;
      ix = 12;
      iw = width - 24;
      py = 91;
      ph = Math.max(50, bottom - py - 8);
    }
    if (!compact || view == 0) {
      search = new EditBox(font, lx, 86, lw, 18, Component.literal("Search elements"));
      search.setHint(Component.literal("Search elements..."));
      search.setMaxLength(48);
      search.setValue(filter);
      search.setResponder(
          v -> {
            filter = v;
            filtered =
                ids.stream()
                    .filter(id -> id.toLowerCase(Locale.ROOT).contains(v.toLowerCase(Locale.ROOT)))
                    .toList();
            listScroll = 0;
          });
      addRenderableWidget(search);
      filtered =
          ids.stream()
              .filter(id -> id.toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT)))
              .toList();
    } else search = null;
    if (!compact || view == 2) buildInspector();
    button("Save JSON", 12, height - 43, 92, this::save);
    button(
        "Reset all",
        110,
        height - 43,
        82,
        () ->
            minecraft.setScreen(
                new ConfirmScreen(
                    ok -> {
                      if (ok) {
                        draft = seeded(new SettingsLayout());
                        history.commit(draft);
                        message = "Original layout restored in draft.";
                      }
                      minecraft.setScreen(this);
                    },
                    Component.literal("Restore original Settings layout?"),
                    Component.literal("This can be undone. Save to apply."))));
    button("Close", width - 72, height - 43, 60, this::onClose);
  }

  private EditBox field(String title, String value, int x, int y, int w, int max) {
    captions.add(new Caption(title, x, y));
    var box = new EditBox(font, x, y + 11, w, 17, Component.literal(title));
    box.setMaxLength(max);
    box.setValue(value);
    addRenderableWidget(box);
    inspector.add(box);
    return box;
  }

  private String num(float v) {
    return String.format(Locale.ROOT, "%.3f", v);
  }

  private void buildInspector() {
    var e = element();
    int yy = 99 - inspectorScroll, half = (iw - 8) / 2;
    label = field("Label (blank = default)", e.label, ix, yy, iw, 40);
    xBox = field("X offset", num(e.x), ix, yy + 37, half, 12);
    yBox = field("Y offset", num(e.y), ix + half + 8, yy + 37, half, 12);
    scaleBox = field("Scale", num(e.scale), ix, yy + 74, half, 12);
    spacingBox = field("Row spacing", num(draft.rowSpacing), ix + half + 8, yy + 74, half, 12);
    colorBox = field("Accent #RRGGBB", draft.accent, ix, yy + 111, iw, 6);
    var vis =
        button(
            e.visible ? "Visible: yes" : "Visible: no",
            ix,
            yy + 148,
            iw,
            () -> {
              if (applyFields() && !Set.of(SettingsLayout.PARTS).contains(selected)) {
                element().visible = !element().visible;
                history.commit(draft);
                rebuild();
              }
            });
    inspector.add(vis);
    vis.active = !Set.of(SettingsLayout.PARTS).contains(selected);
    inspector.add(
        button(
            "Apply properties",
            ix,
            yy + 173,
            iw,
            () -> {
              if (applyFields()) rebuild();
            }));
    inspector.add(
        button(
            "Reset element",
            ix,
            yy + 198,
            iw,
            () -> {
              draft.elements.put(selected, new SettingsLayout.Element());
              history.commit(draft);
              message = "Element reset. Ctrl+Z to undo.";
              rebuild();
            }));
    for (var widget : inspector)
      widget.visible = widget.getY() >= 91 && widget.getY() + widget.getHeight() <= bottom - 4;
  }

  private boolean pendingFields() {
    return label != null
        && (!label.getValue().equals(element().label)
            || !colorBox.getValue().equals(draft.accent)
            || !xBox.getValue().equals(num(element().x))
            || !yBox.getValue().equals(num(element().y))
            || !scaleBox.getValue().equals(num(element().scale))
            || !spacingBox.getValue().equals(num(draft.rowSpacing)));
  }

  private boolean applyFields() {
    if (label == null || compact && view != 2) return true;
    try {
      var next = draft.copy();
      var e = next.element(selected);
      e.label = label.getValue();
      e.x = Float.parseFloat(xBox.getValue());
      e.y = Float.parseFloat(yBox.getValue());
      e.scale = Float.parseFloat(scaleBox.getValue());
      next.rowSpacing = Float.parseFloat(spacingBox.getValue());
      next.accent = colorBox.getValue();
      next.validate();
      draft = next;
      history.commit(draft);
      return true;
    } catch (Exception ex) {
      message = "Invalid properties: " + ex.getMessage();
      return false;
    }
  }

  private void select(String id) {
    if (!applyFields()) return;
    selected = id;
    inspectorScroll = 0;
    message = "Selected " + id;
    rebuild();
  }

  private void undo(boolean redo) {
    draft = redo ? history.redo() : history.undo();
    message = redo ? "Redone." : "Undone.";
    rebuild();
  }

  private void save() {
    if (!applyFields()) return;
    try {
      SettingsLayout.save(draft);
      saved = new Gson().toJson(draft);
      message = "Saved locally: config/climber_settings_ui.json";
      rebuild();
    } catch (Exception e) {
      message = e.getMessage();
    }
  }

  private void importJson() {
    try {
      String file =
          org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog(
              "Import Settings layout JSON", "", null, "JSON files", false);
      if (file == null) return;
      Path path = Path.of(file);
      if (!file.toLowerCase(Locale.ROOT).endsWith(".json") || Files.size(path) > 131072)
        throw new IllegalArgumentException("Choose a JSON file smaller than 128 KB");
      SettingsLayout next = new Gson().fromJson(Files.readString(path), SettingsLayout.class);
      if (next == null) throw new IllegalArgumentException("Empty JSON");
      next.validate();
      draft = seeded(next);
      history.commit(draft);
      message = "Imported draft. Save JSON to apply; Ctrl+Z to undo.";
      rebuild();
    } catch (Exception e) {
      message = "Import failed: " + e.getMessage();
    }
  }

  private String category(String row) {
    int n = ids.indexOf(row);
    if (row.equals("row:DoorPhysics")
        || row.matches(
            "row:(RebarKnockback|MaxTimeCrackLight|ClickCrankRegen|ClimberGravity|RopeSwingStrenght|DoorHitbox(?:Pos)?[XYZ])"))
      return "Gameplay";
    if (n >= ids.indexOf("row:Grab-hit file")) return "Sounds";
    if (n >= ids.indexOf("row:Include blocks")) return "Block lists";
    if (n >= ids.indexOf("row:Hand X")) return "Hand position";
    if (n >= ids.indexOf("row:Stamina")) return "Stamina";
    return "Climbing";
  }

  private String previewTab() {
    return selected.startsWith("tab:")
        ? selected.substring(4)
        : selected.startsWith("row:") ? category(selected) : "Climbing";
  }

  private List<String> previewIds() {
    var result = new ArrayList<String>();
    result.add("Header");
    result.add("Tabs");
    result.add("Panel");
    ids.stream().filter(id -> id.startsWith("tab:")).forEach(result::add);
    ids.stream()
        .filter(id -> id.startsWith("row:") && category(id).equals(previewTab()))
        .forEach(result::add);
    return result;
  }

  private float[] rect(String id) {
    var e = draft.element(id);
    float x = px, y = py, w = pw * .55f, h = 12;
    if (id.equals("Header")) {
      x += pw * .05f;
      y += ph * .06f;
      w = pw * .85f;
      h = 20;
    } else if (id.equals("Tabs") || id.startsWith("tab:")) {
      var parent = draft.element("Tabs");
      float parentScale = id.equals("Tabs") ? 1 : parent.scale;
      x += pw * .05f;
      y += ph * .27f;
      w = pw * .26f;
      h = ph * .65f;
      if (id.startsWith("tab:")) {
        var tabs = ids.stream().filter(v -> v.startsWith("tab:")).toList();
        x += parent.x * pw;
        y += parent.y * ph + tabs.indexOf(id) * ph * .085f * parent.scale;
        h = ph * .08f;
      }
      w *= parentScale;
      h *= parentScale;
    } else {
      var parent = draft.element("Panel");
      x += pw * .37f;
      y += ph * .27f;
      w = pw * .58f;
      h = ph * .65f;
      if (id.startsWith("row:")) {
        var rows =
            ids.stream()
                .filter(v -> v.startsWith("row:") && category(v).equals(previewTab()))
                .toList();
        int n = rows.indexOf(id), chosen = rows.indexOf(selected);
        int start = Math.max(0, chosen - 4);
        x += parent.x * pw;
        y +=
            parent.y * ph
                + (n - start) * Math.min(ph * .12f, draft.rowSpacing * ph / 220) * parent.scale;
        h = ph * .10f;
        w *= parent.scale;
      }
    }
    return new float[] {x + e.x * pw, y + e.y * ph, w * e.scale, h * e.scale};
  }

  private boolean hit(float[] r, double x, double y) {
    return x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
  }

  private boolean canvas(double x, double y) {
    return (!compact || view == 1) && x >= px && x < px + pw && y >= py && y < py + ph;
  }

  @Override
  public boolean mouseClicked(double x, double y, int b) {
    if (super.mouseClicked(x, y, b)) return true;
    if (b != 0) return false;
    if ((!compact || view == 0) && x >= lx && x < lx + lw && y >= 110 && y < bottom - 8) {
      int n = listScroll + (int) ((y - 110) / 18);
      if (n < filtered.size()) select(filtered.get(n));
      return true;
    }
    if (canvas(x, y)) {
      var visible = previewIds();
      String pick = null;
      // Prefer small controls over container rectangles, but allow dragging the selected container.
      for (int i = visible.size() - 1; i >= 0; i--)
        if (hit(rect(visible.get(i)), x, y)) {
          pick = visible.get(i);
          break;
        }
      if (Set.of(SettingsLayout.PARTS).contains(selected) && hit(rect(selected), x, y))
        pick = selected;
      if (pick != null) {
        if (!pick.equals(selected)) select(pick);
        if (!applyFields()) return true;
        setFocused(null);
        dragging = true;
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean mouseDragged(double x, double y, int b, double dx, double dy) {
    if (dragging && b == 0) {
      var e = element();
      e.x = clamp(e.x + (float) (dx / pw), -.7f, .7f);
      e.y = clamp(e.y + (float) (dy / ph), -.7f, .7f);
      return true;
    }
    return super.mouseDragged(x, y, b, dx, dy);
  }

  private float clamp(float v, float a, float b) {
    return Math.max(a, Math.min(b, v));
  }

  @Override
  public boolean mouseReleased(double x, double y, int b) {
    if (dragging) {
      dragging = false;
      if (grid) {
        element().x = Math.round(element().x * 100) / 100f;
        element().y = Math.round(element().y * 100) / 100f;
      }
      history.commit(draft);
      rebuild();
      return true;
    }
    return super.mouseReleased(x, y, b);
  }

  @Override
  public boolean mouseScrolled(double x, double y, double d) {
    if ((!compact || view == 0) && x >= lx && x < lx + lw) {
      listScroll =
          Math.max(
              0,
              Math.min(
                  Math.max(0, filtered.size() - (bottom - 118) / 18),
                  listScroll + (d < 0 ? 2 : -2)));
      return true;
    }
    if ((!compact || view == 2) && x >= ix) {
      if (!applyFields()) return true;
      inspectorScroll =
          Math.max(
              0, Math.min(Math.max(0, 323 - bottom + 16), inspectorScroll + (d < 0 ? 24 : -24)));
      rebuild();
      return true;
    }
    if (canvas(x, y)) {
      if (!applyFields()) return true;
      element().scale = clamp(element().scale + (d > 0 ? .05f : -.05f), .5f, 2);
      history.commit(draft);
      rebuild();
      return true;
    }
    return super.mouseScrolled(x, y, d);
  }

  @Override
  public boolean keyPressed(int key, int scan, int modifiers) {
    if (hasControlDown() && key == GLFW.GLFW_KEY_S) {
      save();
      return true;
    }
    if (hasControlDown() && key == GLFW.GLFW_KEY_Z) {
      undo(hasShiftDown());
      return true;
    }
    if (hasControlDown() && key == GLFW.GLFW_KEY_Y) {
      undo(true);
      return true;
    }
    if (key == GLFW.GLFW_KEY_ENTER && getFocused() instanceof EditBox) {
      if (applyFields()) rebuild();
      return true;
    }
    if (!(getFocused() instanceof EditBox)
        && (key >= GLFW.GLFW_KEY_RIGHT && key <= GLFW.GLFW_KEY_UP)) {
      float step = hasShiftDown() ? .05f : .01f;
      var e = element();
      e.x =
          clamp(
              e.x + (key == GLFW.GLFW_KEY_LEFT ? -step : key == GLFW.GLFW_KEY_RIGHT ? step : 0),
              -.7f,
              .7f);
      e.y =
          clamp(
              e.y + (key == GLFW.GLFW_KEY_UP ? -step : key == GLFW.GLFW_KEY_DOWN ? step : 0),
              -.7f,
              .7f);
      history.commit(draft);
      rebuild();
      return true;
    }
    return super.keyPressed(key, scan, modifiers);
  }

  @Override
  public void tick() {
    for (var child : children()) if (child instanceof EditBox box) box.tick();
  }

  @Override
  public void onClose() {
    if (dirty() || pendingFields())
      minecraft.setScreen(
          new ConfirmScreen(
              ok -> minecraft.setScreen(ok ? parent : this),
              Component.literal("Discard unsaved layout edits?"),
              Component.literal("Save JSON applies your local layout."),
              Component.literal("Discard"),
              Component.literal("Keep editing")));
    else minecraft.setScreen(parent);
  }

  private void text(GuiGraphics g, String text, int x, int y, int max, int color) {
    g.drawString(font, font.plainSubstrByWidth(text, Math.max(0, max)), x, y, color, false);
  }

  private void preview(GuiGraphics g) {
    g.fill(px, py, px + pw, py + ph, 0xFF090D10);
    g.enableScissor(px, py, px + pw, py + ph);
    for (int yy = py; yy < py + ph; yy += 3) g.fill(px, yy, px + pw, yy + 1, 0x08FFFFFF);
    for (var id : previewIds()) {
      var e = draft.element(id);
      var r = rect(id);
      if (!e.visible) continue;
      if (id.equals("Tabs") || id.equals("Panel")) {
        if (id.equals(selected))
          g.renderOutline((int) r[0], (int) r[1], (int) r[2], (int) r[3], 0x665E9FE8);
        continue;
      }
      String fallback =
          id.equals("Header") ? "THE CLIMBER" : id.substring(4).toUpperCase(Locale.ROOT);
      float fontScale =
          (id.equals("Header") ? Math.min(1.6f, pw / 165f) : Math.min(1, pw / 390f)) * e.scale;
      g.pose().pushPose();
      g.pose().translate(r[0], r[1], 0);
      g.pose().scale(fontScale, fontScale, 1);
      g.drawString(
          font,
          draft.label(id, fallback),
          0,
          0,
          id.equals("Header") || id.equals("tab:" + previewTab()) ? draft.color() : 0xFFADB7C0,
          false);
      g.pose().popPose();
    }
    var r = rect(selected);
    g.renderOutline(
        (int) r[0] - 2,
        (int) r[1] - 2,
        Math.max(4, (int) r[2] + 4),
        Math.max(4, (int) r[3] + 4),
        0xFF70B7F0);
    g.disableScissor();
  }

  @Override
  public void render(GuiGraphics g, int mx, int my, float partial) {
    g.fill(0, 0, width, height, 0xFF10161C);
    text(g, "SETTINGS / LAYOUT STUDIO" + (dirty() ? " *" : ""), 12, 12, width - 24, 0xFFD6DDE2);
    text(
        g,
        "Local appearance only. Original Settings theme is preserved.",
        12,
        27,
        width - 24,
        0xFF8899A6);
    if (!compact || view == 0) {
      text(g, "ELEMENTS / " + filtered.size(), lx, 72, lw, 0xFF70B7F0);
      g.fill(lx + lw + 5, 70, lx + lw + 6, bottom - 8, 0xFF26343E);
      g.enableScissor(lx, 109, lx + lw, bottom - 8);
      int rows = Math.max(0, (bottom - 118) / 18);
      for (int i = 0; i < rows && i + listScroll < filtered.size(); i++) {
        String id = filtered.get(i + listScroll);
        int yy = 110 + i * 18;
        if (id.equals(selected)) {
          g.fill(lx, yy - 2, lx + lw, yy + 14, 0x182783DE);
          g.fill(lx, yy - 2, lx + 2, yy + 14, 0xFF70B7F0);
        }
        text(g, id, lx + 6, yy + 2, lw - 8, id.equals(selected) ? 0xFF70B7F0 : 0xFFB3BDC6);
      }
      g.disableScissor();
    }
    if (!compact || view == 1) {
      text(g, "SCHEMATIC / " + previewTab(), px, 72, pw - (compact ? 105 : 0), 0xFF70B7F0);
      preview(g);
    }
    if (!compact || view == 2) {
      text(g, "PROPERTIES / WHEEL", ix, 72, iw - (compact ? 105 : 0), 0xFF70B7F0);
      g.enableScissor(ix, 91, ix + iw, bottom - 4);
      for (var cap : captions)
        if (cap.y >= 91 && cap.y + 28 <= bottom - 4)
          text(g, cap.text, cap.x, cap.y, iw, 0xFF8899A6);
      g.disableScissor();
    }
    g.fill(12, bottom, width - 12, bottom + 1, 0xFF26343E);
    super.render(g, mx, my, partial);
    text(g, message, 12, height - 17, width - 24, 0xFF9AAAB6);
  }
}
