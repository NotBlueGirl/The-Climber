package net.mcreator.climber.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.mcreator.climber.entity.ThrownBrickEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;

/** Tumbling 3D brick in flight. */
public class ThrownBrickRenderer extends EntityRenderer<ThrownBrickEntity> {
    private final ItemRenderer itemRenderer;

    public ThrownBrickRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.itemRenderer = ctx.getItemRenderer();
        this.shadowRadius = 0.15f;
    }

    @Override
    public void render(ThrownBrickEntity e, float yaw, float partialTick, PoseStack pose, MultiBufferSource buf, int light) {
        if (e.tickCount < 2 && entityRenderDispatcher.camera.getEntity().distanceToSqr(e) < 12.25) return;
        pose.pushPose();
        pose.translate(0, 0.12, 0);
        pose.mulPose(Axis.YP.rotationDegrees(-e.getYRot()));
        float t = e.tickCount + partialTick;
        pose.mulPose(Axis.XP.rotationDegrees(t * 24f));
        pose.mulPose(Axis.ZP.rotationDegrees(t * 9f));
        pose.scale(0.6f, 0.6f, 0.6f);
        itemRenderer.renderStatic(e.getItem(), ItemDisplayContext.FIXED, light, OverlayTexture.NO_OVERLAY, pose, buf, e.level(), e.getId());
        pose.popPose();
        super.render(e, yaw, partialTick, pose, buf, light);
    }

    @Override
    @SuppressWarnings("deprecation")
    public ResourceLocation getTextureLocation(ThrownBrickEntity e) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
