package net.mcreator.climber.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.mcreator.climber.client.model.MechanismModels;
import net.mcreator.climber.mechanism.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Quaternionf;

/** Real textured mesh assets; rope and rails follow their actual world endpoints. */
public class MechanismRenderer extends EntityRenderer<MechanismEntity> {
  public MechanismRenderer(EntityRendererProvider.Context context) {
    super(context);
    shadowRadius = 0;
  }

  @Override
  public ResourceLocation getTextureLocation(MechanismEntity e) {
    return MechanismModels.TEXTURE;
  }

  @Override
  public void render(
      MechanismEntity e,
      float yaw,
      float partial,
      PoseStack p,
      MultiBufferSource buffers,
      int light) {
    MechanismSpec s = e.spec();
    p.pushPose();
    if (e.isChild()) {
      Vec3 own =
          new Vec3(
              net.minecraft.util.Mth.lerp(partial, e.xo, e.getX()),
              net.minecraft.util.Mth.lerp(partial, e.yo, e.getY()),
              net.minecraft.util.Mth.lerp(partial, e.zo, e.getZ()));
      Vec3 correction = e.renderPosition(partial).subtract(own);
      p.translate(correction.x, correction.y, correction.z);
    }
    if (s.kind == MechanismSpec.Kind.ROPE) {
      var points = e.ropePoints(partial);
      Vec3 renderOrigin =
          new Vec3(
              net.minecraft.util.Mth.lerp(partial, e.xo, e.getX()),
              net.minecraft.util.Mth.lerp(partial, e.yo, e.getY()),
              net.minecraft.util.Mth.lerp(partial, e.zo, e.getZ()));
      for (int i = 1; i < points.size(); i++)
        repeat(
            "rope_link",
            p,
            buffers,
            points.get(i - 1).subtract(renderOrigin),
            points.get(i).subtract(renderOrigin),
            light);
      p.pushPose();
      Vec3 end = points.get(points.size() - 1).subtract(renderOrigin);
      p.translate(end.x, end.y, end.z);
      MechanismModels.draw("rope_end", p, buffers, light);
      p.popPose();
      Vec3 ceiling = e.ceiling().subtract(renderOrigin);
      p.translate(ceiling.x, ceiling.y, ceiling.z);
      MechanismModels.draw("rope_anchor", p, buffers, light);
    } else {
      p.mulPose(Axis.YP.rotationDegrees(-e.face().toYRot()));
      switch (s.kind) {
        case HOOK -> MechanismModels.draw("climbing_hook", p, buffers, light);
        case WEAK_HOOK -> MechanismModels.draw("weak_climbing_hook", p, buffers, light);
        case VALVE -> {
          MechanismModels.draw("valve_base", p, buffers, light);
          p.translate(0, .15, .12);
          p.mulPose(Axis.ZP.rotationDegrees((float) (e.progress() / s.valveMax * 360)));
          MechanismModels.draw("valve_wheel", p, buffers, light);
        }
        case PLATFORM -> MechanismModels.draw("platform", p, buffers, light);
        default -> {}
      }
    }
    p.popPose();
    if (s.kind == MechanismSpec.Kind.PLATFORM) {
      Vec3 renderOrigin =
          new Vec3(
              net.minecraft.util.Mth.lerp(partial, e.xo, e.getX()),
              net.minecraft.util.Mth.lerp(partial, e.yo, e.getY()),
              net.minecraft.util.Mth.lerp(partial, e.zo, e.getZ()));
      Vec3 normal = new Vec3(e.face().getStepX(), 0, e.face().getStepZ());
      for (var track :
          net.mcreator.climber.mechanism.PlatformRails.tracks(e.origin(), e.face(), s.route()))
        for (int i = 1; i < track.size(); i++)
          repeat(
              "rail_segment",
              p,
              buffers,
              track.get(i - 1).subtract(renderOrigin),
              track.get(i).subtract(renderOrigin),
              light,
              normal);
    }
    super.render(e, yaw, partial, p, buffers, light);
  }

  public static void repeat(
      String model, PoseStack p, MultiBufferSource buffers, Vec3 from, Vec3 to, int light) {
    repeat(model, p, buffers, from, to, light, null);
  }

  private static void repeat(
      String model,
      PoseStack p,
      MultiBufferSource buffers,
      Vec3 from,
      Vec3 to,
      int light,
      Vec3 front) {
    Vec3 d = to.subtract(from);
    double length = d.length();
    if (length < 1e-6) return;
    Vec3 n = d.scale(1 / length);
    p.pushPose();
    p.translate(from.x, from.y, from.z);
    if (front == null || Math.abs(front.dot(n)) > .999) {
      p.mulPose(new Quaternionf().rotationTo(0, 1, 0, (float) n.x, (float) n.y, (float) n.z));
    } else {
      Vec3 z = front.subtract(n.scale(front.dot(n))).normalize();
      Vec3 x = n.cross(z).normalize();
      p.mulPose(
          new Quaternionf()
              .setFromNormalized(
                  new Matrix3f(
                      (float) x.x,
                      (float) x.y,
                      (float) x.z,
                      (float) n.x,
                      (float) n.y,
                      (float) n.z,
                      (float) z.x,
                      (float) z.y,
                      (float) z.z)));
    }
    // Exact final partial segment; no gaps or overshoot at the anchor/path endpoint.
    for (double y = 0; y < length - 1e-6; y += .5) {
      p.pushPose();
      p.translate(0, y, 0);
      p.scale(1, (float) (Math.min(.5, length - y) / .5), 1);
      MechanismModels.draw(model, p, buffers, light);
      p.popPose();
    }
    p.popPose();
  }
}
