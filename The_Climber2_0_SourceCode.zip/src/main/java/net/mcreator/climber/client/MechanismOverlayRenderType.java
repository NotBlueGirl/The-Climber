package net.mcreator.climber.client;

import com.mojang.blaze3d.vertex.*;
import java.util.OptionalDouble;
import net.minecraft.client.renderer.RenderType;

/** Camera-mode authoring guides remain visible through the selected support blocks. */
public final class MechanismOverlayRenderType extends RenderType {
  private MechanismOverlayRenderType() {
    super(
        "climber_guide_dummy",
        DefaultVertexFormat.POSITION_COLOR_NORMAL,
        VertexFormat.Mode.LINES,
        256,
        false,
        false,
        () -> {},
        () -> {});
  }

  public static final RenderType GUIDES =
      create(
          "climber_camera_guides",
          DefaultVertexFormat.POSITION_COLOR_NORMAL,
          VertexFormat.Mode.LINES,
          256,
          false,
          false,
          CompositeState.builder()
              .setShaderState(RENDERTYPE_LINES_SHADER)
              .setLineState(new LineStateShard(OptionalDouble.of(2)))
              .setLayeringState(VIEW_OFFSET_Z_LAYERING)
              .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
              .setDepthTestState(NO_DEPTH_TEST)
              .setWriteMaskState(COLOR_WRITE)
              .setCullState(NO_CULL)
              .createCompositeState(false));
}
