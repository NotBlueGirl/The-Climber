package net.mcreator.climber.client.screens;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.*;
import java.util.function.Consumer;
import net.mcreator.climber.mechanism.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;
import org.lwjgl.glfw.GLFW;

/** Detached, client-only authoring camera. It never moves or changes game mode of the player. */
public final class MechanismCameraScreen extends Screen {
  public final boolean valve;
  public final MechanismEntity source;
  public final MechanismSpec draft;
  private final Screen parent;
  private final Consumer<MechanismSpec> accept;
  private final List<BlockPos> selected = new ArrayList<>();
  private Entity oldCamera;
  private CameraBody camera;
  private Vec3 start;
  private String message = "";

  public MechanismCameraScreen(
      Screen parent,
      MechanismSpec spec,
      MechanismEntity source,
      boolean valve,
      Consumer<MechanismSpec> accept) {
    super(Component.literal(valve ? "Select valve target" : "Select rail blocks"));
    this.parent = parent;
    this.source = source;
    this.valve = valve;
    this.accept = accept;
    draft = MechanismSpec.load(spec.save());
    if (!valve) selected.addAll(draft.railBlocks);
    else if (draft.valveTarget != null) selected.add(draft.valveTarget);
  }

  @Override
  protected void init() {
    if (minecraft.player == null || minecraft.level == null) return;
    if (camera == null) {
      oldCamera = minecraft.getCameraEntity();
      camera = new CameraBody(minecraft.level);
      start = minecraft.player.getEyePosition();
      camera.setPos(start);
      camera.setYRot(minecraft.player.getYRot());
      camera.setXRot(minecraft.player.getXRot());
      camera.xo = camera.getX();
      camera.yo = camera.getY();
      camera.zo = camera.getZ();
      minecraft.setCameraEntity(camera);
    }
    addRenderableWidget(new DebuggerActionButton("Confirm", 12, height - 31, 80, this::confirm));
    addRenderableWidget(
        new DebuggerActionButton(
            "Undo",
            100,
            height - 31,
            60,
            () -> {
              if (!selected.isEmpty()) selected.remove(selected.size() - 1);
            }));
    if (!valve)
      addRenderableWidget(
          new DebuggerActionButton(
              "Curve: " + (draft.curved ? "on" : "off"),
              166,
              height - 31,
              100,
              () -> {
                draft.curved = !draft.curved;
                clearWidgets();
                init();
              }));
    addRenderableWidget(
        new DebuggerActionButton("Cancel / Esc", width - 110, height - 31, 100, this::onClose));
  }

  public List<BlockPos> selected() {
    return List.copyOf(selected);
  }

  public BlockHitResult aimed() {
    if (camera == null) return null;
    var hit = camera.pick(48, 1, false);
    return hit instanceof BlockHitResult b && hit.getType() == HitResult.Type.BLOCK ? b : null;
  }

  @Override
  public boolean mouseClicked(double x, double y, int button) {
    if (super.mouseClicked(x, y, button)) return true;
    if (button == 0) {
      var hit = aimed();
      if (hit != null) {
        var b = hit.getBlockPos();
        if (valve) {
          selected.clear();
          selected.add(b);
        } else if (selected.size() < 32 && !selected.contains(b)) selected.add(b);
        message = "";
      }
      return true;
    }
    return button == 1;
  }

  @Override
  public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
    if (button == 1 && camera != null) {
      camera.setYRot(camera.getYRot() + (float) dx * .6f);
      camera.setXRot(Math.max(-89, Math.min(89, camera.getXRot() + (float) dy * .6f)));
      return true;
    }
    return super.mouseDragged(x, y, button, dx, dy);
  }

  private boolean down(int key) {
    return InputConstants.isKeyDown(minecraft.getWindow().getWindow(), key);
  }

  @Override
  public void tick() {
    if (minecraft.player == null || minecraft.level == null) {
      onClose();
      return;
    }
    if (camera == null) return;
    Vec3 forward = Vec3.directionFromRotation(0, camera.getYRot()),
        right = new Vec3(-forward.z, 0, forward.x);
    Vec3 delta = Vec3.ZERO;
    if (down(GLFW.GLFW_KEY_W)) delta = delta.add(forward);
    if (down(GLFW.GLFW_KEY_S)) delta = delta.subtract(forward);
    if (down(GLFW.GLFW_KEY_D)) delta = delta.add(right);
    if (down(GLFW.GLFW_KEY_A)) delta = delta.subtract(right);
    if (down(GLFW.GLFW_KEY_SPACE)) delta = delta.add(0, 1, 0);
    if (down(GLFW.GLFW_KEY_LEFT_CONTROL)) delta = delta.add(0, -1, 0);
    camera.xo = camera.getX();
    camera.yo = camera.getY();
    camera.zo = camera.getZ();
    camera.yRotO = camera.getYRot();
    camera.xRotO = camera.getXRot();
    if (delta.lengthSqr() > 0) {
      Vec3 next =
          camera.position().add(delta.normalize().scale(down(GLFW.GLFW_KEY_LEFT_SHIFT) ? .8 : .25));
      if (next.distanceTo(start) <= 48) camera.setPos(next);
    }
  }

  private void confirm() {
    try {
      if (valve) {
        if (selected.size() != 1) throw new IllegalArgumentException("Select a target block");
        draft.valveTarget = selected.get(0);
      } else draft.selectRailBlocks(selected);
      draft.validate();
      restore();
      accept.accept(draft);
      minecraft.setScreen(parent);
    } catch (RuntimeException e) {
      message = e.getMessage();
    }
  }

  private void restore() {
    if (camera != null && minecraft.getCameraEntity() == camera)
      minecraft.setCameraEntity(
          oldCamera != null && oldCamera.isAlive() ? oldCamera : minecraft.player);
  }

  @Override
  public void removed() {
    restore();
  }

  @Override
  public void onClose() {
    restore();
    minecraft.setScreen(minecraft.player == null ? null : parent);
  }

  @Override
  public boolean isPauseScreen() {
    return false;
  }

  @Override
  public void render(GuiGraphics g, int x, int y, float partial) {
    g.fill(0, 0, width, 56, 0xD910151B);
    g.fill(0, height - 54, width, height, 0xD910151B);
    g.drawString(
        font,
        valve ? "CAMERA  /  VALVE TARGET" : "CAMERA  /  PLATFORM RAIL ROUTE",
        12,
        10,
        0x70B7F0,
        false);
    g.drawString(font, "WASD move | Space/Ctrl height | RMB-drag look", 12, 25, 0xD6DDE2, false);
    g.drawString(font, "LMB selects the block at + | Esc cancels", 12, 39, 0xD6DDE2, false);
    g.drawCenteredString(font, "+", width / 2, height / 2 - 4, 0xFFFFFF);
    String status =
        message.isEmpty()
            ? (valve
                ? "Blue: target  Red: valve  Yellow: link"
                : "Selected " + selected.size() + " / 32  | First block = placement block")
            : message;
    g.drawString(
        font,
        font.plainSubstrByWidth(status, width - 24),
        12,
        height - 49,
        message.isEmpty() ? 0xD6DDE2 : 0xF0B46C,
        false);
    super.render(g, x, y, partial);
  }

  private static final class CameraBody extends Entity {
    CameraBody(Level level) {
      super(EntityType.MARKER, level);
    }

    @Override
    protected void defineSynchedData() {}

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {}

    @Override
    public boolean isSpectator() {
      return true;
    }
  }
}
