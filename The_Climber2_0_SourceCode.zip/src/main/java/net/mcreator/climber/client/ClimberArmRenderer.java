package net.mcreator.climber.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.IdentityHashMap;
import java.util.Map;
import net.mcreator.climber.ClimberConfig;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@OnlyIn(Dist.CLIENT)
public class ClimberArmRenderer {

  // -----------------------------------------------------------------
  // World-space pinned-arm render (third-person / other players)
  // -----------------------------------------------------------------

  @SubscribeEvent
  public void onRenderWorld(RenderLevelStageEvent event) {
    if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
    Minecraft mc = Minecraft.getInstance();
    if (mc.level == null) return;

    Camera camera = mc.gameRenderer.getMainCamera();
    Vec3 camPos = camera.getPosition();
    PoseStack ps = event.getPoseStack();
    MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();

    ClimberClientData.REMOTE_STATES.keySet().removeIf(id -> mc.level.getPlayerByUUID(id) == null);

    for (Player p : mc.level.players()) {
      if (!(p instanceof AbstractClientPlayer player)) continue;
      if (player == mc.player
          && mc.screen instanceof net.mcreator.climber.client.screens.MechanismCameraScreen)
        continue;

      ClimberClientData.RemoteClimbState state = ClimberClientData.getState(player);
      if (state == null || !state.climbEnabled) continue;

      Vec3 shoulder = player.position().add(0, player.getEyeHeight() * 0.5, 0);

      if (state.rightGrabbing && state.rightAnchor != null) {
        if (state.rightAnchorDir == null) {
          Vec3 toShoulder = shoulder.subtract(state.rightAnchor);
          double len = toShoulder.length();
          state.rightAnchorDir = len > 0.001 ? toShoulder.scale(1.0 / len) : new Vec3(0, 1, 0);
        }
        renderPinnedHand(
            ps,
            buf,
            mc,
            camPos,
            player,
            state.rightAnchor,
            state.rightAnchorDir,
            HumanoidArm.RIGHT,
            state);
      }

      if (state.leftGrabbing && state.leftAnchor != null) {
        if (state.leftAnchorDir == null) {
          Vec3 toShoulder = shoulder.subtract(state.leftAnchor);
          double len = toShoulder.length();
          state.leftAnchorDir = len > 0.001 ? toShoulder.scale(1.0 / len) : new Vec3(0, 1, 0);
        }
        renderPinnedHand(
            ps,
            buf,
            mc,
            camPos,
            player,
            state.leftAnchor,
            state.leftAnchorDir,
            HumanoidArm.LEFT,
            state);
      }
    }
  }

  private void renderPinnedHand(
      PoseStack ps,
      MultiBufferSource buf,
      Minecraft mc,
      Vec3 camPos,
      AbstractClientPlayer player,
      Vec3 anchor,
      Vec3 frozenDir,
      HumanoidArm arm,
      ClimberClientData.RemoteClimbState state) {
    ps.pushPose();
    Vec3 shoulderRenderPos = anchor.add(frozenDir.scale(0.75));
    ps.translate(
        shoulderRenderPos.x - camPos.x,
        shoulderRenderPos.y - camPos.y,
        shoulderRenderPos.z - camPos.z);

    Vec3 down = frozenDir.scale(-1);
    float yaw = (float) Math.toDegrees(Math.atan2(down.x, down.z));
    float pitch = (float) Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, -down.y))));
    ps.mulPose(Axis.YP.rotationDegrees(yaw));
    ps.mulPose(Axis.XP.rotationDegrees(pitch + 90f));

    var renderer =
        (net.minecraft.client.renderer.entity.player.PlayerRenderer)
            mc.getEntityRenderDispatcher().getRenderer(player);
    var model = renderer.getModel();
    model.setupAnim(player, 0, 0, 0, 0, 0);

    // Save visibility
    boolean headVisible = model.head.visible;
    boolean hatVisible = model.hat.visible;
    boolean bodyVisible = model.body.visible;
    boolean rightLegVisible = model.rightLeg.visible;
    boolean leftLegVisible = model.leftLeg.visible;
    boolean rightArmVisible = model.rightArm.visible;
    boolean leftArmVisible = model.leftArm.visible;
    boolean rightSleeveVisible = model.rightSleeve.visible;
    boolean leftSleeveVisible = model.leftSleeve.visible;

    boolean isRight = (arm == HumanoidArm.RIGHT);

    float blush = ClimberClientData.getBlushFactor(state, isRight);
    int overlay = blush > 0.01f ? OverlayTexture.pack(0, true) : OverlayTexture.NO_OVERLAY;
    int brightLight = 15728880;
    int light = blush > 0.5f ? (int) (brightLight * (1f - blush * 0.3f)) : brightLight;

    VertexConsumer vcSolid = buf.getBuffer(RenderType.entitySolid(player.getSkinTextureLocation()));
    VertexConsumer vcCutout =
        buf.getBuffer(RenderType.entityCutoutNoCull(player.getSkinTextureLocation()));

    if (isRight) {
      hideAllExcept(model, true);
      model.rightArm.render(ps, vcSolid, light, overlay);
      model.rightSleeve.visible = true;
      model.rightSleeve.render(ps, vcCutout, light, overlay);
    } else {
      hideAllExcept(model, false);
      model.leftArm.render(ps, vcSolid, light, overlay);
      model.leftSleeve.visible = true;
      model.leftSleeve.render(ps, vcCutout, light, overlay);
    }

    // Restore
    model.head.visible = headVisible;
    model.hat.visible = hatVisible;
    model.body.visible = bodyVisible;
    model.rightLeg.visible = rightLegVisible;
    model.leftLeg.visible = leftLegVisible;
    model.rightArm.visible = rightArmVisible;
    model.leftArm.visible = leftArmVisible;
    model.rightSleeve.visible = rightSleeveVisible;
    model.leftSleeve.visible = leftSleeveVisible;

    ps.popPose();
  }

  // -----------------------------------------------------------------
  // Hide pinned arms from normal player renderer
  // -----------------------------------------------------------------

  private final Map<Player, ItemStack> suppressedMainItems = new IdentityHashMap<>();
  private final Map<Player, ItemStack> suppressedOffItems = new IdentityHashMap<>();

  @SubscribeEvent
  public void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
    Player player = event.getEntity();
    PlayerModel<?> model = event.getRenderer().getModel();

    ClimberClientData.RemoteClimbState state = ClimberClientData.getState(player);
    if (state == null || !state.climbEnabled) return;

    if (state.rightGrabbing) {
      model.rightArm.visible = false;
      model.rightSleeve.visible = false;

      boolean rightIsMain = (player.getMainArm() == HumanoidArm.RIGHT);
      if (rightIsMain) {
        suppressedMainItems.putIfAbsent(player, player.getMainHandItem().copy());
        player.getInventory().items.set(player.getInventory().selected, ItemStack.EMPTY);
      } else {
        suppressedOffItems.putIfAbsent(player, player.getOffhandItem().copy());
        player.getInventory().offhand.set(0, ItemStack.EMPTY);
      }
    }
    if (state.leftGrabbing) {
      model.leftArm.visible = false;
      model.leftSleeve.visible = false;

      boolean leftIsMain = (player.getMainArm() == HumanoidArm.LEFT);
      if (leftIsMain) {
        suppressedMainItems.putIfAbsent(player, player.getMainHandItem().copy());
        player.getInventory().items.set(player.getInventory().selected, ItemStack.EMPTY);
      } else {
        suppressedOffItems.putIfAbsent(player, player.getOffhandItem().copy());
        player.getInventory().offhand.set(0, ItemStack.EMPTY);
      }
    }
  }

  private static boolean isVanilla(ItemStack st) {
    return !st.isEmpty() && !(st.getItem() instanceof net.mcreator.climber.item.ClimberTool);
  }

  @SubscribeEvent
  public void onRenderPlayerPost(RenderPlayerEvent.Post event) {
    Player player = event.getEntity();
    PlayerModel<?> model = event.getRenderer().getModel();

    model.rightArm.visible = true;
    model.leftArm.visible = true;
    model.rightSleeve.visible = true;
    model.leftSleeve.visible = true;

    if (suppressedMainItems.containsKey(player)) {
      player
          .getInventory()
          .items
          .set(player.getInventory().selected, suppressedMainItems.remove(player));
    }
    if (suppressedOffItems.containsKey(player)) {
      player.getInventory().offhand.set(0, suppressedOffItems.remove(player));
    }
  }

  // -----------------------------------------------------------------
  // First-person hand rendering
  // -----------------------------------------------------------------

  @SubscribeEvent(priority = EventPriority.HIGH)
  public void onRenderHand(RenderHandEvent event) {
    Minecraft mc = Minecraft.getInstance();
    if (mc.screen instanceof net.mcreator.climber.client.screens.MechanismCameraScreen) {
      event.setCanceled(true);
      return;
    }
    if (!ClimberClientData.climbEnabled) return;
    if (mc.player == null) return;

    boolean isRight =
        (event.getHand() == InteractionHand.MAIN_HAND)
            == (mc.player.getMainArm() == HumanoidArm.RIGHT);
    boolean grabbing = isRight ? ClimberClientData.rightGrabbing : ClimberClientData.leftGrabbing;

    if (grabbing) {
      event.setCanceled(true);
      return;
    }

    // Other items keep the vanilla first-person view; the climber tools are drawn in the climber
    // arm's hand (at the end of the arm model).
    // In climber mode vanilla items are not shown at all (the arm looks empty).
    ItemStack held = event.getItemStack();

    PoseStack ps = event.getPoseStack();
    MultiBufferSource buf = event.getMultiBufferSource();
    int light = event.getPackedLight();

    float baseSide = isRight ? 0.56f : -0.56f;
    float baseDown = -0.52f;
    float baseDepth = -0.72f;

    Vec3 offset = ClimberConfig.INSTANCE.getIdleHandPos();
    float offX = (float) offset.x * (isRight ? 1 : -1);
    float offY = (float) offset.y;
    float offZ = (float) offset.z;

    // camera-aligned base frame of the hand pass (x right, y up, -z forward)
    org.joml.Matrix4f basePose = new org.joml.Matrix4f(ps.last().pose());
    org.joml.Matrix3f baseNormal = new org.joml.Matrix3f(ps.last().normal());
    ps.pushPose();
    float side = isRight ? 1f : -1f;
    float equip = event.getEquipProgress();
    float swing = event.getSwingProgress();
    float sw = Mth.sin(Mth.sqrt(swing) * (float) Math.PI);
    ps.translate(baseSide + offX, baseDown + offY - equip * 0.6f, baseDepth + offZ);
    if (!held.isEmpty() && mc.player.isUsingItem() && mc.player.getUseItem() == held) {
      // cranking (flashlight) / aiming: small circular wobble of the whole arm
      float t = (mc.player.getTicksUsingItem() + event.getPartialTick()) * 0.8f;
      ps.translate(Mth.cos(t) * 0.025f * side, Mth.sin(t) * 0.025f, 0);
    }
    ps.mulPose(Axis.ZP.rotationDegrees(isRight ? -18f : 18f));
    ps.mulPose(Axis.XP.rotationDegrees(-35f - sw * 55f));
    ps.mulPose(Axis.YP.rotationDegrees(sw * 20f * side));

    var renderer =
        (net.minecraft.client.renderer.entity.player.PlayerRenderer)
            mc.getEntityRenderDispatcher().getRenderer(mc.player);
    var model = renderer.getModel();
    model.setupAnim(mc.player, 0, 0, 0, 0, 0);

    boolean exhausted =
        isRight ? ClimberClientData.rightExhausted : ClimberClientData.leftExhausted;
    int overlay = exhausted ? OverlayTexture.pack(0, true) : OverlayTexture.NO_OVERLAY;

    var vcSolid = buf.getBuffer(RenderType.entitySolid(mc.player.getSkinTextureLocation()));
    var vcCutout = buf.getBuffer(RenderType.entityCutoutNoCull(mc.player.getSkinTextureLocation()));

    if (isRight) {
      hideAllExcept(model, true);
      model.rightArm.render(ps, vcSolid, light, overlay);
      model.rightSleeve.visible = true;
      model.rightSleeve.render(ps, vcCutout, light, overlay);
      model.rightSleeve.visible = false;
    } else {
      hideAllExcept(model, false);
      model.leftArm.render(ps, vcSolid, light, overlay);
      model.leftSleeve.visible = true;
      model.leftSleeve.render(ps, vcCutout, light, overlay);
      model.leftSleeve.visible = false;
    }

    if (!held.isEmpty()
        && net.mcreator.climber.client.animation.AnimationClient.armAnimated(mc.player, isRight)) {
      ps.pushPose();
      (isRight ? model.rightArm : model.leftArm).translateAndRotate(ps);
      ps.translate(side * FIST_X / 16f, FIST_Y / 16f, FIST_Z / 16f);
      ItemDisplayOverrides.toTransform(ItemDisplayOverrides.climberValues(held, isRight))
          .apply(!isRight, ps);
      mc.getEntityRenderDispatcher()
          .getItemInHandRenderer()
          .renderItem(
              mc.player,
              held,
              net.minecraft.world.item.ItemDisplayContext.NONE,
              !isRight,
              ps,
              buf,
              light);
      ps.popPose();
    } else if (!held.isEmpty()) {
      // Held like in a real hand: the tool goes through the fist perpendicular to the forearm and
      // is oriented in camera space (hammer upright with its face forward, torch lens forward,
      // piton tip towards the wall, rebar ready to throw, brick resting on the fist).
      ps.pushPose();
      (isRight ? model.rightArm : model.leftArm).translateAndRotate(ps);
      org.joml.Vector3f fist =
          ps.last()
              .pose()
              .transformPosition(
                  side * FIST_X / 16f, FIST_Y / 16f, FIST_Z / 16f, new org.joml.Vector3f());
      ps.popPose();
      org.joml.Vector3f local = new org.joml.Matrix4f(basePose).invert().transformPosition(fist);
      ps.pushPose();
      ps.last().pose().set(basePose);
      ps.last().normal().set(baseNormal);
      ps.translate(local.x, local.y, local.z);
      boolean using = mc.player.isUsingItem() && mc.player.getUseItem() == held;
      float charge =
          using
              ? Mth.clamp((mc.player.getTicksUsingItem() + event.getPartialTick()) / 14f, 0f, 1f)
              : 0f;
      ps.mulPose(
          Axis.XP.rotationDegrees(-sw * 55f + charge * 30f)); // swing forward / pull back to charge
      // tool pose (debug-editable like a Blockbench display slot; left hand is mirrored)
      ItemDisplayOverrides.toTransform(ItemDisplayOverrides.climberValues(held, isRight))
          .apply(!isRight, ps);
      mc.getEntityRenderDispatcher()
          .getItemInHandRenderer()
          .renderItem(
              mc.player,
              held,
              net.minecraft.world.item.ItemDisplayContext.NONE,
              !isRight,
              ps,
              buf,
              light);
      ps.popPose();
    }

    ps.popPose();
    event.setCanceled(true);
  }

  /**
   * Default climber-arm pose of a tool as display values (rotation XYZ, translation px, scale),
   * converted from {@link HeldPose}. Left-hand values are stored un-mirrored like Blockbench does.
   */
  static float[] climberDefault(ItemStack st, boolean right) {
    HeldPose hp = HeldPose.of(st);
    float side = right ? 1f : -1f;
    org.joml.Quaternionf q =
        new org.joml.Quaternionf()
            .rotateZ((float) Math.toRadians(hp.lean * side))
            .rotateX((float) Math.toRadians(hp.pitch))
            .rotateY((float) Math.toRadians(hp.yaw + hp.yawSide * side));
    org.joml.Matrix3f m = q.get(new org.joml.Matrix3f());
    float ry = (float) Math.asin(Mth.clamp(m.m20, -1f, 1f));
    float rx = (float) Math.atan2(-m.m21, m.m22);
    float rz = (float) Math.atan2(-m.m10, m.m00);
    org.joml.Vector3f t =
        q.transform(
            new org.joml.Vector3f(-(hp.gx - 8f) / 16f, -(hp.gy - 8f) / 16f, -(hp.gz - 8f) / 16f)
                .mul(hp.scale));
    float[] v = {
      (float) Math.toDegrees(rx),
      (float) Math.toDegrees(ry),
      (float) Math.toDegrees(rz),
      t.x * 16f,
      t.y * 16f,
      t.z * 16f,
      hp.scale,
      hp.scale,
      hp.scale
    };
    if (!right) {
      v[1] = -v[1];
      v[2] = -v[2];
      v[3] = -v[3];
    } // ItemTransform.apply(left) mirrors back
    for (int i = 0; i < 9; i++) v[i] = Math.round(v[i] * 100f) / 100f;
    return v;
  }

  /** Fist centre in arm-part space (pixels). */
  static float FIST_X = -1f, FIST_Y = 8.5f, FIST_Z = 0f;

  /**
   * Camera-space hold of a tool: grip point on the model (px), lean towards the screen centre,
   * pitch (positive = top towards the camera), yaw, extra yaw mirrored per hand, scale.
   */
  record HeldPose(
      float gx,
      float gy,
      float gz,
      float lean,
      float pitch,
      float yaw,
      float yawSide,
      float scale) {
    static HeldPose of(ItemStack st) {
      var it = st.getItem();
      if (it instanceof net.mcreator.climber.item.HammerItem) return HAMMER;
      if (it instanceof net.mcreator.climber.item.RebarItem) return REBAR;
      if (it instanceof net.mcreator.climber.item.PitonItem) return PITON;
      if (it instanceof net.mcreator.climber.item.CrankFlashlightItem) return FLASHLIGHT;
      if (it instanceof net.mcreator.climber.item.ThrowableBrickItem) return BRICK;
      return NONE;
    }
  }

  static HeldPose NONE = new HeldPose(8, 8, 8, 0, 0, 0, 0, 0.5f);
  static HeldPose HAMMER = new HeldPose(8, 1.5f, 8, 12, -12, -90, 0, 0.55f);
  static HeldPose REBAR = new HeldPose(8, -1, 8, 10, -30, 0, 0, 0.5f);
  static HeldPose PITON = new HeldPose(8, 8.5f, 8, 8, 125, 0, 0, 0.55f);
  static HeldPose FLASHLIGHT = new HeldPose(9, 4, 8, 6, -5, -90, -28, 0.5f);
  static HeldPose BRICK = new HeldPose(8, 1.5f, 8, 4, 0, 90, -15, 0.5f);

  private void hideAllExcept(PlayerModel<?> model, boolean rightArm) {
    model.head.visible = false;
    model.hat.visible = false;
    model.body.visible = false;
    model.rightLeg.visible = false;
    model.leftLeg.visible = false;
    model.rightArm.visible = rightArm;
    model.leftArm.visible = !rightArm;
  }
}
