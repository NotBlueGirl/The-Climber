package net.mcreator.climber.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.mcreator.climber.entity.PitonEntity;
import net.mcreator.climber.init.ClimberModItems;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/** Renders the 3D piton model (assets/climber/models/item/piton.json) driven into the wall. */
public class PitonRenderer extends EntityRenderer<PitonEntity> {
    private final ItemRenderer itemRenderer;
    private ItemStack stack;

    public PitonRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.itemRenderer = ctx.getItemRenderer();
        this.shadowRadius = 0f;
    }

    @Override
    public void render(PitonEntity e, float yaw, float partialTick, PoseStack pose, MultiBufferSource buf, int light) {
        if (stack == null) stack = new ItemStack(ClimberModItems.PITON.get());
        Direction f = e.getFace();
        Vec3 n = new Vec3(f.getStepX(), f.getStepY(), f.getStepZ());

        pose.pushPose();
        // entity origin = bottom centre of the hitbox; go to the wall surface
        double half = e.getBbHeight() / 2.0;
        pose.translate(-n.x * PitonEntity.OUT, half - n.y * PitonEntity.OUT, -n.z * PitonEntity.OUT);
        // model +Y (tip -> ring) must point out of the wall
        pose.mulPose(new Quaternionf().rotationTo(0f, 1f, 0f, (float) n.x, (float) n.y, (float) n.z));
        // rotate the ring so it hangs "vertical" on walls
        if (f.getAxis().isHorizontal()) pose.mulPose(Axis.YP.rotationDegrees(90f));

        // an unstable piton wobbles more and more while it is being pulled out
        float loose = e.getLooseness();
        if (loose > 0f) {
            float t = (e.tickCount + partialTick) * 1.7f;
            pose.mulPose(Axis.XP.rotationDegrees(Mth.sin(t) * 9f * loose));
            pose.mulPose(Axis.ZP.rotationDegrees(Mth.cos(t * 1.3f) * 6f * loose));
        }
        // each hammer blow drives it deeper
        double embed = 0.04 + 0.045 * e.getHammered() - 0.08 * loose;
        float scale = 0.5f;
        // model tip sits at y=1px; the model is authored diagonal (-45 deg) like vanilla sprites, so straighten it
        pose.translate(0, -embed + scale * (7.0 / 16.0), 0);
        pose.scale(scale, scale, scale);
        pose.mulPose(Axis.ZP.rotationDegrees(45f));
        itemRenderer.renderStatic(stack, ItemDisplayContext.FIXED, light, OverlayTexture.NO_OVERLAY, pose, buf, e.level(), e.getId());
        pose.popPose();
        super.render(e, yaw, partialTick, pose, buf, light);
    }

    @Override
    @SuppressWarnings("deprecation")
    public ResourceLocation getTextureLocation(PitonEntity e) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
