package net.mcreator.climber.client.model;

import com.mojang.blaze3d.vertex.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.mcreator.climber.mechanism.MechanismMesh;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Resource-pack reloadable textured model assets shared by world rendering and QA gallery. */
@Mod.EventBusSubscriber(
    modid = "climber",
    value = Dist.CLIENT,
    bus = Mod.EventBusSubscriber.Bus.MOD)
public final class MechanismModels {
  public static final ResourceLocation TEXTURE =
      new ResourceLocation("climber", "textures/entity/mechanisms.png");
  private static final Map<String, MechanismMesh> CACHE = new HashMap<>();

  @SubscribeEvent
  public static void reload(RegisterClientReloadListenersEvent event) {
    event.registerReloadListener((ResourceManagerReloadListener) manager -> CACHE.clear());
  }

  private static MechanismMesh load(String name) {
    return CACHE.computeIfAbsent(
        name,
        key -> {
          try (Reader reader =
              new InputStreamReader(
                  Minecraft.getInstance()
                      .getResourceManager()
                      .open(new ResourceLocation("climber", "models/mechanism/" + key + ".json")),
                  StandardCharsets.UTF_8)) {
            return MechanismMesh.read(reader);
          } catch (IOException e) {
            throw new IllegalStateException("Cannot load mechanism model " + key, e);
          }
        });
  }

  public static void draw(String name, PoseStack pose, MultiBufferSource buffers, int light) {
    VertexConsumer v = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
    for (var face : load(name).faces()) {
      for (int i = 0; i < 4; i++) {
        int j = Math.min(i, face.positions().length - 1);
        float[] p = face.positions()[j], uv = face.uv()[j], n = face.normal();
        v.vertex(pose.last().pose(), p[0], p[1], p[2])
            .color(255, 255, 255, 255)
            .uv(uv[0], uv[1])
            .overlayCoords(OverlayTexture.NO_OVERLAY)
            .uv2(light)
            .normal(pose.last().normal(), n[0], n[1], n[2])
            .endVertex();
      }
    }
  }
}
