package net.mcreator.climber.client;

import com.mojang.blaze3d.vertex.*;
import net.mcreator.climber.client.screens.MechanismCameraScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "climber", value = Dist.CLIENT)
public final class MechanismSelectionOverlay {
  @SubscribeEvent
  public static void hidePlayer(net.minecraftforge.client.event.RenderPlayerEvent.Pre event) {
    var mc = Minecraft.getInstance();
    if (mc.screen instanceof MechanismCameraScreen && event.getEntity() == mc.player)
      event.setCanceled(true);
  }

  @SubscribeEvent
  public static void hideHand(net.minecraftforge.client.event.RenderHandEvent event) {
    if (Minecraft.getInstance().screen instanceof MechanismCameraScreen) event.setCanceled(true);
  }

  @SubscribeEvent
  public static void render(RenderLevelStageEvent e) {
    if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
    var mc = Minecraft.getInstance();
    if (!(mc.screen instanceof MechanismCameraScreen screen)) return;
    PoseStack p = e.getPoseStack();
    p.pushPose();
    Vec3 cam = e.getCamera().getPosition();
    p.translate(-cam.x, -cam.y, -cam.z);
    var buffers = mc.renderBuffers().bufferSource();
    var v = buffers.getBuffer(MechanismOverlayRenderType.GUIDES);
    for (BlockPos b : screen.selected())
      LevelRenderer.renderLineBox(p, v, new AABB(b).inflate(.006), .25f, .65f, 1, 1);
    var aimed = screen.aimed();
    if (aimed != null)
      LevelRenderer.renderLineBox(
          p, v, new AABB(aimed.getBlockPos()).inflate(.009), .55f, .8f, 1, .7f);
    if (screen.valve && screen.source != null) {
      LevelRenderer.renderLineBox(
          p, v, screen.source.getBoundingBox().inflate(.035), 1, .2f, .25f, 1);
      if (!screen.selected().isEmpty())
        line(
            p,
            v,
            screen.source.position().add(0, .15, 0),
            Vec3.atCenterOf(screen.selected().get(0)));
    } else if (screen.selected().size() > 1) {
      var draft = new net.mcreator.climber.mechanism.MechanismSpec();
      draft.curved = screen.draft.curved;
      draft.selectRailBlocks(screen.selected());
      var path = draft.route();
      Vec3 origin = Vec3.atCenterOf(screen.selected().get(0));
      for (int i = 1; i < path.size(); i++)
        line(p, v, origin.add(path.get(i - 1)), origin.add(path.get(i)));
    }
    // NO_DEPTH_TEST uses an always-pass shard; explicitly disable the existing terrain test.
    com.mojang.blaze3d.systems.RenderSystem.disableDepthTest();
    buffers.endBatch(MechanismOverlayRenderType.GUIDES);
    com.mojang.blaze3d.systems.RenderSystem.enableDepthTest();
    p.popPose();
  }

  private static void line(PoseStack p, VertexConsumer v, Vec3 a, Vec3 b) {
    Vec3 n = b.subtract(a).normalize();
    for (Vec3 x : new Vec3[] {a, b})
      v.vertex(p.last().pose(), (float) x.x, (float) x.y, (float) x.z)
          .color(1f, .8f, .18f, 1f)
          .normal(p.last().normal(), (float) n.x, (float) n.y, (float) n.z)
          .endVertex();
  }
}
