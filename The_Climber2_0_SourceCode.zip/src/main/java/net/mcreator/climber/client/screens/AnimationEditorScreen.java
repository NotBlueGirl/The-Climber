package net.mcreator.climber.client.screens;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.animation.RigAnimation;
import net.mcreator.climber.animation.AnimationEdits;
import org.joml.Quaternionf;
import net.mcreator.climber.client.animation.AnimationClient;
import net.mcreator.climber.network.AnimationRequestPacket;
import net.mcreator.climber.network.ConfigSyncPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;
import org.lwjgl.glfw.GLFW;
import java.nio.file.*;
import java.util.*;

/** Non-pausing keyframe editor: local rig preview, approved server playback and portable JSON. */
@OnlyIn(Dist.CLIENT)
public final class AnimationEditorScreen extends Screen {
    private static RigAnimation draft;
    private RigAnimation clip = RigAnimation.blank();
    private int page, boneIndex, scroll;
    private float cursor;
    private boolean capturing, playing;
    private long lastTick;
    private EditBox idField, itemField, durationField, cooldownField;
    private final List<PoseSlider> sliders = new ArrayList<>();
    private final List<Label> labels = new ArrayList<>();
    private Timeline timeline;
    private Button localPlay;
    private int panel;
    private final AnimationEdits.History history = new AnimationEdits.History();
    private Map<String,float[]> poseClipboard;
    private final Set<Integer> invalidPoseNumbers = new HashSet<>();
    private final List<EditBox> poseFields = new ArrayList<>();
    private boolean syncing, dirtyDraft, orbiting, batching;
    private long editedAt, savedAt;
    private float cameraYaw, cameraPitch = -10, zoom = 1, speed = 1;
    private String libraryFilter = "", moveTick = "0", stretchTicks = "20";
    private boolean serverLibrary = true;
    private int contentHeight;
    private Button undoButton, redoButton;
    private record Label(String name, int y) {}
    private static final String[] CHANNELS = { "Rot X", "Rot Y", "Rot Z", "Pos X", "Pos Y", "Pos Z" };

    public AnimationEditorScreen() {
        super(Component.literal("Debug Tool - Animation Mode"));
        if (draft != null) { clip = draft; return; }
        try {
            Path path = FMLPaths.CONFIGDIR.get().resolve("climber_animation_drafts/last.json");
            if (Files.isRegularFile(path) && Files.size(path) <= RigAnimation.MAX_JSON * 3L) { clip = RigAnimation.fromJson(Files.readString(path)); status("Restored autosaved draft: " + clip.id); return; }
        } catch (Exception e) { ClimberMod.LOGGER.warn("[Animator] Draft restore failed: {}", e.getMessage()); }
        var p = Minecraft.getInstance().player;
        if (p != null && !p.getMainHandItem().isEmpty()) clip.item = String.valueOf(ForgeRegistries.ITEMS.getKey(p.getMainHandItem().getItem()));
    }
    private void status(String text) { AnimationClient.status = text; }
    private void change(String group) { if(batching)return; history.record(clip, group, System.currentTimeMillis()); dirtyDraft = true; editedAt = System.currentTimeMillis(); }
    private void undo(boolean redo) { clip = redo ? history.redo(clip) : history.undo(clip); cursor = Math.min(cursor,clip.durationTicks); playing=false; dirtyDraft=true;editedAt=System.currentTimeMillis();rebuild(); }
    private void operation(String name,Runnable run) { try { change(name); run.run(); rebuild(); } catch(RuntimeException e) { status(e.getMessage()); } }
    private void rebuild() { setFocused(null); clearWidgets(); init(); }
    @Override protected void init() {
        panel = Math.min(280, Math.max(172, width / 2)); sliders.clear(); labels.clear(); poseFields.clear();invalidPoseNumbers.clear();
        idField = null; itemField = null; durationField = null; cooldownField = null;
        String[] pages = { "Clip", "Pose", "Keys", "Files" };
        for(int i=0;i<4;i++){final int p=i;button((page==i?">":"")+pages[i],8+i*(panel-16)/4,27,(panel-16)/4-2,16,()->{page=p;scroll=0;rebuild();});}
        int rightWidth=width-panel-16, half=Math.max(20,(rightWidth-3)/2);
        undoButton=button("Undo",panel+8,49,half,16,()->undo(false));
        redoButton=button("Redo",panel+11+half,49,half,16,()->undo(true));
        button("x"+speed,panel+8,69,half,16,()->{speed=speed==.25f?.5f:speed==.5f?1:speed==1?2:.25f;rebuild();});
        button("Reset view",panel+11+half,69,half,16,()->{cameraYaw=0;cameraPitch=-10;zoom=1;});
        button("Item display", Math.max(panel + 8, width - 103), 6, Math.min(95, width - panel - 12), 16, () -> {
            onClose(); Minecraft.getInstance().setScreen(new ItemDisplayEditorScreen());
        });
        int y = 50 - scroll;
        if (page == 0) {
            idField = field("ID", clip.id, y, 48, v -> { change("id"); clip.id = v; }); y += 22;
            String event = clip.event.name(); rowButton("Event", event, y, () -> { change("event"); clip.event = RigAnimation.Trigger.values()[(clip.event.ordinal() + 1) % RigAnimation.Trigger.values().length]; rebuild(); }); y += 22;
            rowButton("Key", capturing ? "Press a key..." : keyName(), y, () -> { capturing = true; playing = false; status("Press the binding key; Escape cancels capture."); rebuild(); }); y += 22;
            itemField = field("Item", clip.item, y, 128, v -> { change("item"); clip.item = v; }); y += 22;
            rowButton("Hand", clip.hand.name(), y, () -> { change("hand"); clip.hand = RigAnimation.Hand.values()[(clip.hand.ordinal() + 1) % RigAnimation.Hand.values().length]; rebuild(); }); y += 22;
            durationField = field("Ticks", "" + clip.durationTicks, y, 4, v -> {
                try { int n = Integer.parseInt(v); if (n >= 1 && n <= 1200 && clip.frames.lastKey() <= n) { change("duration"); clip.durationTicks = n; cursor = Math.min(cursor, n); if (timeline != null) timeline.sync(); } }
                catch (NumberFormatException ignored) { }
            }); y += 22;
            cooldownField = field("Cooldown", "" + clip.cooldownTicks, y, 5, v -> {
                try { int n = Integer.parseInt(v); if (n >= 1 && n <= 12000) { change("cooldown"); clip.cooldownTicks = n; } } catch (NumberFormatException ignored) { }
            }); y += 22;
            rowButton("Loop", clip.loop ? "ON" : "OFF", y, () -> { change("loop"); clip.loop = !clip.loop; rebuild(); }); y += 22;
            rowButton("Mode", clip.additive ? "ADDITIVE" : "REPLACE", y, () -> { change("mode"); clip.additive = !clip.additive; rebuild(); }); y += 22;
            rowButton("Release", clip.stopOnRelease ? "Stop on release" : "Play to end", y, () -> { change("release"); clip.stopOnRelease = !clip.stopOnRelease; rebuild(); }); y += 22;
            rowButton("Item", "Use held item", y, this::useHeld); y += 22;
            rowButton("File", "Import by ID", y, this::importFile); y += 22;
            rowButton("Clipboard", "Import JSON", y, this::importClipboard); y += 22;
            rowButton("Create", "New animation", y, () -> { change("new"); clip = RigAnimation.blank(); cursor = 0; playing = false; rebuild(); }); y += 22;
        } else if (page == 1) {
            for(int i=0;i<6;i++){final int bone=i;int bx=8+(i%2)*(panel-16)/2,by=y+(i/2)*19;
                Button bb=button((boneIndex==i?"> ":"")+RigAnimation.BONES[i].replace('_',' '),bx,by,(panel-16)/2-2,16,()->{boneIndex=bone;rebuild();});body(bb,by);}
            y+=62;
            for (int i = 0; i < 6; i++) {
                final int idx = i;
                body(button("-",8,y,16,16,()->{edit(idx,values()[idx]-(idx<3?1f:.25f));refresh();}),y);
                PoseSlider slider=new PoseSlider(26,y,panel-122,16,idx);sliders.add(slider);addRenderableWidget(slider);body(slider,y);
                EditBox number=new EditBox(font,panel-92,y,66,16,Component.literal(CHANNELS[i]));number.setMaxLength(24);number.setValue(Float.toString(values()[i]));
                number.setResponder(v->{if(syncing)return;try{float n=Float.parseFloat(v);if(!Float.isFinite(n)||Math.abs(n)>(idx<3?720:32))throw new IllegalArgumentException();edit(idx,n);invalidPoseNumbers.remove(idx);number.setTextColor(0xFFFFFF);sliders.forEach(PoseSlider::sync);}catch(RuntimeException e){invalidPoseNumbers.add(idx);number.setTextColor(0xFF7777);status("Enter a finite number within the channel bounds.");}});
                addRenderableWidget(number);poseFields.add(number);body(number,y);
                body(button("+",panel-24,y,16,16,()->{edit(idx,values()[idx]+(idx<3?1f:.25f));refresh();}),y);y+=21;
            }
            rowButton("Pose", "Copy pose", y, this::copyPose);y+=22;
            rowButton("Pose", "Paste pose", y, this::pastePose);y+=22;
            rowButton("Pose", "Mirror L / R", y, ()->operation("mirror",()->AnimationEdits.paste(clip,Math.round(cursor),AnimationEdits.mirror(AnimationEdits.fullPose(clip,cursor)))));y+=22;
            rowButton("At cursor", "Reset this bone",y,()->operation("reset bone",()->{batching=true;try{for(int i=0;i<6;i++)edit(i,0);}finally{batching=false;}}));y+=22;
            rowButton("Track", "Unkey this bone",y,()->operation("unkey",()->clip.frames.values().forEach(p->p.remove(RigAnimation.BONES[boneIndex]))));y+=22;
        } else if(page == 2) {
            rowButton("Frame", "Add / snapshot",y,this::addFrame);y+=22;
            rowButton("Frame", "Delete at cursor",y,this::deleteFrame);y+=22;
            field("Move to",moveTick,y,4,v->moveTick=v);y+=22;
            rowButton("Retime", "Move selected key",y,()->operation("retime",()->{int to=Integer.parseInt(moveTick);AnimationEdits.move(clip,Math.round(cursor),to);cursor=to;rebuild();}));y+=22;
            field("Length",stretchTicks,y,4,v->stretchTicks=v);y+=22;
            rowButton("Retime", "Stretch all keys",y,()->operation("stretch",()->{int n=Integer.parseInt(stretchTicks);AnimationEdits.stretch(clip,n);cursor=Math.min(cursor,n);rebuild();}));y+=22;
            rowButton("Pose", "Copy pose",y,this::copyPose);y+=22;
            rowButton("Pose", "Paste / duplicate",y,this::pastePose);y+=22;
            for(int t:clip.frames.keySet()){final int tick=t;int by=y;Button b=button((Math.round(cursor)==t?"> ":"")+"Tick "+t+" ("+String.format(Locale.ROOT,"%.2fs",t/20f)+")",8,by,panel-16,17,()->{cursor=tick;moveTick=""+tick;playing=false;rebuild();});body(b,by);y+=20;}
        } else {
            rowButton("Source",serverLibrary?"SERVER":"LOCAL EXPORTS",y,()->{serverLibrary=!serverLibrary;scroll=0;rebuild();});y+=22;
            EditBox filter=field("Filter",libraryFilter,y,48,v->libraryFilter=v);y+=22;
            rowButton("Library","Apply filter",y,()->{scroll=0;rebuild();});y+=22;
            for(String name:libraryNames()){final String id=name;int by=y;Button b=button(name,8,by,panel-16,17,()->loadClip(id));body(b,by);y+=20;}
            rowButton("JSON","Import clipboard",y,this::importClipboard);y+=22;
        }
        contentHeight=y+scroll-50;
        // Fixed timeline and footer; body rows scroll independently at small GUI sizes.
        timeline = new Timeline(8, height - 73, width - 16, 16); addRenderableWidget(timeline);
        int fw = (width - 25) / 4;
        button("Prev key", 8, height - 54, fw, 16, () -> moveKey(-1));
        localPlay = button(playing ? "Pause local" : "Play local", 11 + fw, height - 54, fw, 16, () -> { playing = !playing; if (cursor >= clip.durationTicks) cursor = 0; lastTick = System.nanoTime(); rebuild(); });
        button("Next key", 14 + fw * 2, height - 54, fw, 16, () -> moveKey(1));
        button("Stop server", 17 + fw * 3, height - 54, fw, 16, () -> { send(AnimationRequestPacket.STOP, ""); status("Stop requested for your server animation."); });
        button("Export JSON", 8, height - 35, fw, 16, this::export);
        Button publish = button("Publish (OP)", 11 + fw, height - 35, fw, 16, this::publish);
        Button serverPlay = button("Play server", 14 + fw * 2, height - 35, fw, 16, () -> {
            if (validated() != null) { send(AnimationRequestPacket.PLAY, clip.id); status("Requested the PUBLISHED revision: " + clip.id); }
        });
        publish.active = serverPlay.active = ConfigSyncPacket.clientCanEdit;
        button("Close", 17 + fw * 3, height - 35, fw, 16, this::onClose);
        lastTick = System.nanoTime();
    }
    private Button button(String text, int x, int y, int w, int h, Runnable run) {
        return addRenderableWidget(Button.builder(Component.literal(text), b -> run.run()).bounds(x, y, Math.max(12, w), h).build());
    }
    private void body(AbstractWidget w, int y) { w.visible = y >= 48 && y + w.getHeight() <= height - 92; }
    private void rowButton(String label, String text, int y, Runnable run) {
        labels.add(new Label(label, y)); body(button(text, 72, y, panel - 80, 17, run), y);
    }
    private EditBox field(String label, String text, int y, int max, java.util.function.Consumer<String> change) {
        labels.add(new Label(label, y)); EditBox box = new EditBox(font, 72, y, panel - 80, 17, Component.literal(label));
        box.setMaxLength(max); box.setValue(text); box.setResponder(change); addRenderableWidget(box); body(box, y); return box;
    }
    private String keyName() { String n = GLFW.glfwGetKeyName(clip.keyCode, 0); return (n == null ? "Key" : n.toUpperCase(Locale.ROOT)) + " (" + clip.keyCode + ")"; }
    private float[] values() { float[] v = clip.sample(RigAnimation.BONES[boneIndex], cursor); return v == null ? new float[6] : v; }
    private void edit(int idx, float value) {
        change("pose:"+boneIndex+":"+idx); playing = false; int tick = Math.round(cursor); cursor = tick;
        String bone = RigAnimation.BONES[boneIndex]; float[] previous = clip.sample(bone, cursor);
        int needed = (clip.frames.containsKey(tick) ? 0 : 1) + (previous == null && tick > 0 && !clip.frames.containsKey(0) ? 1 : 0);
        if (clip.frames.size() + needed > RigAnimation.MAX_FRAMES) { status("Maximum 64 keyframes; delete a frame first."); return; }
        // A newly keyed bone gets a neutral start, instead of unexpectedly holding its first pose from tick 0.
        if (previous == null && tick > 0) clip.frames.computeIfAbsent(0, t -> new LinkedHashMap<>()).put(bone, new float[6]);
        Map<String, float[]> frame = clip.frames.get(tick);
        if (frame == null) { frame = clip.pose(cursor); clip.frames.put(tick, frame); }
        float[] pose = frame.get(bone);
        if (pose == null) { pose = previous == null ? new float[6] : previous.clone(); frame.put(bone, pose); }
        float max = idx < 3 ? 720 : 32;
        pose[idx] = Mth.clamp(value, -max, max); if (timeline != null) timeline.sync();
    }
    private void addFrame() {
        change("snapshot"); int tick = Math.round(cursor); playing = false;
        if (!clip.frames.containsKey(tick) && clip.frames.size() >= RigAnimation.MAX_FRAMES) { status("Maximum 64 keyframes."); return; }
        var pose = AnimationEdits.fullPose(clip,tick); clip.frames.put(tick,pose);
        status("Keyframe saved at tick " + tick); rebuild();
    }
    private void deleteFrame() {
        playing = false; if (clip.frames.size() <= 1) { status("Keep at least one keyframe."); return; }
        change("delete"); clip.frames.remove(Math.round(cursor)); status("Deleted keyframe at cursor (if present)."); rebuild();
    }
    private void moveKey(int dir) {
        playing = false; Integer next = dir < 0 ? clip.frames.lowerKey(Math.round(cursor)) : clip.frames.higherKey(Math.round(cursor));
        if (next != null) cursor = next; refresh();
    }
    private void refresh() { sliders.forEach(PoseSlider::sync);syncing=true;for(int i=0;i<poseFields.size();i++)poseFields.get(i).setValue(Float.toString(values()[i]));syncing=false;if(timeline!=null)timeline.sync(); }
    private RigAnimation validated() {
        try {
            if(!invalidPoseNumbers.isEmpty())throw new IllegalArgumentException("Finish the highlighted pose numbers first.");
            if (durationField != null && Integer.parseInt(durationField.getValue()) != clip.durationTicks) throw new IllegalArgumentException("Duration must be 1-1200 and include every keyframe.");
            if (cooldownField != null && Integer.parseInt(cooldownField.getValue()) != clip.cooldownTicks) throw new IllegalArgumentException("Cooldown must be 1-12000 ticks.");
            return RigAnimation.fromJson(clip.toJson());
        } catch (Exception e) { status("Invalid clip: " + e.getMessage()); return null; }
    }
    private void send(int action, String text) { ClimberMod.PACKET_HANDLER.sendToServer(new AnimationRequestPacket(action, text, 0)); }
    private void publish() { RigAnimation a = validated(); if (a != null) { send(AnimationRequestPacket.PUBLISH, a.toJson()); status("Publish requested; waiting for server validation."); } }
    private Path exportFolder() { return FMLPaths.CONFIGDIR.get().resolve("climber_animation_exports"); }
    private void export() {
        RigAnimation a = validated(); if (a == null) return;
        try { Files.createDirectories(exportFolder()); Files.writeString(exportFolder().resolve(a.id + ".json"), a.toJson()); Minecraft.getInstance().keyboardHandler.setClipboard(a.toJson()); status("Exported config/climber_animation_exports/" + a.id + ".json; also copied JSON."); }
        catch (Exception e) { status("Export failed: " + e.getMessage()); }
    }
    private void importText(String text) {
        RigAnimation imported=RigAnimation.fromJson(text); change("import"); clip = imported; cursor = 0; playing = false; capturing = false; scroll = 0; rebuild(); status("Imported local clip: " + clip.id + ". Publish to update server.");
    }
    private void importClipboard() { try { importText(Minecraft.getInstance().keyboardHandler.getClipboard()); } catch (Exception e) { status("Import rejected: " + e.getMessage()); } }
    private void importFile() {
        try {
            if (!RigAnimation.validId(clip.id)) throw new IllegalArgumentException("Enter a valid animation ID first");
            Path p = exportFolder().resolve(clip.id + ".json"); if (Files.size(p) > RigAnimation.MAX_JSON * 3L) throw new IllegalArgumentException("File too large"); importText(Files.readString(p));
        } catch (Exception e) { status("File import failed: " + e.getMessage()); }
    }
    private void nextClip() {
        if (AnimationClient.CLIPS.isEmpty()) { status("Server has no published clips. Publish one first."); return; }
        String key = AnimationClient.CLIPS.higherKey(clip.id); if (key == null) key = AnimationClient.CLIPS.firstKey();
        change("load"); clip = AnimationClient.CLIPS.get(key).copy(); cursor = 0; playing = false; rebuild(); status("Loaded published clip: " + key);
    }
    @Override public boolean keyPressed(int key, int scan, int modifiers) {
        if (capturing) {
            capturing = false; if (key != GLFW.GLFW_KEY_ESCAPE && key >= 32 && key <= 348) { change("key"); clip.keyCode = key; }
            status(key == GLFW.GLFW_KEY_ESCAPE ? "Key capture canceled." : "Linked key: " + keyName()); rebuild(); return true;
        }
        if(!(getFocused() instanceof EditBox)) {
            boolean ctrl=(modifiers & GLFW.GLFW_MOD_CONTROL)!=0;
            if(ctrl&&key==GLFW.GLFW_KEY_Z){undo((modifiers & GLFW.GLFW_MOD_SHIFT)!=0);return true;}
            if(ctrl&&key==GLFW.GLFW_KEY_Y){undo(true);return true;}
            if(ctrl&&key==GLFW.GLFW_KEY_C){copyPose();return true;}if(ctrl&&key==GLFW.GLFW_KEY_V){pastePose();return true;}
            if(ctrl&&key==GLFW.GLFW_KEY_S){export();return true;}
            if(key==GLFW.GLFW_KEY_SPACE){playing=!playing;if(cursor>=clip.durationTicks)cursor=0;return true;}
            if(key==GLFW.GLFW_KEY_INSERT){addFrame();return true;}if(key==GLFW.GLFW_KEY_DELETE){deleteFrame();return true;}
            if(key==GLFW.GLFW_KEY_LEFT||key==GLFW.GLFW_KEY_RIGHT){playing=false;cursor=Mth.clamp(cursor+(key==GLFW.GLFW_KEY_LEFT?-1:1)*((modifiers & GLFW.GLFW_MOD_SHIFT)!=0?5:1),0,clip.durationTicks);refresh();return true;}
            if(key==GLFW.GLFW_KEY_HOME||key==GLFW.GLFW_KEY_END){playing=false;cursor=key==GLFW.GLFW_KEY_HOME?0:clip.durationTicks;refresh();return true;}
        }
        return super.keyPressed(key, scan, modifiers);
    }
    @Override public boolean mouseScrolled(double x, double y, double amount) {
        if (x < panel && y >= 45 && y < height - 77) {
            int max = Math.max(0, contentHeight - (height - 142));
            scroll = Mth.clamp(scroll - (int) (amount * 22), 0, max); rebuild(); return true;
        }
        if(x>panel&&y>87&&y<height-90){zoom=Mth.clamp(zoom+(float)amount*.1f,.5f,2.5f);return true;}
        return super.mouseScrolled(x, y, amount);
    }
    @Override public void tick() {
        for(var child:children())if(child instanceof EditBox box && box.visible)box.tick();
        if(dirtyDraft&&System.currentTimeMillis()-editedAt>1500&&System.currentTimeMillis()-savedAt>2000)saveDraft();

    }
    @Override public void render(GuiGraphics g, int mx, int my, float partial) {
        long n = System.nanoTime(); float delta = lastTick == 0 ? 0 : Math.min(.15f, (n - lastTick) / 1_000_000_000f); lastTick = n;
        if (playing) {
            cursor += delta * 20 * speed; if (cursor >= clip.durationTicks) { if (clip.loop) cursor %= clip.durationTicks; else { cursor = clip.durationTicks; playing = false; } } refresh();
        }
        g.fill(0, 0, width, height, 0xB0151920); g.fill(0, 24, panel, height - 78, 0xD01C222B);
        g.drawString(font, "DEBUG TOOL / ANIMATION"+(dirtyDraft?" *":""), 8, 8, 0xFFFFCC66);
        // Render the actual standard/slim player rig, not a static diagram.
        var mc = Minecraft.getInstance();
        if (mc.player != null) {
            int cx = panel + (width - panel) / 2, base = height - 101;
            int scale = Math.max(16, Math.min(70, Math.min((width - panel - 20) / 2, (height - 146) / 2)));
            AnimationClient.preview=clip;AnimationClient.previewTick=cursor;AnimationClient.previewRendering=true;
            var player=mc.player;float bodyYaw=player.yBodyRot, entityYaw=player.getYRot(), entityPitch=player.getXRot(),head=player.yHeadRot,headOld=player.yHeadRotO;
            g.enableScissor(panel+2,87,width-4,height-92);
            try {
                player.yBodyRot=180;player.setYRot(180);player.setXRot(0);player.yHeadRot=180;player.yHeadRotO=180;
                Quaternionf pitchQ=new Quaternionf().rotateX((float)Math.toRadians(cameraPitch));
                Quaternionf modelQ=new Quaternionf().rotateZ((float)Math.PI).mul(pitchQ).rotateY((float)Math.toRadians(cameraYaw));
                InventoryScreen.renderEntityInInventory(g,cx,base,Math.round(scale*zoom),modelQ,pitchQ,player);
            } finally {player.yBodyRot=bodyYaw;player.setYRot(entityYaw);player.setXRot(entityPitch);player.yHeadRot=head;player.yHeadRotO=headOld;AnimationClient.previewRendering=false;g.disableScissor();}
            g.drawCenteredString(font, "LOCAL RIG PREVIEW", cx, 31, 0xFF9EB9D3);
            if (width - panel > 150) g.drawCenteredString(font, "Drag: orbit | Wheel: zoom", cx, height - 89, 0xFFB6C3CF);
        }
        for (Label l : labels) if (l.y >= 48 && l.y + 17 <= height - 92) g.drawString(font, l.name, 8, l.y + 4, 0xFFCCD7E2);
        if(undoButton!=null)undoButton.active=history.canUndo();if(redoButton!=null)redoButton.active=history.canRedo();
        if (localPlay != null) localPlay.setMessage(Component.literal(playing ? "Pause local" : "Play local"));
        super.render(g, mx, my, partial);
        g.drawString(font, "Scroll panel for more controls", 8, height - 85, 0xFF9AA8B7);
        g.drawString(font, font.plainSubstrByWidth(AnimationClient.status, width - 16), 8, height - 13, 0xFF9CD8AD);
        // Timeline markers: selected tick is in the slider label; yellow lines mark real keyframes.
        for (int t : clip.frames.keySet()) { int x = 12 + (width - 24) * t / clip.durationTicks; g.fill(x, height - 73, x + 1, height - 70, 0xFFFFCC66); }
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { if(dirtyDraft)saveDraft();draft = clip; AnimationClient.preview = null; AnimationClient.previewRendering = false; }

    private void copyPose(){poseClipboard=AnimationEdits.fullPose(clip,cursor);status("Pose copied. Scrub to another tick and Paste to duplicate it.");}
    private void pastePose(){if(poseClipboard==null){status("Copy a pose first (Ctrl+C).");return;}operation("paste",()->AnimationEdits.paste(clip,Math.round(cursor),poseClipboard));}
    private void useHeld(){var p=Minecraft.getInstance().player;if(p==null)return;var stack=clip.hand==RigAnimation.Hand.OFF_HAND?p.getOffhandItem():p.getMainHandItem();change("held");clip.item=String.valueOf(ForgeRegistries.ITEMS.getKey(stack.getItem()));rebuild();}
    private List<String> libraryNames(){if(serverLibrary)return AnimationClient.CLIPS.keySet().stream().filter(n->n.contains(libraryFilter.toLowerCase(Locale.ROOT))).toList();try{Files.createDirectories(exportFolder());try(var files=Files.list(exportFolder())){return files.map(p->p.getFileName().toString()).filter(n->n.endsWith(".json")).map(n->n.substring(0,n.length()-5)).filter(RigAnimation::validId).filter(n->n.contains(libraryFilter.toLowerCase(Locale.ROOT))).sorted().limit(256).toList();}}catch(Exception e){return List.of();}}
    private void loadClip(String id){try{if(serverLibrary)importText(AnimationClient.CLIPS.get(id).toJson());else{Path p=exportFolder().resolve(id+".json");if(Files.size(p)>RigAnimation.MAX_JSON*3L)throw new IllegalArgumentException("File too large");importText(Files.readString(p));}page=0;rebuild();}catch(Exception e){status("Load rejected: "+e.getMessage());}}
    private void saveDraft(){savedAt=System.currentTimeMillis();try{RigAnimation a=RigAnimation.fromJson(clip.toJson());Path dir=FMLPaths.CONFIGDIR.get().resolve("climber_animation_drafts");Files.createDirectories(dir);Path temp=dir.resolve("last.tmp");Files.writeString(temp,a.toJson());Files.move(temp,dir.resolve("last.json"),StandardCopyOption.REPLACE_EXISTING);dirtyDraft=false;}catch(Exception e){ClimberMod.LOGGER.debug("[Animator] Draft is not yet valid for autosave: {}",e.getMessage());}}
    @Override public boolean mouseClicked(double x,double y,int button){
        if(button==0&&y>=height-77&&y<=height-70){for(int t:clip.frames.keySet()){double k=12+(width-24)*t/(double)clip.durationTicks;if(Math.abs(x-k)<=4){cursor=t;moveTick=""+t;playing=false;refresh();return true;}}}
        if((button==0||button==1)&&x>panel&&y>87&&y<height-92){setFocused(null);orbiting=true;return true;}return super.mouseClicked(x,y,button);
    }
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){if(orbiting){cameraYaw+=(float)dx;cameraPitch=Mth.clamp(cameraPitch+(float)dy,-70,70);return true;}return super.mouseDragged(x,y,button,dx,dy);}
    @Override public boolean mouseReleased(double x,double y,int button){if(orbiting){orbiting=false;return true;}return super.mouseReleased(x,y,button);}
    private final class PoseSlider extends AbstractSliderButton {
        private final int index;
        PoseSlider(int x, int y, int w, int h, int index) { super(x, y, w, h, Component.empty(), 0); this.index = index; sync(); }
        void sync() { float max = index < 3 ? 720 : 32; value = (values()[index] + max) / (2 * max); updateMessage(); }
        @Override protected void updateMessage() { setMessage(Component.literal(CHANNELS[index])); }
        @Override protected void applyValue() { float max = index < 3 ? 720 : 32; edit(index, (float) value * 2 * max - max); updateMessage(); }
    }
    private final class Timeline extends AbstractSliderButton {
        Timeline(int x, int y, int w, int h) { super(x, y, w, h, Component.empty(), 0); sync(); }
        void sync() { value = cursor / clip.durationTicks; updateMessage(); }
        @Override protected void updateMessage() { setMessage(Component.literal("Tick " + Math.round(cursor) + " / " + clip.durationTicks + "  |  " + clip.frames.size() + " keys")); }
        @Override protected void applyValue() { playing = false; cursor = Math.round(value * clip.durationTicks); refresh(); }
    }
}
