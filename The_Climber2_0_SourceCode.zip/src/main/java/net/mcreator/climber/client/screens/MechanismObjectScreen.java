package net.mcreator.climber.client.screens;

import java.util.*;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.mechanism.*;
import net.mcreator.climber.network.MechanismListPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;

/** Server-paged catalog; only opening an object temporarily loads its chunk. No teleport. */
public final class MechanismObjectScreen extends Screen {
  private static int nextRequest;
  private final Screen parent;
  private EditBox search;
  private String filter = "", message = "", selected = "";
  private int page, total, request, pageSize;
  private List<CompoundTag> rows = List.of();

  public MechanismObjectScreen(Screen parent) {
    super(Component.literal("Debugger / Created objects"));
    this.parent = parent;
  }

  @Override
  protected void init() {
    pageSize = Math.max(3, Math.min(12, (height - 118) / 28));
    search = new EditBox(font, 16, 35, width - 135, 18, Component.literal("Search objects"));
    search.setMaxLength(80);
    search.setValue(filter);
    addRenderableWidget(search);
    add(
        "Search",
        width - 107,
        33,
        90,
        () -> {
          filter = search.getValue();
          page = 0;
          fetch();
        });
    int col = (width - 32) / 4;
    add(
        "< Prev",
        12,
        height - 44,
        col,
        () -> {
          if (page > 0) {
            page--;
            fetch();
          }
        });
    add(
        "Next >",
        16 + col,
        height - 44,
        col,
        () -> {
          if ((page + 1) * pageSize < total) {
            page++;
            fetch();
          }
        });
    add("Edit", 20 + col * 2, height - 44, col, this::edit);
    add("Back", 24 + col * 3, height - 44, col, this::onClose);
    fetch();
  }

  private void add(String label, int x, int y, int w, Runnable r) {
    addRenderableWidget(new DebuggerActionButton(label, x, y, w, r));
  }

  private void fetch() {
    if (minecraft.player == null
        || !minecraft.player.isCreative()
        || !(minecraft.player.getMainHandItem().getItem()
                instanceof net.mcreator.climber.item.DebuggerToolItem
            || minecraft.player.getOffhandItem().getItem()
                instanceof net.mcreator.climber.item.DebuggerToolItem)) {
      message = "Hold Debugger Tool in Creative.";
      return;
    }
    request = ++nextRequest;
    message = "Loading server objects...";
    ClimberMod.PACKET_HANDLER.sendToServer(
        new MechanismListPacket.Request(request, filter, page, pageSize));
  }

  public static void receive(MechanismListPacket.Response m) {
    var mc = Minecraft.getInstance();
    if (mc.screen instanceof MechanismObjectScreen s && s.request == m.request()) {
      s.rows = m.rows();
      s.page = m.page();
      s.total = m.total();
      s.message = "Select a row. Edit remotely, in any dimension.";
    }
  }

  private void edit() {
    if (selected.isEmpty()) {
      message = "Select an object first.";
      return;
    }
    ClimberMod.PACKET_HANDLER.sendToServer(
        new net.mcreator.climber.network.RemoteObjectPacket(selected, 0, new CompoundTag(), 0));
    message = "Loading remote object...";
  }

  @Override
  public boolean mouseClicked(double x, double y, int button) {
    if (button == 0 && y >= 66 && y < height - 60) {
      int i = (int) (y - 66) / 28;
      if (i < rows.size()) {
        selected = rows.get(i).getString("id");
        message =
            "Selected "
                + rows.get(i).getString("kind")
                + " — "
                + MechanismCatalog.Entry.load(rows.get(i)).pos().toShortString();
        return true;
      }
    }
    return super.mouseClicked(x, y, button);
  }

  @Override
  public boolean mouseScrolled(double x, double y, double delta) {
    if (delta < 0 && (page + 1) * pageSize < total) {
      page++;
      fetch();
    } else if (delta > 0 && page > 0) {
      page--;
      fetch();
    }
    return true;
  }

  @Override
  public void tick() {
    search.tick();
  }

  @Override
  public boolean keyPressed(int k, int scan, int mods) {
    if (k == 257) {
      filter = search.getValue();
      page = 0;
      fetch();
      return true;
    }
    return super.keyPressed(k, scan, mods);
  }

  @Override
  public void onClose() {
    minecraft.setScreen(parent == null ? new MechanismEditorScreen(-1) : parent);
  }

  @Override
  public boolean isPauseScreen() {
    return false;
  }

  @Override
  public void render(GuiGraphics g, int x, int y, float partial) {
    g.fill(0, 0, width, height, 0xFA10151B);
    g.drawString(font, "DEBUGGER  /  CREATED OBJECTS", 16, 12, 0xE7EDF2, false);
    g.drawString(font, total + " objects | page " + (page + 1), 16, 56, 0x70B7F0, false);
    for (int i = 0; i < rows.size(); i++) {
      var row = rows.get(i);
      var e = MechanismCatalog.Entry.load(row);
      int yy = 68 + i * 28;
      boolean chosen = e.id().equals(selected);
      if (chosen) g.fill(12, yy - 2, width - 12, yy + 24, 0x303F789F);
      String title =
          e.kind().replace('_', ' ')
              + "  ["
              + (row.getBoolean("loaded") ? "loaded" : "unloaded")
              + "]";
      g.drawString(
          font,
          font.plainSubstrByWidth(title, width - 32),
          16,
          yy,
          chosen ? 0x70B7F0 : 0xE7EDF2,
          false);
      g.drawString(
          font,
          font.plainSubstrByWidth(e.dimension() + "  " + e.pos().toShortString(), width - 32),
          16,
          yy + 11,
          0x94A6B2,
          false);
    }
    super.render(g, x, y, partial);
    g.drawString(
        font, font.plainSubstrByWidth(message, width - 24), 12, height - 16, 0x94A6B2, false);
  }
}
