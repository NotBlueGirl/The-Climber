package net.mcreator.climber.client.screens;

import java.util.*;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.item.DebuggerToolItem;
import net.mcreator.climber.mechanism.*;
import net.mcreator.climber.network.MechanismEditPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.*;
import net.minecraft.network.chat.Component;

/** Authoring parameters are saved to the held Creative Debugger. Right click a wall to place. */
public final class MechanismEditorScreen extends Screen {
  private final int target;
  private net.mcreator.climber.network.RemoteObjectReply remote;
  private MechanismSpec spec;
  private final List<EditBox> boxes = new ArrayList<>();
  private final Map<String, String> input = new HashMap<>();
  private final List<Line> labels = new ArrayList<>();
  private String message = "";
  private int scroll, contentEnd;
  private boolean buildingBody;

  private record Line(String text, int y) {}

  public MechanismEditorScreen(int target) {
    super(Component.literal("Creative Debugger / Mechanisms"));
    this.target = target;
    var mc = Minecraft.getInstance();
    if (target >= 0 && mc.level != null && mc.level.getEntity(target) instanceof MechanismEntity e)
      spec = MechanismSpec.load(e.spec().save());
    else if (mc.player != null) {
      var held =
          mc.player.getMainHandItem().getItem() instanceof DebuggerToolItem
              ? mc.player.getMainHandItem()
              : mc.player.getOffhandItem();
      spec = DebuggerToolItem.spec(held);
    } else spec = new MechanismSpec();
  }

  public MechanismEditorScreen(net.mcreator.climber.network.RemoteObjectReply reply) {
    this(0);
    remote = reply;
    spec = MechanismSpec.load(reply.tag());
    message = "Remote: " + reply.dimension() + " " + reply.pos().toShortString();
  }

  private Button btn(String t, int x, int y, int w, Runnable r) {
    var b = addRenderableWidget(new DebuggerActionButton(t, x, y, w, r));
    if (buildingBody) b.visible = y >= 52 && y + 20 <= bodyBottom();
    return b;
  }

  private int bodyBottom() {
    return target >= 0 ? height - 80 : height - 73;
  }

  private void rebuild() {
    clearWidgets();
    init();
  }

  private void field(String name, String key, String initial, int y) {
    labels.add(new Line(name, y));
    var e = new EditBox(font, bodyX(), y + 13, width - bodyX() - 16, 18, Component.literal(name));
    e.setMaxLength(key.equals("path") ? 4096 : 32);
    e.setBordered(false);
    e.setTextColor(0xE7EDF2);
    e.setValue(input.getOrDefault(key, initial));
    e.setResponder(v -> input.put(key, v));
    addRenderableWidget(e);
    e.visible = y >= 52 && y + 31 <= bodyBottom();
    boxes.add(e);
  }

  @Override
  protected void init() {
    boxes.clear();
    labels.clear();
    int tabY = 48;
    if (height < 230) {
      var choose =
          btn(
              "Type: "
                  + spec.kind
                      .name()
                      .replace("WEAK_HOOK", "Weak hook")
                      .replace("HOOK", "Hook")
                      .replace('_', ' ')
                  + " >",
              12,
              48,
              106,
              () -> {
                if (target >= 0) return;
                spec.kind =
                    MechanismSpec.Kind.values()[
                        (spec.kind.ordinal() + 1) % MechanismSpec.Kind.values().length];
                input.clear();
                scroll = 0;
                rebuild();
              });
      choose.active = target < 0;
    } else
      for (MechanismSpec.Kind kind : MechanismSpec.Kind.values()) {
        final MechanismSpec.Kind k = kind;
        var tab =
            btn(
                (spec.kind == kind ? "> " : "")
                    + (switch (kind) {
                      case VALVE -> "Valve";
                      case ROPE -> "Rope";
                      case PLATFORM -> "Platform";
                      case HOOK -> "Climbing hook";
                      case WEAK_HOOK -> "Weak hook";
                      case LADDER -> "Ladder";
                    }),
                12,
                tabY,
                106,
                () -> {
                  if (target >= 0) return;
                  spec.kind = k;
                  input.clear();
                  scroll = 0;
                  rebuild();
                });
        tab.active = target < 0 || spec.kind == kind;
        tabY += 25;
      }
    int y = 56 - scroll;
    buildingBody = true;
    switch (spec.kind) {
      case VALVE -> {
        field("Increment per turn", "step", "" + spec.valveStep, y);
        y += 39;
        field("Counter maximum", "max", "" + spec.valveMax, y);
        y += 39;
        btn(
            "Target action: " + spec.action,
            bodyX(),
            y,
            width - bodyX() - 16,
            () -> {
              var a = List.of("OPEN", "CLOSE", "TOGGLE", "PULSE");
              spec.action = a.get((a.indexOf(spec.action) + 1) % a.size());
              rebuild();
            });
        y += 24;
        if (remote == null)
          btn("Select a block", bodyX(), y, width - bodyX() - 16, () -> camera(true));
        else {
          field(
              "Target X,Y,Z (blank = support)",
              "valvePos",
              spec.valveTarget == null
                  ? ""
                  : spec.valveTarget.getX()
                      + ","
                      + spec.valveTarget.getY()
                      + ","
                      + spec.valveTarget.getZ(),
              y);
          y += 16;
        }
        y += 25;
        labels.add(
            new Line(
                spec.valveTarget == null
                    ? "Target: supporting block"
                    : "Target: " + spec.valveTarget.toShortString(),
                y));
        y += 22;
      }
      case ROPE -> {
        field("Length (blocks, 0.5..32)", "length", "" + spec.ropeLength, y);
        y += 39;
        labels.add(new Line("Grab end; WASD to swing, sprint for more force.", y));
        y += 24;
      }
      case PLATFORM -> {
        field("Round trip (seconds)", "seconds", "" + spec.roundTripSeconds, y);
        y += 39;
        field("Round trips (0 = continuous)", "repeats", "" + spec.repeats, y);
        y += 39;
        if (remote == null)
          btn("Select rail blocks (Camera)", bodyX(), y, width - bodyX() - 16, () -> camera(false));
        else {
          field("Route offsets x,y,z; x,y,z", "path", spec.pathText(), y);
          y += 16;
        }
        y += 25;
        btn(
            "Route: " + (spec.curved ? "curve" : "straight"),
            bodyX(),
            y,
            width - bodyX() - 16,
            () -> {
              spec.curved = !spec.curved;
              rebuild();
            });
        y += 25;
        labels.add(
            new Line(
                spec.railBlocks.isEmpty()
                    ? "No block selection (legacy offsets)"
                    : spec.railBlocks.size() + " rail blocks selected",
                y));
        y += 22;
        btn(
            "Needs redstone: " + spec.redstone,
            bodyX(),
            y,
            width - bodyX() - 16,
            () -> {
              spec.redstone = !spec.redstone;
              rebuild();
            });
        y += 24;
        btn(
            "Needs trigger: " + spec.trigger,
            bodyX(),
            y,
            width - bodyX() - 16,
            () -> {
              spec.trigger = !spec.trigger;
              rebuild();
            });
        y += 24;
        labels.add(new Line("Hooks travel with the platform; contact does not stop it.", y));
        y += 24;
      }
      case WEAK_HOOK -> {
        field("Total holding time before break (seconds)", "weak", "" + spec.weakSeconds, y);
        y += 39;
        labels.add(new Line("Lifetime is cumulative across hands and players.", y));
        y += 24;
      }
      case HOOK -> {
        labels.add(new Line("Red permanent handhold, placed at the exact aimed wall point.", y));
        y += 24;
      }
      case LADDER -> {
        labels.add(new Line("Place one half-depth ladder; place a second on the same block.", y));
        y += 22;
        labels.add(new Line("Projectile drops the connected front chain. Redstone retracts.", y));
        y += 22;
        labels.add(new Line("Up to 32 front layers; needs full chain length free below.", y));
        y += 22;
      }
    }
    contentEnd = y + scroll;
    buildingBody = false;
    int footerWidth = (width - 36) / 4;
    btn("Save", 12, height - 45, footerWidth, () -> send(0));
    btn(
        "Animator",
        20 + footerWidth,
        height - 45,
        footerWidth,
        () -> minecraft.setScreen(new AnimationEditorScreen()));
    btn(
        "UI editor",
        28 + footerWidth * 2,
        height - 45,
        footerWidth,
        () -> minecraft.setScreen(new SettingsLayoutScreen(this)));
    btn("Close", 36 + footerWidth * 3, height - 45, footerWidth - 12, this::onClose);
    btn(
        "Created objects",
        width - 128,
        height - 68,
        116,
        () -> minecraft.setScreen(new MechanismObjectScreen(this)));
    if (target >= 0) {
      btn(
          "Remove object",
          12,
          height - 68,
          110,
          () ->
              minecraft.setScreen(
                  new ConfirmScreen(
                      ok -> {
                        if (ok) {
                          send(1);
                          onClose();
                        } else minecraft.setScreen(this);
                      },
                      Component.literal("Remove this mechanism?"),
                      Component.literal("This removes the world object on the server."))));
      if (spec.kind == MechanismSpec.Kind.PLATFORM)
        btn("Start / stop", 126, height - 68, Math.max(58, width - 266), () -> send(2));
    }
  }

  private int bodyX() {
    return 138;
  }

  private void camera(boolean valve) {
    if (remote != null) {
      message = "Remote editing: use coordinate fields, not the local camera.";
      return;
    }
    if (minecraft.player == null || minecraft.level == null) {
      message = "Open this tool in a world.";
      return;
    }
    MechanismEntity object =
        target >= 0 && minecraft.level.getEntity(target) instanceof MechanismEntity e ? e : null;
    if (valve && object == null) {
      message = "Place a valve first, then edit it to select its target.";
      return;
    }
    try {
      readDraft();
      minecraft.setScreen(
          new MechanismCameraScreen(
              this,
              spec,
              object,
              valve,
              chosen -> {
                spec = chosen;
                input.clear();
                scroll = 0;
                send(0);
              }));
    } catch (RuntimeException e) {
      message = e.getMessage();
    }
  }

  private void readDraft() {
    spec.valveStep = number("step", spec.valveStep);
    spec.valveMax = number("max", spec.valveMax);
    spec.ropeLength = number("length", spec.ropeLength);
    spec.weakSeconds = number("weak", spec.weakSeconds);
    spec.roundTripSeconds = number("seconds", spec.roundTripSeconds);
    double n = number("repeats", spec.repeats);
    if (n != Math.rint(n)) throw new IllegalArgumentException("Round trips must be integer");
    spec.repeats = (int) n;
    spec.validate();
  }

  private double number(String key, double fallback) {
    return input.containsKey(key) ? Double.parseDouble(input.get(key)) : fallback;
  }

  private void send(int action) {
    try {
      if (minecraft.player == null || !minecraft.player.isCreative())
        throw new IllegalArgumentException("Creative mode required");
      boolean tool =
          minecraft.player.getMainHandItem().getItem() instanceof DebuggerToolItem
              || minecraft.player.getOffhandItem().getItem() instanceof DebuggerToolItem;
      if (!tool) throw new IllegalArgumentException("Hold the Creative Debugger Tool");
      spec.valveStep = number("step", spec.valveStep);
      spec.valveMax = number("max", spec.valveMax);
      spec.ropeLength = number("length", spec.ropeLength);
      spec.weakSeconds = number("weak", spec.weakSeconds);
      spec.roundTripSeconds = number("seconds", spec.roundTripSeconds);
      double repeats = number("repeats", spec.repeats);
      if (repeats != Math.rint(repeats))
        throw new IllegalArgumentException("Round trips must be an integer");
      spec.repeats = (int) repeats;
      if (input.containsKey("path") && !input.get("path").trim().equals(spec.pathText()))
        spec.setPath(input.get("path"));
      if (remote != null && input.containsKey("valvePos")) {
        String v = input.get("valvePos").trim();
        if (v.isEmpty()) spec.valveTarget = null;
        else {
          var xyz = v.split(",");
          if (xyz.length != 3) throw new IllegalArgumentException("Use integer X,Y,Z");
          spec.valveTarget =
              new net.minecraft.core.BlockPos(
                  Integer.parseInt(xyz[0].trim()),
                  Integer.parseInt(xyz[1].trim()),
                  Integer.parseInt(xyz[2].trim()));
        }
      }
      spec.validate();
      if (remote != null)
        ClimberMod.PACKET_HANDLER.sendToServer(
            new net.mcreator.climber.network.RemoteObjectPacket(
                remote.id(),
                action == 0 ? 1 : action == 1 ? 2 : 3,
                spec.save(),
                remote.revision()));
      else
        ClimberMod.PACKET_HANDLER.sendToServer(
            new MechanismEditPacket(spec.save(), target, action));
      message = "Request sent. Server confirmation appears in chat.";
    } catch (RuntimeException e) {
      message = e.getMessage() == null ? "Invalid value" : e.getMessage();
    }
  }

  @Override
  public boolean mouseScrolled(double x, double y, double d) {
    if (y >= 52 && y < bodyBottom()) {
      scroll =
          Math.max(0, Math.min(Math.max(0, contentEnd - bodyBottom()), scroll - (int) (d * 30)));
      rebuild();
      return true;
    }
    return super.mouseScrolled(x, y, d);
  }

  @Override
  public void tick() {
    boxes.forEach(EditBox::tick);
  }

  @Override
  public void onClose() {
    minecraft.setScreen(null);
  }

  @Override
  public boolean isPauseScreen() {
    return false;
  }

  @Override
  public void render(GuiGraphics g, int x, int y, float p) {
    g.fill(0, 0, width, height, 0xF510151B);
    g.drawString(
        font,
        remote == null ? "DEBUGGER  /  MECHANISMS" : "DEBUGGER  /  REMOTE OBJECT",
        16,
        12,
        0xFFE7EDF2,
        false);

    g.fill(124, 43, 125, bodyBottom(), 0x303E4C57);
    g.drawString(
        font,
        switch (spec.kind) {
          case VALVE -> "Valve";
          case ROPE -> "Rope";
          case PLATFORM -> "Platform";
          case HOOK -> "Climbing hook";
          case WEAK_HOOK -> "Weak hook";
          case LADDER -> "Ladder";
        },
        bodyX(),
        33,
        0xFF70B7F0,
        false);
    g.enableScissor(bodyX(), 52, width - 12, bodyBottom());
    for (Line l : labels)
      if (l.y == 32 || l.y >= 52 && l.y + 10 < bodyBottom())
        g.drawWordWrap(
            font, Component.literal(l.text), bodyX(), l.y, width - bodyX() - 16, 0xFFB5C1CB);
    g.disableScissor();
    if (contentEnd > bodyBottom()) {
      g.drawString(font, "Wheel: scroll", width - 92, 10, 0xFF888888, false);
      int full = contentEnd - 52,
          visible = bodyBottom() - 52,
          thumb = Math.max(10, visible * visible / full),
          ty = 52 + (int) (scroll * (visible - thumb) / (float) (full - visible));
      g.fill(width - 7, 52, width - 6, bodyBottom(), 0x30FFFFFF);
      g.fill(width - 8, ty, width - 5, ty + thumb, 0xFF70B7F0);
    }
    for (EditBox box : boxes)
      if (box.visible)
        g.fill(
            box.getX(),
            box.getY() + box.getHeight(),
            box.getX() + box.getWidth(),
            box.getY() + box.getHeight() + 1,
            0xFF40505C);
    super.render(g, x, y, p);
    g.drawString(
        font, font.plainSubstrByWidth(message, width - 24), 12, height - 17, 0xFF70B7F0, false);
  }
}
