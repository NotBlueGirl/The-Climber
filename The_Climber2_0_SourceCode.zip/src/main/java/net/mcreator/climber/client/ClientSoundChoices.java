package net.mcreator.climber.client;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;

/** Per-PC file preferences. Never sent to server or other clients. */
public final class ClientSoundChoices {
  private static final Path FILE = Path.of("config", "climber_local_sounds.json");
  private static final Map<String, String> values = new HashMap<>();

  public static String get(String key, String fallback) {
    return values.getOrDefault(key, fallback);
  }

  public static String local(String key) {
    return values.getOrDefault(key, "");
  }

  public static void set(String key, String path) {
    if (!Set.of("grabHitSound", "grabJumpSound").contains(key))
      throw new IllegalArgumentException("Unknown sound slot");
    if (path.isBlank()) values.remove(key);
    else {
      Path f = Path.of(path).toAbsolutePath().normalize();
      if (!Files.isRegularFile(f)) throw new IllegalArgumentException("Choose an existing file");
      String ext = f.toString().toLowerCase(Locale.ROOT);
      if (!ext.endsWith(".ogg") && !ext.endsWith(".wav"))
        throw new IllegalArgumentException("Choose .ogg or PCM .wav");
      values.put(key, f.toString());
    }
    save();
  }

  public static void load() {
    values.clear();
    if (!Files.exists(FILE)) return;
    try {
      JsonObject t = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
      for (String k : List.of("grabHitSound", "grabJumpSound"))
        if (t.has(k)) values.put(k, t.get(k).getAsString());
    } catch (Exception e) {
      net.mcreator.climber.ClimberMod.LOGGER.warn("Cannot load local sounds", e);
    }
  }

  private static void save() {
    try {
      Files.createDirectories(FILE.getParent());
      Path tmp = FILE.resolveSibling(FILE.getFileName() + ".tmp");
      Files.writeString(tmp, new GsonBuilder().setPrettyPrinting().create().toJson(values));
      try {
        Files.move(tmp, FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
      } catch (AtomicMoveNotSupportedException e) {
        Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
      }
    } catch (Exception e) {
      throw new IllegalArgumentException("Could not save sound choices: " + e.getMessage());
    }
  }
}
