package net.mcreator.climber.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;

/**
 * Climber mode: a small diamond is shown at the crosshair while it points at a "work" block - any
 * block with its own interface (crafting table, chest, furnace, anvil, ...). Right click on such a
 * block opens it instead of grabbing.
 */
@OnlyIn(Dist.CLIENT)
public class InteractableCrosshair {
    private static float anim = 0f;

    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "climber_interact_diamond", InteractableCrosshair::render);
    }

    /** Block under the crosshair has a GUI (menu). */
    public static boolean lookingAtInterface(Minecraft mc) {
        if (mc.level == null || !(mc.hitResult instanceof BlockHitResult bhr) || bhr.getType() != HitResult.Type.BLOCK) return false;
        return isInterfaceBlock(mc.level, bhr.getBlockPos());
    }

    public static boolean isInterfaceBlock(Level level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.isAir()) return false;
        if (st.getBlock() instanceof EnderChestBlock) return true;
        try {
            if (st.getMenuProvider(level, pos) != null) return true;
        } catch (RuntimeException ignored) {
            // some modded blocks only build their menu on the server
        }
        BlockEntity be = level.getBlockEntity(pos);
        return be instanceof MenuProvider;
    }

    private static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        boolean show = ClimberClientData.climbEnabled && mc.player != null && !mc.options.hideGui
                && mc.screen == null && mc.options.getCameraType().isFirstPerson() && lookingAtInterface(mc);
        anim += ((show ? 1f : 0f) - anim) * 0.35f;
        if (anim < 0.03f) return;
        int cx = w / 2, cy = h / 2;
        int r = Math.round(4 + 3 * anim); // pops open
        int alpha = Math.round(235 * anim);
        int col = (alpha << 24) | 0xF2EEE4;
        int shadow = (Math.round(150 * anim) << 24);
        // hollow diamond outline (2 px) around the crosshair, with a dark shadow for contrast
        drawDiamond(g, cx + 1, cy + 1, r, shadow);
        drawDiamond(g, cx, cy, r, col);
        // tiny filled centre
        g.fill(cx - 1, cy - 1, cx + 1, cy + 1, col);
    }

    private static void drawDiamond(GuiGraphics g, int cx, int cy, int r, int col) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = r - Math.abs(dy);
            g.fill(cx - dx - 1, cy + dy, cx - dx + 1, cy + dy + 1, col);
            if (dx > 0) g.fill(cx + dx - 1, cy + dy, cx + dx + 1, cy + dy + 1, col);
        }
    }
}
