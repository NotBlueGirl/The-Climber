package net.mcreator.climber.client;

import net.mcreator.climber.client.screens.ItemDisplayEditorScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** Debug entry points: item display mode and /climbdebug animation skeletal editor. */
@OnlyIn(Dist.CLIENT)
public class ItemDisplayDebug {
  static boolean openRequested = false;
  static boolean animationRequested = false;
  static boolean uiRequested = false, mechanismsRequested = false;

  @SubscribeEvent
  public void onRegisterCommands(RegisterClientCommandsEvent event) {
    event
        .getDispatcher()
        .register(
            Commands.literal("climbdebug")
                .executes(
                    c -> {
                      openRequested = true;
                      return 1;
                    })
                .then(
                    Commands.literal("display")
                        .executes(
                            c -> {
                              openRequested = true;
                              return 1;
                            }))
                .then(
                    Commands.literal("animation")
                        .executes(
                            c -> {
                              openRequested = true;
                              animationRequested = true;
                              return 1;
                            }))
                .then(
                    Commands.literal("ui")
                        .executes(
                            c -> {
                              openRequested = true;
                              uiRequested = true;
                              return 1;
                            }))
                .then(
                    Commands.literal("mechanisms")
                        .executes(
                            c -> {
                              openRequested = true;
                              mechanismsRequested = true;
                              return 1;
                            }))
                .then(
                    Commands.literal("reload")
                        .executes(
                            c -> {
                              ItemDisplayOverrides.load();
                              c.getSource()
                                  .sendSuccess(
                                      () -> Component.literal("Item display overrides reloaded."),
                                      false);
                              return 1;
                            })));
  }

  @SubscribeEvent
  public void onClientTick(TickEvent.ClientTickEvent event) {
    if (event.phase != TickEvent.Phase.END) return;
    Minecraft mc = Minecraft.getInstance();
    if (mc.player == null) return;
    while (ClimberKeybinds.KEY_ITEM_EDITOR.consumeClick())
      if (mc.screen == null) openRequested = true;
    if (openRequested && mc.screen == null) {
      openRequested = false;
      if (uiRequested) {
        uiRequested = false;
        mc.setScreen(new net.mcreator.climber.client.screens.SettingsLayoutScreen(null));
      } else if (mechanismsRequested) {
        mechanismsRequested = false;
        mc.setScreen(new net.mcreator.climber.client.screens.MechanismEditorScreen(-1));
      } else if (animationRequested) {
        animationRequested = false;
        mc.setScreen(new net.mcreator.climber.client.screens.AnimationEditorScreen());
      } else mc.setScreen(new ItemDisplayEditorScreen());
    }
  }
}
