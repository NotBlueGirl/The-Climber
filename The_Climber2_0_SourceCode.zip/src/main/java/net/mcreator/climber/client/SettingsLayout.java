package net.mcreator.climber.client;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;

/** Local-only, normalized layout data. Defaults preserve the original dark/yellow settings menu. */
public final class SettingsLayout {
  public static final Path FILE = Path.of("config", "climber_settings_ui.json");
  public static final String[] PARTS = {"Header", "Tabs", "Panel"};

  public static final class Element {
    public float x = 0, y = 0, scale = 1;
    public boolean visible = true;
    public String label = "";
  }

  public int version = 1;
  public String accent = "E8C547";
  public float rowSpacing = 22;
  public Map<String, Element> elements = new LinkedHashMap<>();
  private static SettingsLayout current;

  public Element element(String id) {
    return elements.computeIfAbsent(id, k -> new Element());
  }

  public int color() {
    try {
      return 0xFF000000 | Integer.parseInt(accent, 16);
    } catch (Exception e) {
      return 0xFFE8C547;
    }
  }

  public String label(String id, String fallback) {
    Element e = element(id);
    return e.label.isBlank() ? fallback : e.label;
  }

  public void validate() {
    if (version != 1) throw new IllegalArgumentException("Unsupported UI version");
    if (accent == null || !accent.matches("[0-9a-fA-F]{6}"))
      throw new IllegalArgumentException("Accent must be six hexadecimal digits");
    if (!Float.isFinite(rowSpacing) || rowSpacing < 16 || rowSpacing > 60)
      throw new IllegalArgumentException("Row spacing must be 16..60");
    if (elements == null || elements.size() > 128)
      throw new IllegalArgumentException("Too many UI elements");
    for (var entry : elements.entrySet()) {
      Element e = entry.getValue();
      if (e == null
          || !Float.isFinite(e.x)
          || !Float.isFinite(e.y)
          || !Float.isFinite(e.scale)
          || Math.abs(e.x) > .7
          || Math.abs(e.y) > .7
          || e.scale < .5
          || e.scale > 2
          || e.label == null
          || e.label.length() > 40)
        throw new IllegalArgumentException("Invalid UI element: " + entry.getKey());
      if (Set.of(PARTS).contains(entry.getKey())) e.visible = true;
    }
  }

  public SettingsLayout copy() {
    return new Gson().fromJson(new Gson().toJson(this), SettingsLayout.class);
  }

  public static SettingsLayout get() {
    if (current == null) {
      current = new SettingsLayout();
      if (Files.exists(FILE))
        try {
          SettingsLayout c = new Gson().fromJson(Files.readString(FILE), SettingsLayout.class);
          c.validate();
          current = c;
        } catch (Exception e) {
          net.mcreator.climber.ClimberMod.LOGGER.warn(
              "Invalid settings layout; using original design", e);
        }
    }
    return current;
  }

  public static void save(SettingsLayout c) {
    c.validate();
    try {
      Files.createDirectories(FILE.getParent());
      Path tmp = FILE.resolveSibling(FILE.getFileName() + ".tmp");
      Files.writeString(tmp, new GsonBuilder().setPrettyPrinting().create().toJson(c));
      try {
        Files.move(tmp, FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
      } catch (AtomicMoveNotSupportedException e) {
        Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
      }
      current = c.copy();
    } catch (java.io.IOException e) {
      throw new IllegalArgumentException("Could not save layout: " + e.getMessage());
    }
  }

  public static List<String> controls() {
    return List.of(
        "Header",
        "Tabs",
        "Panel",
        "tab:Climbing",
        "tab:Stamina",
        "tab:Hand position",
        "tab:Block lists",
        "tab:Sounds",
        "tab:Help",
        "tab:Gameplay",
        "row:DoorPhysics",
        "row:RebarKnockback",
        "row:MaxTimeCrackLight",
        "row:ClickCrankRegen",
        "row:ClimberGravity",
        "row:RopeSwingStrenght",
        "row:DoorHitboxX",
        "row:DoorHitboxY",
        "row:DoorHitboxZ",
        "row:DoorHitboxPosX",
        "row:DoorHitboxPosY",
        "row:DoorHitboxPosZ",
        "row:Climbing",
        "row:Grip mode",
        "row:Auto grip",
        "row:Jump strength (two hands)",
        "row:Jump strength (one hand)",
        "row:Stamina",
        "row:Max stamina",
        "row:Drain speed",
        "row:Recovery speed",
        "row:Hand X",
        "row:Hand Y",
        "row:Hand Z",
        "row:Include blocks",
        "row:Exclude blocks",
        "row:Grab-hit file",
        "row:Grab-jump file",
        "row:Preview hit",
        "row:Reset hit file",
        "row:Server hit sound",
        "row:Preview jump",
        "row:Reset jump file",
        "row:Server jump sound");
  }
}
