package net.mcreator.climber.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.mcreator.climber.entity.RebarEntity;
import net.mcreator.climber.init.ClimberModItems;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/** Renders the 3D rebar model (assets/climber/models/item/rebar.json) flying / stuck in a surface. */
public class RebarRenderer extends EntityRenderer<RebarEntity> {
    private static final float LENGTH = 0.72f;   // model scale (30 px model -> 1.35 blocks)
    private static final double EMBED = 0.22;   // how deep the tip goes into the wall
    private final ItemRenderer itemRenderer;
    private ItemStack stack;

    public RebarRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.itemRenderer = ctx.getItemRenderer();
        this.shadowRadius = 0f;
    }

    @Override
    public void render(RebarEntity e, float yaw, float partialTick, PoseStack pose, MultiBufferSource buf, int light) {
        if (stack == null) stack = new ItemStack(ClimberModItems.REBAR.get());

        Vec3 d; // direction of travel (tip first)
        if (e.isStuck()) {
            d = e.getStuckDir();
        } else {
            Vec3 v = e.getDeltaMovement();
            d = v.lengthSqr() > 1.0e-6 ? v.normalize() : e.getStuckDir();
        }
        Vec3 out = d.scale(-1);

        pose.pushPose();
        pose.mulPose(new Quaternionf().rotationTo(0f, 1f, 0f, (float) out.x, (float) out.y, (float) out.z));
        if (!e.isStuck()) {
            // spin in flight
            pose.mulPose(Axis.YP.rotationDegrees((e.tickCount + partialTick) * 40f));
        } else if (e.shakeTime > 0) {
            float s = e.shakeTime - partialTick;
            pose.mulPose(Axis.XP.rotationDegrees(-Mth.sin(s * 3f) * s * 0.8f));
        }
        // model tip sits at y=-6px; straighten the diagonal (-45 deg) item model
        pose.translate(0, -EMBED + LENGTH * (14.0 / 16.0), 0);
        pose.scale(LENGTH, LENGTH, LENGTH);
        pose.mulPose(Axis.ZP.rotationDegrees(45f));
        itemRenderer.renderStatic(stack, ItemDisplayContext.FIXED, light, OverlayTexture.NO_OVERLAY, pose, buf, e.level(), e.getId());
        pose.popPose();
        super.render(e, yaw, partialTick, pose, buf, light);
    }

    /** The entity sits right on the block face, so sample light just outside the wall instead of inside it. */
    private static net.minecraft.core.BlockPos lightPos(RebarEntity e) {
        Vec3 out = e.isStuck() ? e.getStuckDir().scale(-0.35) : Vec3.ZERO;
        return net.minecraft.core.BlockPos.containing(e.position().add(out));
    }

    @Override
    protected int getBlockLightLevel(RebarEntity e, net.minecraft.core.BlockPos pos) {
        return e.level().getBrightness(net.minecraft.world.level.LightLayer.BLOCK, lightPos(e));
    }

    @Override
    protected int getSkyLightLevel(RebarEntity e, net.minecraft.core.BlockPos pos) {
        return e.level().getBrightness(net.minecraft.world.level.LightLayer.SKY, lightPos(e));
    }

    @Override
    @SuppressWarnings("deprecation")
    public ResourceLocation getTextureLocation(RebarEntity e) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
