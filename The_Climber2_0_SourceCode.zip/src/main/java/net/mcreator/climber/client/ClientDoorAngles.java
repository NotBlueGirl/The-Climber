package net.mcreator.climber.client;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;

/** Client copy of the server door angles (lower-half position -> angle), interpolated per frame. */
@OnlyIn(Dist.CLIENT)
public class ClientDoorAngles {

  // read from the chunk-mesh builder threads (BlockRenderDispatcherMixin) -> concurrent map
  private static final Map<Long, Entry> ANGLES = new ConcurrentHashMap<>();

  private static class Entry {
    volatile float prev;
    volatile float current;

    Entry(float value) {
      this.prev = value;
      this.current = value;
    }
  }

  /** Call once at the end of every client tick so "current" becomes "prev" for interpolation. */
  public static void beginTick() {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()
        && !ANGLES.isEmpty()) {
      for (long key : ANGLES.keySet()) requestRerender(BlockPos.of(key));
      ANGLES.clear();
    }
    for (Entry e : ANGLES.values()) e.prev = e.current;
  }

  public static void set(BlockPos lower, float angle) {
    long key = lower.asLong();
    if (Float.isNaN(angle)) {
      if (ANGLES.remove(key) != null) requestRerender(lower);
      return;
    }
    Entry e = ANGLES.get(key);
    if (e == null) {
      ensureBlockEntities(lower);
      ANGLES.put(key, new Entry(angle));
      requestRerender(lower); // remove the door from the static chunk mesh
      return;
    }
    e.current = angle; // per-frame renderer picks it up, no chunk rebuild needed
  }

  public static void clear() {
    ANGLES.clear();
  }

  public static void removeInChunk(ChunkPos cp) {
    ANGLES
        .keySet()
        .removeIf(
            k -> {
              BlockPos p = BlockPos.of(k);
              return (p.getX() >> 4) == cp.x && (p.getZ() >> 4) == cp.z;
            });
  }

  @Nullable
  public static Float getFor(BlockGetter level, BlockPos pos) {
    Entry e = getEntry(level, pos);
    return e == null ? null : e.current;
  }

  public static float getInterpolated(BlockGetter level, BlockPos pos, float partialTick) {
    Entry e = getEntry(level, pos);
    if (e == null) return 0.0F;
    return e.prev + (e.current - e.prev) * partialTick;
  }

  @Nullable
  private static Entry getEntry(BlockGetter level, BlockPos pos) {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()) return null;
    BlockState st = level.getBlockState(pos);
    if (!(st.getBlock() instanceof DoorBlock)) return null;
    BlockPos lower = st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? pos.below() : pos;
    return ANGLES.get(lower.asLong());
  }

  /** Old worlds: doors placed before the mod was installed have no block entity -> create it. */
  private static void ensureBlockEntities(BlockPos lower) {
    Minecraft mc = Minecraft.getInstance();
    if (mc.level == null || !mc.level.isLoaded(lower)) return;
    mc.level.getBlockEntity(lower);
    mc.level.getBlockEntity(lower.above());
  }

  private static void requestRerender(BlockPos lower) {
    Minecraft mc = Minecraft.getInstance();
    if (mc.level == null || mc.levelRenderer == null) return;
    BlockPos upper = lower.above();
    mc.levelRenderer.setBlocksDirty(
        lower.getX(), lower.getY(), lower.getZ(), upper.getX(), upper.getY(), upper.getZ());
  }
}
