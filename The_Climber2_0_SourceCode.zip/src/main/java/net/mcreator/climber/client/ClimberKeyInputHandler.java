package net.mcreator.climber.client;

import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.init.ClimberModSounds;
import net.mcreator.climber.network.ClimbJumpPacket;
import net.mcreator.climber.network.DoorJumpPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;
import org.lwjgl.glfw.GLFW;

@OnlyIn(Dist.CLIENT)
public class ClimberKeyInputHandler {

  @SubscribeEvent
  public void onKeyInput(InputEvent.Key event) {
    Minecraft mc = Minecraft.getInstance();

    if (mc.player == null || mc.screen != null) return;
    if (!mc.options.keyJump.matches(event.getKey(), event.getScanCode())) return;
    if (event.getAction() != GLFW.GLFW_PRESS) return;

    // Сначала обрабатываем дверь, потому что это может работать даже при выключенном climb mode
    if (ClientDoorGrab.currentLower != null) {
      if (!ClimberClientData.climbEnabled) {
        // Если climber mode выключен: прыжок просто отпускает дверь
        ClientDoorGrab.releaseIfGrabbing();
        return;
      }

      // Если climber mode включён: прыжок от двери
      Vec3 look = mc.player.getLookAngle();
      float strength = ClimberConfig.INSTANCE.getStrengthJumpOneHand();

      mc.player.setDeltaMovement(
          new Vec3(look.x, look.y + 0.3D, look.z).normalize().scale(strength));

      mc.player.setNoGravity(false);
      ClientDoorGrab.releaseIfGrabbing();

      ClimberMod.PACKET_HANDLER.sendToServer(new DoorJumpPacket());

      // Можно использовать ваш кастомный звук прыжка.
      // Для простоты здесь используется встроенный.
      mc.player.playSound(ClimberModSounds.GRAB_JUMP.get(), 0.7F, 1.0F);

      return;
    }

    if (!ClimberClientData.climbEnabled) return;

    boolean anyGrabbing = ClimberClientData.rightGrabbing || ClimberClientData.leftGrabbing;
    if (!anyGrabbing) return;

    boolean bothHands = ClimberClientData.rightGrabbing && ClimberClientData.leftGrabbing;

    Vec3 rightAnchor = ClimberClientData.rightAnchor;
    Vec3 leftAnchor = ClimberClientData.leftAnchor;

    ClimberClientData.rightGrabbing = false;
    ClimberClientData.leftGrabbing = false;
    ClimberClientData.rightAnchor = null;
    ClimberClientData.leftAnchor = null;
    ClimberClientData.rightAnchorDir = null;
    ClimberClientData.leftAnchorDir = null;

    if (bothHands && rightAnchor != null && leftAnchor != null) {
      Vec3 look = mc.player.getLookAngle();
      float strength = ClimberConfig.INSTANCE.getStrengthJumpBothHands();
      mc.player.setDeltaMovement(
          new Vec3(look.x, look.y + 0.55D, look.z).normalize().scale(strength));
    } else {
      Vec3 look = mc.player.getLookAngle();
      float strength = ClimberConfig.INSTANCE.getStrengthJumpOneHand();
      mc.player.setDeltaMovement(
          new Vec3(look.x, look.y + 0.3D, look.z).normalize().scale(strength));
    }

    mc.player.setNoGravity(false);

    boolean played = false;
    String customJump =
        ClientSoundChoices.get("grabJumpSound", ClimberConfig.INSTANCE.getGrabJumpSound());

    if (customJump != null && !customJump.isEmpty()) {
      if (ClimberSoundPreloader.isFilePath(customJump)) {
        ClimberSoundPreloader.playAt(customJump, 0.7F, 1.0F, mc.player.position());
        played = true;
      } else {
        try {
          ResourceLocation rl = new ResourceLocation(customJump);
          SoundEvent ev = ForgeRegistries.SOUND_EVENTS.getValue(rl);

          if (ev != null) {
            mc.player.playSound(ev, 0.7F, 1.0F);
            played = true;
          }
        } catch (Exception e) {
          ClimberMod.LOGGER.warn("[Climber] Invalid grab-jump registry ID: '{}'", customJump);
        }
      }
    }

    if (!played) {
      mc.player.playSound(ClimberModSounds.GRAB_JUMP.get(), 0.7F, 1.0F);
    }

    ClimberMod.PACKET_HANDLER.sendToServer(new ClimbJumpPacket(bothHands));
  }
}
