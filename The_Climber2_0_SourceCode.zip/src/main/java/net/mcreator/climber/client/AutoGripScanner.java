package net.mcreator.climber.client;

import net.mcreator.climber.grip.AutoGripMode;
import net.mcreator.climber.grip.GripMode;
import net.mcreator.climber.network.HandGrabPacket;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Auto Grip: пока кнопка захвата (ПКМ/ЛКМ) удерживается и рука ещё не зацеплена, каждый тик
 * проверяет, куда сейчас смотрит игрок — и как только прицел попадает на подходящую цель (блок в
 * режиме Lip Hands, выступ в режиме Realistic), захват происходит автоматически, без необходимости
 * отпускать и заново нажимать кнопку.
 *
 * <p>Управляется настройкой {@link AutoGripMode} (см. "/climb autogrip
 * off|only_liphands|only_realistic|both").
 */
@OnlyIn(Dist.CLIENT)
public final class AutoGripScanner {

  private AutoGripScanner() {}

  /** Вызывается каждый клиентский тик локального игрока. */
  public static void tick(Minecraft mc) {
    if (mc.player == null || mc.level == null || mc.screen != null) return;
    if (!ClimberClientData.climbEnabled) return;

    AutoGripMode mode = ClimberClientData.autoGripMode;
    if (mode == AutoGripMode.OFF) return;

    GripMode currentGrip =
        ClimberClientData.gripModeRealistic ? GripMode.REALISTIC : GripMode.LIP_HANDS;
    if (!mode.isActiveFor(currentGrip)) return;

    tryAutoGrab(
        mc,
        true,
        ClimberClientData.rightMouseDown,
        ClimberClientData.rightGrabbing,
        ClimberClientData.rightExhausted);
    tryAutoGrab(
        mc,
        false,
        ClimberClientData.leftMouseDown,
        ClimberClientData.leftGrabbing,
        ClimberClientData.leftExhausted);
  }

  private static void tryAutoGrab(
      Minecraft mc, boolean right, boolean mouseDown, boolean grabbing, boolean exhausted) {
    if (!mouseDown || grabbing || exhausted) return;
    // right hand holding a climbing tool uses the tool instead of grabbing
    if (!mc.player.getItemInHand(ClimberInputHandler.itemHand(mc.player, right)).isEmpty()) return;
    ClimberInputHandler.tryGrab(mc, right ? HandGrabPacket.HAND_RIGHT : HandGrabPacket.HAND_LEFT);
  }
}
