package net.mcreator.climber.client;

import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

/** Side-safe entry point used by common code (mixins) to reach client-only door code. */
public final class ClientDoorGrabBridge {
    private ClientDoorGrabBridge() {}

    public static void press(BlockPos pos, Vec3 hit) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientDoorGrab.press(pos, hit));
    }
}
