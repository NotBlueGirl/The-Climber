package net.mcreator.climber.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.mcreator.climber.blockentity.DoorBlockEntity;
import net.mcreator.climber.client.ClientDoorAngles;
import net.mcreator.climber.door.DoorGeometry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/**
 * Рисует дверь КАЖДЫЙ КАДР (не только при перестройке чанка), поворачивая её вокруг
 * петли на угол, интерполированный между предыдущим и текущим сетевым значением
 * (ClientDoorAngles.getInterpolated), используя реальный partialTick кадра.
 * <p>
 * Рендерится только если для позиции этой двери есть активная запись угла —
 * т.е. только для дверей, которые прямо сейчас открывают/закрывают. Как только
 * запись исчезает (ClientDoorAngles.set(pos, NaN)), BlockRenderDispatcherMixin
 * перестаёт отменять batched-рендер, и дверь снова рисуется статично из chunk-меша
 * без какого-либо участия этого рендерера.
 */
public class DoorBlockEntityRenderer implements BlockEntityRenderer<DoorBlockEntity> {

    public DoorBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(DoorBlockEntity be, float partialTick, PoseStack pose,
                        MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
        Level level = be.getLevel();
        BlockPos pos = be.getBlockPos();
        if (level == null) return;

        if (ClientDoorAngles.getFor(level, pos) == null) return; // не анимируется — статический меш чанка уже рисует эту дверь

        BlockState state = be.getBlockState();
        if (!(state.getBlock() instanceof DoorBlock)) return;

        BlockPos lower = state.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? pos.below() : pos;
        BlockState lowerState = level.getBlockState(lower);
        if (!(lowerState.getBlock() instanceof DoorBlock)) return;

        float angle = ClientDoorAngles.getInterpolated(level, pos, partialTick);

        Direction facing = lowerState.getValue(DoorBlock.FACING);
        boolean hingeRight = lowerState.getValue(DoorBlock.HINGE) == DoorHingeSide.RIGHT;

        double[] o = DoorGeometry.hingeOffsetLocal(facing, hingeRight);
        double hingeLocalX = 0.5 + o[0];
        double hingeLocalZ = 0.5 + o[1];

        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BlockState closed = state.setValue(DoorBlock.OPEN, false);

        pose.pushPose();
        pose.translate(hingeLocalX, 0, hingeLocalZ);
        // ВАЖНО: Axis.YP.rotationDegrees(+angle) поворачивает от +Z к +X (стандартная
        // кватернионная математика по правилу правой руки для оси +Y), тогда как
        // DoorGeometry.plankDir/rotatedShape поворачивают вектор (x, z) от +X к +Z при
        // положительном angleDeg (обычная 2D-матрица поворота). Это противоположные
        // направления при одном и том же знаке угла, поэтому здесь угол инвертируется,
        // чтобы модель поворачивалась СИНХРОННО с хитбоксом.
        pose.mulPose(Axis.YP.rotationDegrees(-angle));
        pose.translate(-hingeLocalX, 0, -hingeLocalZ);

        // renderType = null -> dispatcher сам определяет подходящий RenderType по модели блока,
        // как это делает ванильный batched-рендер (не хардкодим cutout, чтобы не сломать
        // двери с другим типом прозрачности/материала из сторонних модов).
        dispatcher.renderSingleBlock(
                closed, pose, bufferSource, packedLight, packedOverlay,
                ModelData.EMPTY, null
        );

        pose.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen(DoorBlockEntity be) {
        return false;
    }

    @Override
    public int getViewDistance() {
        return 64;
    }
}
