package net.mcreator.climber.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.mcreator.climber.item.CrankFlashlightItem;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Matrix4f;

/**
 * Visible flashlight beam: a soft additive light cone coming out of the torch in the player's hand
 * along the view direction, plus a round light spot where it hits a surface. Brightness follows the
 * dynamo charge. Drawn for every player holding a shining flashlight.
 */
@OnlyIn(Dist.CLIENT)
public class FlashlightBeamRenderer {
  private static final int SEG = 20;

  @SubscribeEvent
  public void onRenderLevel(RenderLevelStageEvent event) {
    if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
    Minecraft mc = Minecraft.getInstance();
    if (mc.level == null || mc.player == null) return;
    float partial = event.getPartialTick();
    Camera cam = event.getCamera();
    Vec3 cp = cam.getPosition();
    PoseStack ps = event.getPoseStack();

    RenderSystem.enableBlend();
    RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
    RenderSystem.disableCull();
    RenderSystem.depthMask(false);
    RenderSystem.enableDepthTest();
    RenderSystem.setShader(GameRenderer::getPositionColorShader);
    for (Player p : mc.level.players()) {
      if (p.isSpectator() || p.distanceToSqr(cp) > 96 * 96) continue;
      ItemStack light = null;
      InteractionHand hand = InteractionHand.MAIN_HAND;
      for (InteractionHand h : InteractionHand.values()) {
        if (CrankFlashlightItem.isShining(p.getItemInHand(h))) {
          light = p.getItemInHand(h);
          hand = h;
          break;
        }
      }
      if (light == null) continue;
      drawBeam(mc, ps, cam, cp, p, light, hand, partial);
    }
    RenderSystem.depthMask(true);
    RenderSystem.enableCull();
    RenderSystem.defaultBlendFunc();
    RenderSystem.disableBlend();
  }

  private static void drawBeam(
      Minecraft mc,
      PoseStack ps,
      Camera cam,
      Vec3 cp,
      Player p,
      ItemStack light,
      InteractionHand hand,
      float partial) {
    float frac =
        Mth.clamp(
            (float) CrankFlashlightItem.getCharge(light) / CrankFlashlightItem.maxCharge(), 0f, 1f);
    float power = 0.25f + 0.75f * frac;
    if (frac < 0.1f && p.getRandom().nextFloat() < 0.3f * (1f - frac / 0.1f))
      power *= 0.4f; // dying dynamo flickers

    Vec3 eye = p.getEyePosition(partial);
    Vec3 look = p.getViewVector(partial);
    // beam origin: the centre of the player's body (chest), slightly in front of it
    Vec3 up = new Vec3(0, 1, 0);
    Vec3 origin = chestOrigin(p, partial, look);
    double range =
        6 + 28.0 * CrankFlashlightItem.brightness(CrankFlashlightItem.getCharge(light)) / 15.0;
    BlockHitResult hit =
        mc.level.clip(
            new ClipContext(
                eye,
                eye.add(look.scale(range)),
                ClipContext.Block.VISUAL,
                ClipContext.Fluid.NONE,
                p));
    boolean miss = hit.getType() == HitResult.Type.MISS;
    Vec3 target = miss ? eye.add(look.scale(range)) : hit.getLocation();
    Vec3 axis = target.subtract(origin);
    double len = axis.length();
    if (len < 0.3) return;
    Vec3 dir = axis.scale(1 / len);
    double beamLen = Math.min(len, 18.0);

    ps.pushPose();
    Matrix4f m = ps.last().pose();
    // basis around the beam axis
    Vec3 a =
        Math.abs(dir.y) < 0.95
            ? dir.cross(up).normalize()
            : dir.cross(new Vec3(1, 0, 0)).normalize();
    Vec3 b = dir.cross(a).normalize();
    float r = 1.0f, g = 0.93f, bl = 0.74f;

    // two nested cones: a faint wide halo and a brighter core
    cone(
        m,
        origin.subtract(cp),
        dir,
        a,
        b,
        0.05,
        0.05 + beamLen * 0.20,
        beamLen,
        0.11f * power,
        r,
        g,
        bl);
    cone(
        m,
        origin.subtract(cp),
        dir,
        a,
        b,
        0.03,
        0.03 + beamLen * 0.09,
        beamLen * 0.85,
        0.13f * power,
        r,
        g,
        bl);

    if (!miss) {
      // light spot on the surface
      double dist = target.distanceTo(origin);
      Direction face = hit.getDirection();
      Vec3 n = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
      Vec3 c = target.add(n.scale(0.01)).subtract(cp);
      Vec3 ta =
          Math.abs(n.y) < 0.9 ? n.cross(up).normalize() : n.cross(new Vec3(1, 0, 0)).normalize();
      Vec3 tb = n.cross(ta).normalize();
      float fade = (float) Mth.clamp(1.0 - dist / (range + 2), 0.15, 1.0);
      disc(m, c, ta, tb, 0.35 + dist * 0.16, 0.55f * power * fade, r, g, bl);
      disc(m, c, ta, tb, 0.15 + dist * 0.07, 0.45f * power * fade, r, g, bl);
    }
    ps.popPose();
  }

  /** Centre of the body at chest height, pushed a little forward along the horizontal view. */
  public static Vec3 chestOrigin(Player p, float partial, Vec3 look) {
    Vec3 pos = p.getPosition(partial);
    Vec3 flat = new Vec3(look.x, 0, look.z);
    flat = flat.lengthSqr() < 1.0e-4 ? Vec3.ZERO : flat.normalize();
    return pos.add(0, p.getBbHeight() * 0.58, 0).add(flat.scale(0.32));
  }

  private static void cone(
      Matrix4f m,
      Vec3 o,
      Vec3 dir,
      Vec3 a,
      Vec3 b,
      double r0,
      double r1,
      double len,
      float alpha,
      float r,
      float g,
      float bl) {
    BufferBuilder bb = Tesselator.getInstance().getBuilder();
    bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
    int steps = 6;
    for (int s = 0; s < steps; s++) {
      double t0 = (double) s / steps, t1 = (double) (s + 1) / steps;
      float a0 = alpha * (float) Math.pow(1 - t0, 1.6), a1 = alpha * (float) Math.pow(1 - t1, 1.6);
      if (s == 0) a0 *= 0.6f;
      Vec3 c0 = o.add(dir.scale(len * t0)), c1 = o.add(dir.scale(len * t1));
      double rr0 = r0 + (r1 - r0) * t0, rr1 = r0 + (r1 - r0) * t1;
      for (int i = 0; i < SEG; i++) {
        double p0 = Math.PI * 2 * i / SEG, p1 = Math.PI * 2 * (i + 1) / SEG;
        Vec3 e0 = a.scale(Math.cos(p0)).add(b.scale(Math.sin(p0)));
        Vec3 e1 = a.scale(Math.cos(p1)).add(b.scale(Math.sin(p1)));
        v(bb, m, c0.add(e0.scale(rr0)), r, g, bl, a0);
        v(bb, m, c0.add(e1.scale(rr0)), r, g, bl, a0);
        v(bb, m, c1.add(e1.scale(rr1)), r, g, bl, a1);
        v(bb, m, c1.add(e0.scale(rr1)), r, g, bl, a1);
      }
    }
    BufferUploader.drawWithShader(bb.end());
  }

  private static void disc(
      Matrix4f m, Vec3 c, Vec3 a, Vec3 b, double rad, float alpha, float r, float g, float bl) {
    BufferBuilder bb = Tesselator.getInstance().getBuilder();
    bb.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
    int n = 28;
    for (int i = 0; i < n; i++) {
      double p0 = Math.PI * 2 * i / n, p1 = Math.PI * 2 * (i + 1) / n;
      v(bb, m, c, r, g, bl, alpha);
      v(bb, m, c.add(a.scale(Math.cos(p0) * rad)).add(b.scale(Math.sin(p0) * rad)), r, g, bl, 0f);
      v(bb, m, c.add(a.scale(Math.cos(p1) * rad)).add(b.scale(Math.sin(p1) * rad)), r, g, bl, 0f);
    }
    BufferUploader.drawWithShader(bb.end());
  }

  private static void v(BufferBuilder bb, Matrix4f m, Vec3 p, float r, float g, float b, float a) {
    bb.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
  }
}
