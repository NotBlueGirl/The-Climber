package net.mcreator.climber.client;

import net.mcreator.climber.blockentity.DoorBlockEntity;
import net.mcreator.climber.client.renderer.DoorBlockEntityRenderer;
import net.mcreator.climber.init.ClimberModBlockEntities;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@OnlyIn(Dist.CLIENT)
public class ClimberClientSetup {

  public static void init(IEventBus modBus) {
    net.mcreator.climber.door.DoorClientHooks.angleLookup = ClientDoorAngles::getFor;
    net.mcreator.climber.door.DoorClientHooks.grabPress = ClientDoorGrabBridge::press;
    modBus.addListener(ClimberClientSetup::onClientSetup);
    modBus.addListener(InteractableCrosshair::onRegisterOverlays);
    // "Config" button in the Mods list opens the settings screen
    net.minecraftforge.fml.ModLoadingContext.get()
        .registerExtensionPoint(
            net.minecraftforge.client.ConfigScreenHandler.ConfigScreenFactory.class,
            () ->
                new net.minecraftforge.client.ConfigScreenHandler.ConfigScreenFactory(
                    (mc, parent) ->
                        new net.mcreator.climber.client.screens.ClimberConfigScreen(parent)));
    modBus.addListener(ClimberClientSetup::onRegisterRenderers);
    // Register the keybind on the mod bus
    ClimberKeybinds.registerKeys(modBus);
  }

  /** Crank flashlight model: lens lit / unlit and 8 crank-arm positions while cranking. */
  private static void registerItemProperties() {
    var item = net.mcreator.climber.init.ClimberModItems.CRANK_FLASHLIGHT.get();
    net.minecraft.client.renderer.item.ItemProperties.register(
        item,
        new net.minecraft.resources.ResourceLocation("climber", "lit"),
        (stack, level, entity, seed) ->
            net.mcreator.climber.item.CrankFlashlightItem.isShining(stack) ? 1f : 0f);
    net.minecraft.client.renderer.item.ItemProperties.register(
        item,
        new net.minecraft.resources.ResourceLocation("climber", "crank"),
        (stack, level, entity, seed) -> {
          if (!(entity instanceof net.minecraft.world.entity.player.Player p)) return 0f;
          float partial = net.minecraft.client.Minecraft.getInstance().getFrameTime();
          float cd = p.getCooldowns().getCooldownPercent(stack.getItem(), partial);
          if (cd <= 0f) return 0f;
          // one crank = the lever swings out and back while the cooldown runs
          float out = net.minecraft.util.Mth.sin((1f - cd) * (float) Math.PI);
          return out > 0.6f ? 1.0f : out > 0.15f ? 0.5f : 0f;
        });
  }

  @SuppressWarnings("unchecked")
  private static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
    event.registerBlockEntityRenderer(
        (BlockEntityType<DoorBlockEntity>) ClimberModBlockEntities.DOOR_ANIMATOR.get(),
        DoorBlockEntityRenderer::new);
    event.registerEntityRenderer(
        net.mcreator.climber.init.ClimberModEntities.MECHANISM.get(),
        net.mcreator.climber.client.renderer.MechanismRenderer::new);
    event.registerEntityRenderer(
        net.mcreator.climber.init.ClimberModEntities.PITON.get(),
        net.mcreator.climber.client.renderer.PitonRenderer::new);
    event.registerEntityRenderer(
        net.mcreator.climber.init.ClimberModEntities.REBAR.get(),
        net.mcreator.climber.client.renderer.RebarRenderer::new);
    event.registerEntityRenderer(
        net.mcreator.climber.init.ClimberModEntities.THROWN_BRICK.get(),
        net.mcreator.climber.client.renderer.ThrownBrickRenderer::new);
  }

  private static void onClientSetup(FMLClientSetupEvent event) {
    event.enqueueWork(ClimberClientSetup::registerItemProperties);
    MinecraftForge.EVENT_BUS.register(new ClimberInputHandler());
    MinecraftForge.EVENT_BUS.register(new ClimberKeyInputHandler());
    MinecraftForge.EVENT_BUS.register(new ClimberArmRenderer());
    // BUG FIX: Client physics must be registered on the client side only
    MinecraftForge.EVENT_BUS.register(new ClimberClientPhysics());
    // Keybind polling handler
    MinecraftForge.EVENT_BUS.register(new ClimberKeybinds());
    MinecraftForge.EVENT_BUS.register(new DoorClientHandler());
    MinecraftForge.EVENT_BUS.register(new FlashlightBeamRenderer());
    MinecraftForge.EVENT_BUS.register(new ItemDisplayDebug());
    MinecraftForge.EVENT_BUS.register(new ClimberSettingsCommands());
    MinecraftForge.EVENT_BUS.register(new net.mcreator.climber.client.animation.AnimationClient());
    net.mcreator.climber.item.DebuggerToolItem.OPEN =
        id -> {
          var mc = net.minecraft.client.Minecraft.getInstance();
          if (mc.screen == null)
            mc.setScreen(new net.mcreator.climber.client.screens.MechanismEditorScreen(id));
        };
    ClientSoundChoices.load();
    ItemDisplayOverrides.load();
  }
}
