package net.mcreator.climber.client;

import com.mojang.blaze3d.audio.*;
import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import javax.sound.sampled.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.*;
import net.minecraft.client.sounds.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.ConstantFloat;
import net.minecraft.world.phys.Vec3;

/**
 * Local audio uses Minecraft's audio engine, volume sliders, and audio thread. Never raw OpenAL
 * threads.
 */
public final class ClimberSoundPreloader {
  private static final Map<ResourceLocation, Path> FILES = new ConcurrentHashMap<>();

  public static boolean isFilePath(String s) {
    return s != null && net.mcreator.climber.config.ConfigValidation.filePath(s);
  }

  private static ResourceLocation register(String path) {
    Path p = Path.of(path).toAbsolutePath().normalize();
    try {
      long size = Files.size(p);
      if (size > 16 * 1024 * 1024)
        throw new IllegalArgumentException("Local sound must be at most 16 MB");
      String signature = p + ":" + Files.getLastModifiedTime(p).toMillis() + ":" + size;
      String id =
          UUID.nameUUIDFromBytes(signature.getBytes(java.nio.charset.StandardCharsets.UTF_8))
              .toString();
      var key = new ResourceLocation("climber_local", "sounds/" + id + ".ogg");
      FILES.put(key, p);
      return key;
    } catch (IOException e) {
      throw new IllegalArgumentException("Cannot read local audio file: " + p, e);
    }
  }

  public static void preload(String path) {
    /* Lazy loading is cached and owned by SoundBufferLibrary. */
  }

  public static void clear() {
    FILES.clear();
  }

  public static boolean handles(ResourceLocation id) {
    return FILES.containsKey(id);
  }

  public static CompletableFuture<SoundBuffer> decode(ResourceLocation id) {
    Path p = FILES.get(id);
    return CompletableFuture.supplyAsync(
        () -> {
          try {
            if (p == null) throw new IOException("Unknown local sound");
            if (p.toString().toLowerCase(Locale.ROOT).endsWith(".ogg")) {
              try (OggAudioStream stream = new OggAudioStream(Files.newInputStream(p))) {
                ByteBuffer data = stream.read(16 * 1024 * 1024 + 1);
                if (data.remaining() > 16 * 1024 * 1024)
                  throw new IOException("Decoded sound exceeds 16 MB");
                return new SoundBuffer(data, stream.getFormat());
              }
            }
            try (AudioInputStream source = AudioSystem.getAudioInputStream(p.toFile())) {
              AudioFormat format = source.getFormat();
              if (format.getChannels() < 1 || format.getChannels() > 2)
                throw new IOException("Use mono or stereo WAV");
              AudioFormat pcm =
                  new AudioFormat(
                      AudioFormat.Encoding.PCM_SIGNED,
                      format.getSampleRate(),
                      16,
                      format.getChannels(),
                      format.getChannels() * 2,
                      format.getSampleRate(),
                      false);
              try (AudioInputStream stream = AudioSystem.getAudioInputStream(pcm, source)) {
                byte[] bytes = stream.readNBytes(16 * 1024 * 1024 + 1);
                if (bytes.length > 16 * 1024 * 1024)
                  throw new IOException("Decoded sound exceeds 16 MB");
                ByteBuffer data =
                    ByteBuffer.allocateDirect(bytes.length).order(ByteOrder.nativeOrder());
                data.put(bytes).flip();
                return new SoundBuffer(data, pcm);
              }
            }
          } catch (Exception e) {
            net.mcreator.climber.ClimberMod.LOGGER.warn("Cannot decode local sound {}", p, e);
            throw new CompletionException(e);
          }
        },
        net.minecraft.Util.backgroundExecutor());
  }

  public static void play(String path, float volume, float pitch) {
    playInternal(path, volume, pitch, null);
  }

  public static void playAt(String path, float volume, float pitch, Vec3 pos) {
    playInternal(path, volume, pitch, pos);
  }

  private static void playInternal(String path, float volume, float pitch, Vec3 pos) {
    if (path == null || path.isBlank()) return;
    var mc = Minecraft.getInstance();
    mc.execute(
        () -> {
          try {
            ResourceLocation key = register(path);
            mc.getSoundManager().play(new LocalSound(key, volume, pitch, pos));
          } catch (RuntimeException e) {
            net.mcreator.climber.ClimberMod.LOGGER.warn("Local sound playback failed", e);
            if (mc.player != null)
              mc.player.displayClientMessage(
                  net.minecraft.network.chat.Component.literal("Climber audio: " + e.getMessage()),
                  true);
          }
        });
  }

  private static final class LocalSound extends AbstractSoundInstance {
    private final Sound local;

    LocalSound(ResourceLocation file, float gain, float speed, Vec3 pos) {
      super(
          new ResourceLocation("climber_local", "file"),
          SoundSource.PLAYERS,
          RandomSource.create());
      String name = file.getPath().substring(7, file.getPath().length() - 4);
      local =
          new Sound(
              "climber_local:" + name,
              ConstantFloat.of(1),
              ConstantFloat.of(1),
              1,
              Sound.Type.FILE,
              false,
              false,
              16);
      volume = gain;
      pitch = speed;
      relative = pos == null;
      attenuation = pos == null ? SoundInstance.Attenuation.NONE : SoundInstance.Attenuation.LINEAR;
      if (pos != null) {
        x = pos.x;
        y = pos.y;
        z = pos.z;
      }
    }

    @Override
    public WeighedSoundEvents resolve(SoundManager manager) {
      sound = local;
      WeighedSoundEvents e = new WeighedSoundEvents(location, null);
      e.addSound(local);
      return e;
    }
  }
}
