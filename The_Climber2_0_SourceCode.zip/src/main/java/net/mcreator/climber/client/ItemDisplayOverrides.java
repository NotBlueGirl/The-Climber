package net.mcreator.climber.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.mcreator.climber.ClimberMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ItemTransform;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Debug "display" overrides for item models, edited live in {@link net.mcreator.climber.client.screens.ItemDisplayEditorScreen}
 * (like the Display panel of Blockbench). Values per item and slot: rotation XYZ (deg), translation
 * XYZ (model pixels, like the JSON), scale XYZ. Stored in config/climber_item_display.json.
 */
@OnlyIn(Dist.CLIENT)
public final class ItemDisplayOverrides {
    public enum Slot {
        FP_RIGHT("firstperson_righthand", "First person - right hand", true),
        FP_LEFT("firstperson_lefthand", "First person - left hand", false),
        TP_RIGHT("thirdperson_righthand", "Third person (others see) - right", true),
        TP_LEFT("thirdperson_lefthand", "Third person (others see) - left", false),
        CLIMBER_RIGHT("climber_righthand", "Climber mode arm - right hand", true),
        CLIMBER_LEFT("climber_lefthand", "Climber mode arm - left hand", false);

        public final String key, label;
        public final boolean right;
        Slot(String key, String label, boolean right) { this.key = key; this.label = label; this.right = right; }

        public boolean climber() { return this == CLIMBER_RIGHT || this == CLIMBER_LEFT; }
        public boolean thirdPerson() { return this == TP_RIGHT || this == TP_LEFT; }
        public Slot mirror() { return values()[ordinal() ^ 1]; }
        public ItemDisplayContext context() {
            return switch (this) {
                case FP_RIGHT -> ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
                case FP_LEFT -> ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
                case TP_RIGHT -> ItemDisplayContext.THIRD_PERSON_RIGHT_HAND;
                case TP_LEFT -> ItemDisplayContext.THIRD_PERSON_LEFT_HAND;
                default -> ItemDisplayContext.NONE;
            };
        }
        public static Slot of(ItemDisplayContext ctx) {
            return switch (ctx) {
                case FIRST_PERSON_RIGHT_HAND -> FP_RIGHT;
                case FIRST_PERSON_LEFT_HAND -> FP_LEFT;
                case THIRD_PERSON_RIGHT_HAND -> TP_RIGHT;
                case THIRD_PERSON_LEFT_HAND -> TP_LEFT;
                default -> null;
            };
        }
    }

    private static final Map<String, EnumMap<Slot, float[]>> DATA = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ItemDisplayOverrides() {}

    private static String id(Item item) {
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(item);
        return rl == null ? "?" : rl.toString();
    }

    public static float[] get(Item item, Slot slot) {
        if (DATA.isEmpty()) return null;
        EnumMap<Slot, float[]> m = DATA.get(id(item));
        return m == null ? null : m.get(slot);
    }

    public static void set(Item item, Slot slot, float[] v) {
        DATA.computeIfAbsent(id(item), k -> new EnumMap<>(Slot.class)).put(slot, v.clone());
    }

    public static void remove(Item item, Slot slot) {
        EnumMap<Slot, float[]> m = DATA.get(id(item));
        if (m != null) { m.remove(slot); if (m.isEmpty()) DATA.remove(id(item)); }
    }

    public static ItemTransform toTransform(float[] v) {
        return new ItemTransform(new Vector3f(v[0], v[1], v[2]),
                new Vector3f(v[3] / 16f, v[4] / 16f, v[5] / 16f), new Vector3f(v[6], v[7], v[8]));
    }

    public static float[] fromTransform(ItemTransform t) {
        return new float[] { t.rotation.x(), t.rotation.y(), t.rotation.z(),
                t.translation.x() * 16f, t.translation.y() * 16f, t.translation.z() * 16f,
                t.scale.x(), t.scale.y(), t.scale.z() };
    }

    /** Current values of a slot (override, otherwise what the model / climber arm uses by default). */
    public static float[] current(ItemStack stack, Slot slot) {
        float[] o = get(stack.getItem(), slot);
        return o != null ? o.clone() : defaults(stack, slot);
    }

    public static float[] defaults(ItemStack stack, Slot slot) {
        if (slot.climber()) return ClimberArmRenderer.climberDefault(stack, slot.right);
        Minecraft mc = Minecraft.getInstance();
        BakedModel model = mc.getItemRenderer().getModel(stack, mc.level, mc.player, 0);
        return fromTransform(model.getTransforms().getTransform(slot.context()));
    }

    /** Values used by the climber arm (right/left). */
    public static float[] climberValues(ItemStack stack, boolean right) {
        return current(stack, right ? Slot.CLIMBER_RIGHT : Slot.CLIMBER_LEFT);
    }

    /** Blockbench / item-model JSON of the four vanilla hand slots of an item. */
    public static String exportJson(ItemStack stack) {
        StringBuilder b = new StringBuilder("\"display\": {\n");
        Slot[] order = { Slot.TP_RIGHT, Slot.TP_LEFT, Slot.FP_RIGHT, Slot.FP_LEFT };
        for (int i = 0; i < order.length; i++) {
            float[] v = current(stack, order[i]);
            b.append("\t\"").append(order[i].key).append("\": {\"rotation\": ").append(vec(v, 0))
             .append(", \"translation\": ").append(vec(v, 3)).append(", \"scale\": ").append(vec(v, 6)).append('}')
             .append(i < order.length - 1 ? ",\n" : "\n");
        }
        return b.append('}').toString();
    }

    private static String vec(float[] v, int o) {
        return "[" + num(v[o]) + ", " + num(v[o + 1]) + ", " + num(v[o + 2]) + "]";
    }

    private static String num(float f) {
        float r = Math.round(f * 1000f) / 1000f;
        return r == (int) r ? Integer.toString((int) r) : Float.toString(r);
    }

    private static JsonObject slotJson(float[] v) {
        JsonObject o = new JsonObject();
        o.add("rotation", arr(v[0], v[1], v[2]));
        o.add("translation", arr(v[3], v[4], v[5]));
        o.add("scale", arr(v[6], v[7], v[8]));
        return o;
    }

    private static JsonArray arr(float a, float b, float c) {
        JsonArray x = new JsonArray();
        for (float f : new float[] { a, b, c }) x.add(Math.round(f * 1000f) / 1000f);
        return x;
    }

    private static Path path() { return FMLPaths.CONFIGDIR.get().resolve("climber_item_display.json"); }

    public static void load() {
        DATA.clear();
        Path p = path();
        if (!Files.exists(p)) return;
        try (Reader r = Files.newBufferedReader(p)) {
            JsonObject root = GSON.fromJson(r, JsonObject.class);
            if (root == null) return;
            for (String item : root.keySet()) {
                JsonObject slots = root.getAsJsonObject(item);
                for (Slot s : Slot.values()) {
                    if (!slots.has(s.key)) continue;
                    JsonObject o = slots.getAsJsonObject(s.key);
                    float[] v = new float[9];
                    read(o, "rotation", v, 0, 0f);
                    read(o, "translation", v, 3, 0f);
                    read(o, "scale", v, 6, 1f);
                    DATA.computeIfAbsent(item, k -> new EnumMap<>(Slot.class)).put(s, v);
                }
            }
        } catch (Exception e) {
            ClimberMod.LOGGER.error("[Climber] Failed to read {}: {}", p, e.toString());
        }
    }

    private static void read(JsonObject o, String key, float[] v, int off, float def) {
        for (int i = 0; i < 3; i++) v[off + i] = def;
        if (!o.has(key)) return;
        JsonArray a = o.getAsJsonArray(key);
        for (int i = 0; i < 3 && i < a.size(); i++) v[off + i] = a.get(i).getAsFloat();
    }

    public static void save() {
        JsonObject root = new JsonObject();
        for (Map.Entry<String, EnumMap<Slot, float[]>> e : DATA.entrySet()) {
            JsonObject slots = new JsonObject();
            for (Map.Entry<Slot, float[]> s : e.getValue().entrySet()) slots.add(s.getKey().key, slotJson(s.getValue()));
            root.add(e.getKey(), slots);
        }
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(root, w);
        } catch (Exception e) {
            ClimberMod.LOGGER.error("[Climber] Failed to write {}: {}", path(), e.toString());
        }
    }

    public static String fmt(float f) { return String.format(Locale.ROOT, "%.2f", f); }
}
