package net.mcreator.climber.client;

import net.minecraft.commands.Commands;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** Settings shortcuts independent of the removed sprite-hand subsystem. */
@OnlyIn(Dist.CLIENT)
public final class ClimberSettingsCommands {
    public static boolean matches(String command) {
        return command != null && command.trim().matches("(?i)^/(climb|climber)\\s+(settings|menu|gui)\\s*$");
    }
    @SubscribeEvent public void chat(ClientChatEvent e) {
        if(matches(e.getMessage())){e.setCanceled(true);ClimberKeybinds.openConfigRequested=true;}
    }
    @SubscribeEvent public void commands(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("climbsettings").executes(c->{ClimberKeybinds.openConfigRequested=true;return 1;}));
    }
}
