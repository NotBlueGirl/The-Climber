package net.mcreator.climber.client.screens;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.network.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;

public final class RemoteObjectScreen extends Screen {
  private final RemoteObjectReply data;

  public RemoteObjectScreen(RemoteObjectReply d) {
    super(Component.literal("Remote ladder"));
    data = d;
  }

  public static void open(RemoteObjectReply d) {
    var mc = Minecraft.getInstance();
    if (!(mc.screen instanceof MechanismObjectScreen
        || mc.screen instanceof MechanismEditorScreen
        || mc.screen instanceof RemoteObjectScreen)) return;
    if (d.kind().equals("LADDER")) mc.setScreen(new RemoteObjectScreen(d));
    else mc.setScreen(new MechanismEditorScreen(d));
  }

  protected void init() {
    int y = 85;
    for (int a : new int[] {3, 4, 2}) {
      int action = a;
      String text =
          a == 3 ? "Deploy front chain" : a == 4 ? "Retract front chain" : "Remove base ladder";
      addRenderableWidget(
          new DebuggerActionButton(
              text,
              18,
              y,
              width - 36,
              () -> {
                if (action == 2)
                  minecraft.setScreen(
                      new ConfirmScreen(
                          ok -> {
                            minecraft.setScreen(this);
                            if (ok) send(action);
                          },
                          Component.literal("Remove ladder base?"),
                          Component.literal("Retracts the chain, then removes this base.")));
                else send(action);
              }));
      y += 28;
    }
    addRenderableWidget(
        new DebuggerActionButton(
            "Back to objects",
            18,
            height - 40,
            width - 36,
            () -> minecraft.setScreen(new MechanismObjectScreen(null))));
  }

  private void send(int a) {
    if (a == 2) minecraft.setScreen(new MechanismObjectScreen(null));
    ClimberMod.PACKET_HANDLER.sendToServer(
        new RemoteObjectPacket(data.id(), a, new CompoundTag(), data.revision()));
  }

  public void render(GuiGraphics g, int x, int y, float p) {
    g.fill(0, 0, width, height, 0xFF10151B);
    g.drawString(font, "REMOTE / MECHANICAL LADDER", 18, 16, 0x70B7F0);
    g.drawString(font, data.dimension() + "  " + data.pos().toShortString(), 18, 36, 0xB5C3CB);
    g.drawString(
        font,
        "Layers: "
            + data.tag().getInt("layers")
            + " | deployed: "
            + data.tag().getBoolean("deployed"),
        18,
        56,
        0xFFFFFF);
    super.render(g, x, y, p);
  }

  public boolean isPauseScreen() {
    return false;
  }
}
