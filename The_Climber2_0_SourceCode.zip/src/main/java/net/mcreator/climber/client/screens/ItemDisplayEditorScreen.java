package net.mcreator.climber.client.screens;

import java.util.ArrayList;
import java.util.List;
import net.mcreator.climber.client.ClimberClientData;
import net.mcreator.climber.client.ItemDisplayOverrides;
import net.mcreator.climber.client.ItemDisplayOverrides.Slot;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Debug mode: live editor for how an item sits in the hand, like Blockbench's Display panel. Slots:
 * first person (what you see), third person (what the server / other players see) and the
 * Climber-mode 3D arm, each for the right and the left hand. Changes are visible immediately, saved
 * to config/climber_item_display.json and can be copied as a model "display" JSON block.
 */
@OnlyIn(Dist.CLIENT)
public class ItemDisplayEditorScreen extends Screen {
  private static final String[] LABELS = {
    "Rot X", "Rot Y", "Rot Z", "Pos X", "Pos Y", "Pos Z", "Scale X", "Scale Y", "Scale Z"
  };
  private static final float[] MIN = {-180, -180, -180, -80, -80, -80, 0, 0, 0};
  private static final float[] MAX = {180, 180, 180, 80, 80, 80, 4, 4, 4};
  private static final float[] STEP = {1, 1, 1, 0.25f, 0.25f, 0.25f, 0.01f, 0.01f, 0.01f};

  private static Slot slot = Slot.FP_RIGHT;
  private static boolean lockScale = true;

  private final CameraType prevCamera;
  private float[] values = new float[9];
  private ItemStack editing = ItemStack.EMPTY;
  private final List<ValueSlider> sliders = new ArrayList<>();
  private String status = "";
  private int statusTicks = 0;

  public ItemDisplayEditorScreen() {
    super(Component.literal("Item Display Editor"));
    this.prevCamera = Minecraft.getInstance().options.getCameraType();
  }

  private ItemStack target() {
    Minecraft mc = Minecraft.getInstance();
    if (mc.player == null) return ItemStack.EMPTY;
    ItemStack main = mc.player.getMainHandItem();
    return !main.isEmpty() ? main : mc.player.getOffhandItem();
  }

  @Override
  protected void init() {
    sliders.clear();
    addRenderableWidget(
        Button.builder(
                Component.literal("Animation mode"),
                b -> {
                  onClose();
                  Minecraft.getInstance().setScreen(new AnimationEditorScreen());
                })
            .bounds(Math.max(208, width - 114), height - 24, 106, 16)
            .build());
    addRenderableWidget(
        Button.builder(
                Component.literal("Settings UI"),
                b -> {
                  onClose();
                  Minecraft.getInstance().setScreen(new SettingsLayoutScreen(null));
                })
            .bounds(Math.max(208, width - 114), height - 60, 106, 16)
            .build());
    addRenderableWidget(
        Button.builder(
                Component.literal("Mechanisms"),
                b -> {
                  onClose();
                  Minecraft.getInstance().setScreen(new MechanismEditorScreen(-1));
                })
            .bounds(Math.max(208, width - 114), height - 42, 106, 16)
            .build());
    editing = target();
    if (!editing.isEmpty()) values = ItemDisplayOverrides.current(editing, slot);
    applyCamera();

    int pw = 190, x0 = 8, y = 30;
    addRenderableWidget(
        Button.builder(Component.literal("< "), b -> switchSlot(-1)).bounds(x0, y, 16, 14).build());
    addRenderableWidget(
        Button.builder(Component.literal(slot.label), b -> switchSlot(1))
            .bounds(x0 + 17, y, pw - 34, 14)
            .build());
    addRenderableWidget(
        Button.builder(Component.literal(" >"), b -> switchSlot(1))
            .bounds(x0 + pw - 16, y, 16, 14)
            .build());
    y += 19;
    for (int i = 0; i < 9; i++) {
      final int idx = i;
      addRenderableWidget(
          Button.builder(Component.literal("-"), b -> nudge(idx, -1))
              .bounds(x0, y, 14, 13)
              .build());
      ValueSlider s = new ValueSlider(x0 + 15, y, pw - 30, 13, idx);
      sliders.add(s);
      addRenderableWidget(s);
      addRenderableWidget(
          Button.builder(Component.literal("+"), b -> nudge(idx, 1))
              .bounds(x0 + pw - 14, y, 14, 13)
              .build());
      y += i % 3 == 2 ? 17 : 14;
    }
    int hw = (pw - 2) / 2;
    addRenderableWidget(
        Button.builder(
                Component.literal("Lock scale: " + (lockScale ? "ON" : "OFF")),
                b -> {
                  lockScale = !lockScale;
                  rebuild();
                })
            .bounds(x0, y, hw, 14)
            .build());
    addRenderableWidget(
        Button.builder(
                Component.literal("Reset slot"),
                b -> {
                  if (!editing.isEmpty()) {
                    ItemDisplayOverrides.remove(editing.getItem(), slot);
                    values = ItemDisplayOverrides.current(editing, slot);
                    refresh();
                    say("Slot reset to model default");
                  }
                })
            .bounds(x0 + hw + 2, y, hw, 14)
            .build());
    y += 16;
    addRenderableWidget(
        Button.builder(
                Component.literal("To other hand"),
                b -> {
                  if (!editing.isEmpty()) {
                    ItemDisplayOverrides.set(editing.getItem(), slot.mirror(), values);
                    say("Copied to " + slot.mirror().label);
                  }
                })
            .bounds(x0, y, hw, 14)
            .build());
    addRenderableWidget(
        Button.builder(
                Component.literal("Copy JSON"),
                b -> {
                  if (!editing.isEmpty()) {
                    Minecraft.getInstance()
                        .keyboardHandler
                        .setClipboard(ItemDisplayOverrides.exportJson(editing));
                    say("\"display\" JSON copied to clipboard");
                  }
                })
            .bounds(x0 + hw + 2, y, hw, 14)
            .build());
    y += 16;
    addRenderableWidget(
        Button.builder(Component.literal("Save & close"), b -> onClose())
            .bounds(x0, y, pw, 14)
            .build());
  }

  private void rebuild() {
    clearWidgets();
    init();
  }

  private void switchSlot(int dir) {
    Slot[] all = Slot.values();
    slot = all[Math.floorMod(slot.ordinal() + dir, all.length)];
    rebuild();
  }

  private void applyCamera() {
    Minecraft mc = Minecraft.getInstance();
    mc.options.setCameraType(
        slot.thirdPerson() ? CameraType.THIRD_PERSON_FRONT : CameraType.FIRST_PERSON);
  }

  private void nudge(int idx, int dir) {
    setValue(idx, values[idx] + dir * STEP[idx]);
    refresh();
  }

  private void setValue(int idx, float v) {
    v = Mth.clamp(Math.round(v / STEP[idx]) * STEP[idx], MIN[idx], MAX[idx]);
    v = Math.round(v * 1000f) / 1000f;
    values[idx] = v;
    if (lockScale && idx >= 6) {
      values[6] = v;
      values[7] = v;
      values[8] = v;
    }
    if (!editing.isEmpty()) ItemDisplayOverrides.set(editing.getItem(), slot, values);
  }

  private void refresh() {
    for (ValueSlider s : sliders) s.sync();
  }

  private void say(String s) {
    status = s;
    statusTicks = 80;
  }

  @Override
  public void tick() {
    if (statusTicks > 0) statusTicks--;
    ItemStack t = target();
    if (!ItemStack.isSameItem(t, editing)) rebuild(); // the player switched items
  }

  @Override
  public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
    int pw = 190, x0 = 8;
    g.fill(0, 0, x0 + pw + 4, height, 0xB0101014);
    g.drawString(font, "Item Display Editor (debug)", x0, 5, 0xFFE8C860);
    String name = editing.isEmpty() ? "- hold an item -" : editing.getHoverName().getString();
    g.drawString(font, font.plainSubstrByWidth(name, pw), x0, 17, 0xFFFFFFFF);
    super.render(g, mouseX, mouseY, partial);

    // hints / warnings on the left
    List<String> info = new ArrayList<>();
    if (editing.isEmpty()) info.add("Hold the item you want to edit (main hand, or off hand).");
    if (!slot.right) info.add("Left-hand slot: put the item in your off hand (F) to see it.");
    if (slot.climber()) {
      if (!ClimberClientData.climbEnabled)
        info.add("Climber mode is OFF - turn it on to preview this slot.");
    } else if (ClimberClientData.climbEnabled
        && !(editing.getItem() instanceof net.mcreator.climber.item.ClimberTool)) {
      info.add("Climber mode hides vanilla items - turn it off to preview.");
    } else if (ClimberClientData.climbEnabled && !slot.thirdPerson()) {
      info.add("Climber mode uses the 'Climber mode arm' slots for first person.");
    }
    info.add("Values = Blockbench display (rotation, translation px, scale).");
    info.add("Saved to config/climber_item_display.json");
    int y = 6, ix = x0 + pw + 10;
    for (String s : info) {
      g.drawString(font, s, ix, y, 0xFFFFE080);
      y += 11;
    }
    if (statusTicks > 0) g.drawString(font, status, ix, y + 4, 0xFF80FF80);
  }

  @Override
  public boolean isPauseScreen() {
    return false;
  }

  @Override
  public void onClose() {
    ItemDisplayOverrides.save();
    Minecraft.getInstance().options.setCameraType(prevCamera);
    super.onClose();
  }

  private class ValueSlider extends AbstractSliderButton {
    private final int idx;

    ValueSlider(int x, int y, int w, int h, int idx) {
      super(x, y, w, h, Component.empty(), 0);
      this.idx = idx;
      sync();
    }

    void sync() {
      this.value = (values[idx] - MIN[idx]) / (MAX[idx] - MIN[idx]);
      updateMessage();
    }

    @Override
    protected void updateMessage() {
      setMessage(Component.literal(LABELS[idx] + ": " + ItemDisplayOverrides.fmt(values[idx])));
    }

    @Override
    protected void applyValue() {
      setValue(idx, MIN[idx] + (float) value * (MAX[idx] - MIN[idx]));
      if (lockScale && idx >= 6) for (ValueSlider s : sliders) if (s != this) s.sync();
      updateMessage();
    }
  }
}
