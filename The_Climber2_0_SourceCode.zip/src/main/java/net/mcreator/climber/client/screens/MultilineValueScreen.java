package net.mcreator.climber.client.screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.function.Consumer;
/** Reusable multiline block-list editor. Returning only changes the parent draft. */
public final class MultilineValueScreen extends Screen {
    private final Screen parent;private String initial;private final Consumer<String> accept;private MultiLineEditBox box;
    public MultilineValueScreen(Screen parent,String title,String initial,Consumer<String> accept){super(Component.literal(title));this.parent=parent;this.initial=initial;this.accept=accept;}
    @Override protected void init(){if(box!=null)initial=box.getValue();box=new MultiLineEditBox(font,12,39,width-24,height-81,Component.literal("One namespace:block per line"),title);box.setCharacterLimit(32767);box.setValue(initial.replace(", ","\n"));addRenderableWidget(box);addRenderableWidget(Button.builder(Component.literal("Use in draft"),b->{accept.accept(box.getValue());Minecraft.getInstance().setScreen(parent);}).bounds(12,height-30,(width-28)/2,20).build());addRenderableWidget(Button.builder(Component.literal("Cancel"),b->onClose()).bounds(16+(width-28)/2,height-30,(width-28)/2,20).build());setInitialFocus(box);}
    @Override public void render(GuiGraphics g,int x,int y,float p){g.fill(0,0,width,height,0xFF151D27);g.drawString(font,title,12,10,0xFFE8C547);g.drawString(font,font.plainSubstrByWidth("Separate block IDs with newlines, commas or semicolons.",width-24),12,25,0xFFB8CADD);super.render(g,x,y,p);}
    @Override public void onClose(){Minecraft.getInstance().setScreen(parent);}
}
