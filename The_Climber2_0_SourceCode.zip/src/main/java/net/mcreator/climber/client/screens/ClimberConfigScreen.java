package net.mcreator.climber.client.screens;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.client.ClimberClientData;
import net.mcreator.climber.client.ClimberKeybinds;
import net.mcreator.climber.grip.AutoGripMode;
import net.mcreator.climber.grip.GripMode;
import net.mcreator.climber.network.ConfigSyncPacket;
import net.mcreator.climber.network.ConfigUpdatePacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFW;

/**
 * Settings screen in the spirit of White Knuckle's menus (dark, all caps, tabs on the left, simple
 * value rows on the right) - a simplified take, no assets from the game.
 *
 * <p>Server rows edit a draft that is sent to the server when Apply is pressed (op / single-player
 * host only).
 */
@OnlyIn(Dist.CLIENT)
public class ClimberConfigScreen extends Screen {
  private static final int WHITE = 0xFFFFFFFF,
      LIGHT = 0xFFC8C8C8,
      DIM = 0xFF7A7A7A,
      DARK = 0xFF4A4A4A;

  private final Screen parent;
  private CompoundTag draft;
  private net.mcreator.climber.client.SettingsLayout layout;
  private int ACCENT = 0xFFE8C547;
  private boolean pending;
  private long revision, sent;
  private String message = "";
  private static final String[][] KEYS = {
    {"gripMode", "autoGripMode", "strengthJumpBothHands", "strengthJumpOneHand"},
    {"staminaEnabled", "staminaMax", "staminaDrainRate", "staminaRegenRate"},
    {"idleHandX", "idleHandY", "idleHandZ"},
    {"includeList", "excludeList"},
    {},
    {}
  };
  private boolean dirty = false;
  private int tab = 0;
  private final List<Tab> tabs = new ArrayList<>();
  private SliderRow dragging = null;
  private float scroll = 0f;
  private long openedAt;

  // layout (computed in init)
  private int left, tabsY, divider, rowsX0, rowsX1, rowsY, rowH, footerY;

  public ClimberConfigScreen(Screen parent) {
    super(Component.literal("The Climber - Settings"));
    this.parent = parent;
    this.draft = ClimberConfig.INSTANCE.toSyncTag();
    buildTabs();
  }

  // ------------------------------------------------------------------ model

  private record Tab(String name, boolean server, List<Row> rows, Runnable reset) {}

  private abstract static class Row {
    final String label, hint;
    final boolean server;

    Row(String label, String hint, boolean server) {
      this.label = label;
      this.hint = hint;
      this.server = server;
    }

    abstract String value();

    void click(double mx, int x0, int x1, int button) {}

    void scroll(double delta) {}
  }

  private class CycleRow extends Row {
    final Supplier<String> get;
    final Consumer<Integer> step;

    CycleRow(
        String label, String hint, boolean server, Supplier<String> get, Consumer<Integer> step) {
      super(label, hint, server);
      this.get = get;
      this.step = step;
    }

    @Override
    String value() {
      return get.get();
    }

    @Override
    void click(double mx, int x0, int x1, int button) {
      int dir = button == 1 ? -1 : (mx < x1 - 75 ? -1 : 1);
      step.accept(dir);
      changed(server);
    }

    @Override
    void scroll(double d) {
      step.accept(d > 0 ? 1 : -1);
      changed(server);
    }
  }

  private class ToggleRow extends CycleRow {
    ToggleRow(
        String label, String hint, boolean server, BooleanSupplier get, Consumer<Boolean> set) {
      super(
          label,
          hint,
          server,
          () -> get.getAsBoolean() ? "ON" : "OFF",
          d -> set.accept(!get.getAsBoolean()));
    }
  }

  private class SliderRow extends Row {
    final double min, max, step;
    final DoubleSupplier get;
    final DoubleConsumer set;
    final String fmt;

    SliderRow(
        String label,
        String hint,
        boolean server,
        double min,
        double max,
        double step,
        String fmt,
        DoubleSupplier get,
        DoubleConsumer set) {
      super(label, hint, server);
      this.min = min;
      this.max = max;
      this.step = step;
      this.fmt = fmt;
      this.get = get;
      this.set = set;
    }

    @Override
    String value() {
      return String.format(Locale.ROOT, fmt, get.getAsDouble());
    }

    double frac() {
      return Mth.clamp((get.getAsDouble() - min) / (max - min), 0, 1);
    }

    void setFrac(double f) {
      double v = min + Mth.clamp(f, 0, 1) * (max - min);
      v = Math.round(v / step) * step;
      set.accept(Mth.clamp(v, min, max));
      changed(server);
    }

    @Override
    void click(double mx, int x0, int x1, int button) {
      if (button == 1 || mx > x1 - 55) {
        Minecraft.getInstance()
            .setScreen(
                new ValueEntryScreen(
                    ClimberConfigScreen.this,
                    label,
                    value(),
                    "Enter an exact number. Right-click a slider or click its number to edit.",
                    s -> {
                      double n = Double.parseDouble(s);
                      if (!Double.isFinite(n)
                          || n < (label.startsWith("Hand ") ? -Float.MAX_VALUE : min)
                          || n
                              > (net.mcreator.climber.config.GameplaySettings.OPTIONS.stream()
                                      .anyMatch(o -> o.key().equals(label))
                                  ? max
                                  : Float.MAX_VALUE)
                          || (label.equals("Max stamina")
                              && (n != Math.rint(n) || n > 2147483520d)))
                        throw new IllegalArgumentException("Value is outside its valid range");
                      set.accept(n);
                      changed(server);
                    }));
        return;
      }
      int t0 = x1 - 170, t1 = x1 - 60;
      if (mx >= t0 - 4 && mx <= t1 + 4) {
        setFrac((mx - t0) / (t1 - t0));
        dragging = this;
      }
    }

    @Override
    void scroll(double d) {
      set.accept(Mth.clamp(get.getAsDouble() + (d > 0 ? step : -step), min, max));
      changed(server);
    }
  }

  private class ActionRow extends Row {
    final Supplier<String> get;
    final Runnable action;

    ActionRow(String label, String hint, boolean server, Supplier<String> get, Runnable action) {
      super(label, hint, server);
      this.get = get;
      this.action = action;
    }

    @Override
    String value() {
      return get.get();
    }

    @Override
    void click(double x, int a, int b, int button) {
      action.run();
    }
  }

  private class InfoRow extends Row {
    final String text;

    InfoRow(String label, String text) {
      super(label, null, false);
      this.text = text;
    }

    @Override
    String value() {
      return text;
    }
  }

  private void changed(boolean server) {
    if (server) dirty = true;
    playClick();
  }

  private void playClick() {
    Minecraft.getInstance()
        .getSoundManager()
        .play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.get(), 1.6f, 0.25f));
  }

  private float f(String k) {
    return draft.getFloat(k);
  }

  private void putF(String k, double v) {
    draft.putFloat(k, (float) v);
  }

  private void buildTabs() {
    // ---- CLIMBING ----
    List<Row> climb = new ArrayList<>();
    climb.add(
        new ToggleRow(
            "Climbing",
            "Turns climbing on/off for you (same as /climb on|off).",
            false,
            () -> ClimberClientData.climbEnabled,
            v -> {
              Minecraft mc = Minecraft.getInstance();
              if (mc.player != null)
                mc.player.connection.sendCommand(
                    ClimberClientData.climbEnabled ? "climb off" : "climb on");
            }));
    climb.add(
        new CycleRow(
            "Grip mode",
            "LIP HANDS: grab any solid surface.  REALISTIC: only real ledges, lips, edges and"
                + " corners.",
            true,
            () ->
                GripMode.byId(draft.getString("gripMode")) == GripMode.REALISTIC
                    ? "REALISTIC"
                    : "LIP HANDS",
            d ->
                draft.putString(
                    "gripMode",
                    (GripMode.byId(draft.getString("gripMode")) == GripMode.REALISTIC
                            ? GripMode.LIP_HANDS
                            : GripMode.REALISTIC)
                        .name())));
    climb.add(
        new CycleRow(
            "Auto grip",
            "Keep the mouse button held to grab automatically as soon as a hold is in reach.",
            true,
            () ->
                switch (AutoGripMode.byId(draft.getString("autoGripMode"))) {
                  case OFF -> "OFF";
                  case ONLY_LIP_HANDS -> "LIP HANDS ONLY";
                  case ONLY_REALISTIC -> "REALISTIC ONLY";
                  case BOTH -> "ALWAYS";
                },
            d -> {
              AutoGripMode[] all = AutoGripMode.values();
              int i =
                  Math.floorMod(
                      AutoGripMode.byId(draft.getString("autoGripMode")).ordinal() + d, all.length);
              draft.putString("autoGripMode", all[i].name());
            }));
    climb.add(
        new SliderRow(
            "Jump strength (two hands)",
            "How hard you launch when jumping off a hold with both hands.",
            true,
            0,
            2,
            0.05,
            "%.2f",
            () -> f("strengthJumpBothHands"),
            v -> putF("strengthJumpBothHands", v)));
    climb.add(
        new SliderRow(
            "Jump strength (one hand)",
            "How hard you launch when jumping off a hold with one hand.",
            true,
            0,
            2,
            0.05,
            "%.2f",
            () -> f("strengthJumpOneHand"),
            v -> putF("strengthJumpOneHand", v)));
    tabs.add(
        new Tab(
            "Climbing",
            true,
            climb,
            () -> {
              CompoundTag d = ClimberConfig.defaultSyncTag();
              for (String k :
                  new String[] {
                    "gripMode", "autoGripMode", "strengthJumpBothHands", "strengthJumpOneHand"
                  }) draft.put(k, d.get(k).copy());
              dirty = true;
            }));

    // ---- STAMINA ----
    List<Row> st = new ArrayList<>();
    st.add(
        new ToggleRow(
            "Stamina",
            "Hands get tired while hanging and slip when exhausted.",
            true,
            () -> draft.getBoolean("staminaEnabled"),
            v -> draft.putBoolean("staminaEnabled", !draft.getBoolean("staminaEnabled"))));
    st.add(
        new SliderRow(
            "Max stamina",
            "Stamina of each hand.",
            true,
            1,
            400,
            1,
            "%.0f",
            () -> f("staminaMax"),
            v -> putF("staminaMax", v)));
    st.add(
        new SliderRow(
            "Drain speed",
            "Stamina lost per tick while hanging.",
            true,
            0,
            3,
            0.01,
            "%.2f",
            () -> f("staminaDrainRate"),
            v -> putF("staminaDrainRate", v)));
    st.add(
        new SliderRow(
            "Recovery speed",
            "Stamina regained per tick while the hand is free.",
            true,
            0,
            3,
            0.01,
            "%.2f",
            () -> f("staminaRegenRate"),
            v -> putF("staminaRegenRate", v)));
    tabs.add(
        new Tab(
            "Stamina",
            true,
            st,
            () -> {
              CompoundTag d = ClimberConfig.defaultSyncTag();
              for (String k :
                  new String[] {
                    "staminaEnabled", "staminaMax", "staminaDrainRate", "staminaRegenRate"
                  }) draft.put(k, d.get(k).copy());
              dirty = true;
            }));

    List<Row> hand = new ArrayList<>();
    for (String axis : new String[] {"X", "Y", "Z"}) {
      String key = "idleHand" + axis;
      hand.add(
          new SliderRow(
              "Hand " + axis,
              "Idle 3D hand offset. Right-click for an exact value.",
              true,
              -2,
              2,
              .01,
              "%.2f",
              () -> draft.getDouble(key),
              v -> draft.putDouble(key, v)));
    }
    tabs.add(new Tab("Hand position", true, hand, () -> resetKeys(2)));
    List<Row> blocks = new ArrayList<>();
    for (String name : new String[] {"Include", "Exclude"}) {
      String key = name.toLowerCase(Locale.ROOT) + "List";
      blocks.add(
          new ActionRow(
              name + " blocks",
              "Select any registered vanilla or modded block. Exclusions take priority.",
              true,
              () -> draft.getList(key, 8).size() + " SELECT / EDIT",
              () ->
                  Minecraft.getInstance()
                      .setScreen(
                          new BlockPickerScreen(
                              this,
                              name + " blocks",
                              net.mcreator.climber.config.ConfigValidation.blockIds(
                                  net.mcreator.climber.config.ConfigValidation.listText(
                                      draft, key)),
                              ids -> {
                                draft.put(
                                    key, net.mcreator.climber.config.ConfigValidation.list(ids));
                                dirty = true;
                              }))));
    }
    tabs.add(new Tab("Block lists", true, blocks, () -> resetKeys(3)));
    List<Row> sounds = new ArrayList<>();
    for (String slot : new String[] {"Hit", "Jump"}) {
      String key = "grab" + slot + "Sound";
      sounds.add(
          new ActionRow(
              "Grab-" + slot.toLowerCase(Locale.ROOT) + " file",
              "Select .ogg or PCM .wav on THIS PC. Local preference; never uploaded.",
              false,
              () ->
                  net.mcreator.climber.client.ClientSoundChoices.local(key).isBlank()
                      ? "CHOOSE FILE"
                      : "CHANGE FILE",
              () -> chooseSound(key)));
      sounds.add(
          new ActionRow(
              "Preview " + slot.toLowerCase(Locale.ROOT),
              "Play the selected local sound.",
              false,
              () -> "PLAY",
              () ->
                  net.mcreator.climber.client.ClimberSoundPreloader.play(
                      net.mcreator.climber.client.ClientSoundChoices.local(key), .7f, 1)));
      sounds.add(
          new ActionRow(
              "Reset " + slot.toLowerCase(Locale.ROOT) + " file",
              "Remove your local override and use the server/default sound.",
              false,
              () -> "DEFAULT",
              () -> {
                net.mcreator.climber.client.ClientSoundChoices.set(key, "");
                message = "Local sound reset.";
              }));
      sounds.add(
          new ActionRow(
              "Server " + slot.toLowerCase(Locale.ROOT) + " sound",
              "Shared sound ID or legacy path. Local PC files override this only for you.",
              true,
              () -> draft.getString(key).isBlank() ? "DEFAULT" : "EDIT",
              () ->
                  Minecraft.getInstance()
                      .setScreen(
                          new ValueEntryScreen(
                              this,
                              "Server sound",
                              draft.getString(key),
                              "Empty = default. Registry ID: namespace:sound",
                              v -> {
                                CompoundTag test = new CompoundTag();
                                test.putString(key, v.trim());
                                net.mcreator.climber.config.ConfigValidation.validate(test, false);
                                draft.putString(key, v.trim());
                                dirty = true;
                              }))));
    }
    tabs.add(new Tab("Sounds", false, sounds, null));

    // ---- HELP ----
    List<Row> help = new ArrayList<>();
    help.add(new InfoRow("LMB / RMB", "grab with the left / right hand"));
    help.add(new InfoRow("Jump", "climb-jump off your holds"));
    help.add(new InfoRow("Doors", "hold RMB on a door and drag it"));
    help.add(new InfoRow("Diamond", "block with an interface - RMB opens it"));
    help.add(new InfoRow("Items", "RMB right item / LMB left item; empty hand grabs"));
    help.add(new InfoRow("Piton", "RMB a wall, hit it 3x with the hammer"));
    help.add(new InfoRow("Hammer", "RMB/LMB swing, hold RMB = charged swing"));
    help.add(new InfoRow("Rebar", "RMB throw, LMB or empty RMB to pull out"));
    help.add(new InfoRow("Brick", "RMB to throw, smashes glass"));
    help.add(new InfoRow("Flashlight", "RMB cranks; charge limits are in Gameplay settings"));
    help.add(
        new InfoRow(
            "This menu",
            ClimberKeybinds.KEY_OPEN_CONFIG
                    .getTranslatedKeyMessage()
                    .getString()
                    .toUpperCase(Locale.ROOT)
                + "  or  /climb settings"));
    help.add(new InfoRow("Debug", "/climbdebug = display, animation, UI, mechanisms"));
    help.add(new InfoRow("Block lists", "/climb config include | exclude"));
    tabs.add(new Tab("Help", false, help, null));
    List<Row> gameplayRows = new ArrayList<>();
    gameplayRows.add(
        new ToggleRow(
            "DoorPhysics",
            "Enable physical door dragging; OFF uses vanilla doors.",
            true,
            () -> draft.getBoolean("DoorPhysics"),
            v -> draft.putBoolean("DoorPhysics", v)));
    for (var option : net.mcreator.climber.config.GameplaySettings.OPTIONS) {
      var o = option;
      gameplayRows.add(
          new SliderRow(
              o.key(),
              o.unit() + "; range " + o.min() + ".." + o.max(),
              true,
              o.min(),
              o.max(),
              o.key().contains("Hitbox") ? .03125 : .05,
              "%.3f",
              () -> draft.getDouble(o.key()),
              v -> draft.putDouble(o.key(), v)));
    }
    tabs.add(
        new Tab(
            "Gameplay",
            true,
            gameplayRows,
            () -> {
              var defaults = ClimberConfig.defaultSyncTag();
              for (var o : net.mcreator.climber.config.GameplaySettings.OPTIONS)
                draft.put(o.key(), defaults.get(o.key()).copy());
              draft.putBoolean("DoorPhysics", true);
              dirty = true;
            }));
  }

  private boolean serverEditable() {
    Minecraft mc = Minecraft.getInstance();
    if (mc.getConnection() == null) return true; // main menu: edits the local config file
    return mc.hasSingleplayerServer() || ConfigSyncPacket.clientCanEdit;
  }

  private boolean rowEnabled(Row r) {
    if (r instanceof InfoRow || pending) return false;
    if (r.server) return serverEditable();
    if (r.label.equals("Climbing")) return Minecraft.getInstance().player != null;
    return true;
  }

  // ------------------------------------------------------------------ lifecycle

  @Override
  protected void init() {
    layout = net.mcreator.climber.client.SettingsLayout.get();
    ACCENT = layout.color();
    openedAt = openedAt == 0 ? System.currentTimeMillis() : openedAt;
    left = Math.max(16, (int) (width * 0.06f)) + (int) (width * layout.element("Tabs").x);
    tabsY = (int) (height * (0.30f + layout.element("Tabs").y));
    divider = Math.max(left + 100, (int) (width * (0.30f + layout.element("Panel").x)));
    divider = Mth.clamp(divider, 100, Math.max(101, width - 200));
    rowsX0 = divider + 18;
    rowsX1 = width - left;
    rowsY = (int) (height * (0.24f + layout.element("Panel").y));
    rowH = Math.max((int) layout.rowSpacing, width < 650 ? 30 : 22);
    footerY = height - 30;
  }

  private void resetKeys(int i) {
    CompoundTag d = ClimberConfig.defaultSyncTag();
    for (String k : KEYS[i]) draft.put(k, d.get(k).copy());
    dirty = true;
  }

  private void chooseSound(String key) {
    try (org.lwjgl.system.MemoryStack stack = org.lwjgl.system.MemoryStack.stackPush()) {
      var patterns = stack.mallocPointer(2);
      patterns.put(stack.UTF8("*.ogg")).put(stack.UTF8("*.wav")).flip();
      String path =
          org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog(
              "Select local Climber sound",
              System.getProperty("user.home") + java.io.File.separator,
              patterns,
              "OGG Vorbis / PCM WAV",
              false);
      if (path != null) {
        net.mcreator.climber.client.ClientSoundChoices.set(key, path);
        message = "Local sound saved on this PC.";
      }
    } catch (Exception | LinkageError e) {
      message = "File picker unavailable: " + e.getMessage() + ". Use local path entry.";
      Minecraft.getInstance()
          .setScreen(
              new ValueEntryScreen(
                  this,
                  "Local audio file",
                  "",
                  "Absolute path to .ogg or PCM .wav on this PC.",
                  v -> net.mcreator.climber.client.ClientSoundChoices.set(key, v)));
    }
  }

  private void apply() {
    if (pending || !serverEditable() || !dirty) return;
    try {
      net.mcreator.climber.config.ConfigValidation.validate(draft, false);
    } catch (RuntimeException e) {
      message = e.getMessage();
      return;
    }
    var mc = Minecraft.getInstance();
    if (mc.player != null && mc.getConnection() != null) {
      pending = true;
      revision = ConfigSyncPacket.clientRevision;
      sent = System.currentTimeMillis();
      ClimberMod.PACKET_HANDLER.sendToServer(new ConfigUpdatePacket(draft.copy()));
      message = "Waiting for server confirmation...";
    } else {
      ClimberConfig.INSTANCE.applySyncTag(draft);
      ClimberConfig.INSTANCE.save();
      dirty = false;
      message = "Settings saved.";
    }
  }

  @Override
  public void tick() {
    if (pending && ConfigSyncPacket.clientRevision != revision) {
      pending = false;
      draft = ClimberConfig.INSTANCE.toSyncTag();
      dirty = false;
      message = "Server settings synchronized. Check chat for any rejection.";
    } else if (pending && System.currentTimeMillis() - sent > 10000) {
      pending = false;
      message = "No server reply yet; settings have not been confirmed.";
    }
  }

  @Override
  public void onClose() {
    if (pending) {
      message = "Wait for the server confirmation.";
      return;
    }
    if (dirty)
      Minecraft.getInstance()
          .setScreen(
              new net.minecraft.client.gui.screens.ConfirmScreen(
                  ok -> Minecraft.getInstance().setScreen(ok ? parent : this),
                  Component.literal("Discard unapplied settings?"),
                  Component.literal(
                      "Apply saves gameplay settings. Local UI and sound choices save separately."),
                  Component.literal("Discard"),
                  Component.literal("Keep editing")));
    else Minecraft.getInstance().setScreen(parent);
  }

  @Override
  public boolean isPauseScreen() {
    return true;
  }

  // ------------------------------------------------------------------ render

  @Override
  public void render(GuiGraphics g, int mx, int my, float partial) {
    float fade = Mth.clamp((System.currentTimeMillis() - openedAt) / 180f, 0f, 1f);
    int bgA = (int) (0xE8 * fade);
    g.fill(0, 0, width, height, (bgA << 24) | 0x0A0A0C);
    for (int y = 0; y < height; y += 3) g.fill(0, y, width, y + 1, 0x08FFFFFF); // faint scanlines

    text(
        g,
        layout.label("Header", "THE CLIMBER"),
        Math.max(16, (int) (width * (.06f + layout.element("Header").x))),
        (int) (height * (.08f + layout.element("Header").y)),
        3f * layout.element("Header").scale,
        WHITE);
    text(
        g,
        "SETTINGS",
        Math.max(18, (int) (width * (.06f + layout.element("Header").x)) + 2),
        (int) (height * (.08f + layout.element("Header").y)) + 30,
        1.5f,
        DIM);

    // tabs
    for (int i = 0; i < tabs.size(); i++) {
      var tabCustom = layout.element("tab:" + tabs.get(i).name());
      if (!tabCustom.visible) continue;
      int tabX = left + (int) (width * tabCustom.x);
      int y = tabY(i) + (int) (height * tabCustom.y);
      boolean hov =
          mx >= tabX - 6
              && mx < divider - 8 + (int) (width * tabCustom.x)
              && my >= y - 4
              && my < y + Math.min(20, tabStep());
      boolean sel = i == tab;
      int col = sel ? WHITE : hov ? LIGHT : DIM;
      if (sel) g.fill(tabX - 8, y - 2, tabX - 5, y + 12, ACCENT);
      text(
          g,
          (sel ? "> " : "")
              + layout
                  .label("tab:" + tabs.get(i).name(), tabs.get(i).name())
                  .toUpperCase(Locale.ROOT),
          tabX,
          y,
          (width < 650 ? 1.2f : 2f) * layout.element("Tabs").scale * tabCustom.scale,
          col);
    }
    g.fill(divider, rowsY - 12, divider + 1, footerY - 14, 0x30FFFFFF);

    // rows
    Tab t = tabs.get(tab);
    if (t.server() && !serverEditable()) {
      text(g, "SERVER SETTINGS - OPERATORS ONLY", rowsX0, rowsY - 14, 1f, 0xFFB05050);
    } else if (t.server()) {
      text(
          g,
          "SERVER SETTINGS" + (dirty ? "  -  UNAPPLIED DRAFT" : ""),
          rowsX0,
          rowsY - 14,
          1f,
          DARK);
    }
    Row hovered = null;
    g.enableScissor(
        Math.max(0, rowsX0 - 6),
        Math.max(0, rowsY - 5),
        Math.min(width, rowsX1 + 6),
        Math.max(rowsY, footerY - 28));
    for (int i = 0; i < t.rows().size(); i++) {
      Row r = t.rows().get(i);
      if (!layout.element("row:" + r.label).visible) continue;
      int y = rowY(i, r);
      if (y + rowH < rowsY || y > footerY - 28) continue;
      int rx0 = rowsX0 + (int) (width * layout.element("row:" + r.label).x),
          rx1 = rowsX1 + (int) (width * layout.element("row:" + r.label).x);
      float rowScale = layout.element("row:" + r.label).scale * layout.element("Panel").scale;
      boolean en = rowEnabled(r);
      boolean hov = mx >= rx0 - 6 && mx < rx1 + 6 && my >= y - 5 && my < y + rowH - 5;
      if (hov) hovered = r;
      if (hov && en) g.fill(rx0 - 6, y - 5, rx1 + 6, y + rowH - 5, 0x16FFFFFF);
      int labelCol = r instanceof InfoRow ? ACCENT : !en ? DARK : hov ? WHITE : LIGHT;
      var custom = layout.element("row:" + r.label);
      text(
          g,
          layout.label("row:" + r.label, r.label).toUpperCase(Locale.ROOT),
          rx0,
          y + 2,
          rowScale,
          labelCol);
      if (width < 650) y += 13;

      int valCol = !en && !(r instanceof InfoRow) ? DARK : (r instanceof InfoRow ? LIGHT : WHITE);
      String v = r.value().toUpperCase(Locale.ROOT);
      if (r instanceof SliderRow s) {
        int t0 = rx1 - 170, t1 = rx1 - 60, ty = y + 6;
        g.fill(t0, ty, t1, ty + 1, 0x50FFFFFF);
        int kx = t0 + (int) Math.round(s.frac() * (t1 - t0));
        g.fill(t0, ty - 1, kx, ty + 2, en ? 0xC0FFFFFF : 0x60FFFFFF);
        g.fill(kx - 2, ty - 5, kx + 2, ty + 6, en ? (hov || dragging == s ? ACCENT : WHITE) : DARK);
        text(g, v, rx1 - (int) (font.width(v) * rowScale), y + 2, rowScale, valCol);
      } else if (r instanceof InfoRow) {
        text(g, v, rx1 - (int) (font.width(v) * rowScale), y + 2, rowScale, valCol);
      } else {
        String shown = "<  " + v + "  >";
        int col = valCol;
        if (r instanceof ToggleRow && en) col = v.equals("ON") ? 0xFF9FE08A : 0xFFB0B0B0;
        text(g, shown, rx1 - (int) (font.width(shown) * rowScale), y + 2, rowScale, col);
      }
    }

    g.disableScissor();
    int total = t.rows().size() * rowH, visible = footerY - 28 - rowsY;
    if (total > visible && visible > 0) {
      int x = width - 8,
          thumb = Math.max(10, visible * visible / total),
          y = rowsY + (int) (scroll * (visible - thumb) / (float) (total - visible));
      g.fill(x, rowsY, x + 1, rowsY + visible, 0x30FFFFFF);
      g.fill(x - 1, y, x + 2, y + thumb, ACCENT);
    }

    // hint
    if (hovered != null && hovered.hint != null) {
      g.drawString(
          font,
          font.plainSubstrByWidth(hovered.hint, width - rowsX0 - 8),
          rowsX0,
          footerY - 18,
          DIM,
          false);
    }

    // footer buttons
    if (t.reset() != null) button(g, "RESET TAB", resetX(), footerY + 6, mx, my);
    button(g, "DONE", doneX(), footerY + 6, mx, my);
    button(g, pending ? "WAIT" : "APPLY", applyX(), footerY + 6, mx, my);
    button(g, "EDIT UI", Math.max(8, left), footerY + 6, mx, my);
    if (!message.isBlank())
      g.drawString(font, font.plainSubstrByWidth(message, width - 16), 8, height - 10, DIM, false);
    super.render(g, mx, my, partial);
  }

  private float footerScale() {
    return width < 520 ? 1f : 1.5f;
  }

  private int applyX() {
    return resetX() - 30 - (int) (font.width("APPLY") * footerScale());
  }

  private int tabStep() {
    return Math.min(26, Math.max(16, (footerY - tabsY - 16) / Math.max(1, tabs.size())));
  }

  private int tabY(int i) {
    return tabsY + i * tabStep();
  }

  private int rowY(int i, Row r) {
    return rowsY + i * rowH - (int) scroll + (int) (height * layout.element("row:" + r.label).y);
  }

  private int doneX() {
    return rowsX1 - (int) (font.width("DONE") * footerScale());
  }

  private int resetX() {
    return doneX() - 30 - (int) (font.width("RESET TAB") * footerScale());
  }

  private boolean overButton(String label, int x, int y, double mx, double my) {
    return mx >= x - 4
        && mx <= x + font.width(label) * footerScale() + 4
        && my >= y - 4
        && my <= y + 14;
  }

  private void button(GuiGraphics g, String label, int x, int y, int mx, int my) {
    boolean hov = overButton(label, x, y, mx, my);
    text(g, label, x, y, footerScale(), hov ? WHITE : DIM);
    if (hov) g.fill(x, y + 14, x + (int) (font.width(label) * footerScale()), y + 15, ACCENT);
  }

  private void text(GuiGraphics g, String s, int x, int y, float scale, int color) {
    g.pose().pushPose();
    g.pose().translate(x, y, 0);
    g.pose().scale(scale, scale, 1f);
    g.drawString(font, s, 0, 0, color, false);
    g.pose().popPose();
  }

  // ------------------------------------------------------------------ input

  @Override
  public boolean mouseClicked(double mx, double my, int button) {
    for (int i = 0; i < tabs.size(); i++) {
      var tabCustom = layout.element("tab:" + tabs.get(i).name());
      if (!tabCustom.visible) continue;
      int tabX = left + (int) (width * tabCustom.x);
      int y = tabY(i) + (int) (height * tabCustom.y);
      if (mx >= tabX - 6
          && mx < divider - 8 + (int) (width * tabCustom.x)
          && my >= y - 4
          && my < y + Math.min(20, tabStep())) {
        if (tab != i) {
          tab = i;
          scroll = 0;
          playClick();
        }
        return true;
      }
    }
    Tab t = tabs.get(tab);
    if (overButton("EDIT UI", Math.max(8, left), footerY + 6, mx, my)) {
      Minecraft.getInstance().setScreen(new SettingsLayoutScreen(this));
      return true;
    }
    if (overButton(pending ? "WAIT" : "APPLY", applyX(), footerY + 6, mx, my)) {
      apply();
      return true;
    }
    if (overButton("DONE", doneX(), footerY + 6, mx, my)) {
      playClick();
      onClose();
      return true;
    }
    if (t.reset() != null && overButton("RESET TAB", resetX(), footerY + 6, mx, my)) {
      if (!pending && (!t.server() || serverEditable())) {
        t.reset().run();
        playClick();
      }
      return true;
    }
    Row r = rowAt(mx, my);
    if (r != null && rowEnabled(r)) {
      int dx = (int) (width * layout.element("row:" + r.label).x);
      r.click(mx, rowsX0 + dx, rowsX1 + dx, button);
      return true;
    }
    return super.mouseClicked(mx, my, button);
  }

  @Override
  public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
    if (dragging != null) {
      int offsetX = (int) (width * layout.element("row:" + dragging.label).x);
      int t0 = rowsX1 + offsetX - 170, t1 = rowsX1 + offsetX - 60;
      double before = dragging.get.getAsDouble();
      double v =
          dragging.min + Mth.clamp((mx - t0) / (t1 - t0), 0, 1) * (dragging.max - dragging.min);
      v = Math.round(v / dragging.step) * dragging.step;
      if (Math.abs(v - before) > 1e-9) {
        dragging.set.accept(Mth.clamp(v, dragging.min, dragging.max));
        if (dragging.server) dirty = true;
      }
      return true;
    }
    return super.mouseDragged(mx, my, button, dx, dy);
  }

  @Override
  public boolean mouseReleased(double mx, double my, int button) {
    if (dragging != null) {
      dragging = null;
      return true;
    }
    return super.mouseReleased(mx, my, button);
  }

  @Override
  public boolean mouseScrolled(double mx, double my, double delta) {
    if (mx >= rowsX0 && my >= rowsY - 5 && my < footerY - 28) {
      scroll =
          Mth.clamp(
              scroll - (float) (delta * rowH),
              0,
              Math.max(0, tabs.get(tab).rows.size() * rowH - (footerY - 28 - rowsY)));
      return true;
    }
    return super.mouseScrolled(mx, my, delta);
  }

  @Override
  public boolean keyPressed(int key, int scan, int mods) {
    if (key == GLFW.GLFW_KEY_TAB
        || key == GLFW.GLFW_KEY_DOWN && (mods & GLFW.GLFW_MOD_CONTROL) != 0) {
      tab = (tab + 1) % tabs.size();
      scroll = 0;
      playClick();
      return true;
    }
    if (ClimberKeybinds.KEY_OPEN_CONFIG.matches(key, scan)) {
      onClose();
      return true;
    }
    return super.keyPressed(key, scan, mods);
  }

  private Row rowAt(double mx, double my) {
    if (my < rowsY - 5 || my >= footerY - 28) return null;
    List<Row> rows = tabs.get(tab).rows();
    for (int i = 0; i < rows.size(); i++) {
      Row r = rows.get(i);
      if (!layout.element("row:" + r.label).visible) continue;
      int y = rowY(i, r);
      if (y + rowH < rowsY || y > footerY - 28) continue;
      int dx = (int) (width * layout.element("row:" + r.label).x);
      if (mx >= rowsX0 + dx - 6 && mx < rowsX1 + dx + 6 && my >= y - 5 && my < y + rowH - 5)
        return rows.get(i);
    }
    return null;
  }
}
