package net.mcreator.climber.entity;

import net.mcreator.climber.init.ClimberModEntities;
import net.mcreator.climber.init.ClimberModItems;
import net.mcreator.climber.item.HammerItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A piton driven into a surface. Behaves like in White Knuckle:
 * <ul>
 *   <li>0-2 hammer hits: unstable. Holding it slowly pulls it out
 *       (0.45 s / 3.5 s / 6.55 s total grip time). Letting go does NOT reset the timer.</li>
 *   <li>3 hammer hits: permanent handhold.</li>
 *   <li>Falls out if the block it is in disappears. Sneak + right click with an empty hand to take it back.</li>
 * </ul>
 */
public class PitonEntity extends Entity implements HandholdEntity {

    /** Total grip ticks allowed per hammer level (0, 1, 2 hits). 3 hits = infinite. */
    public static final int[] GRIP_LIMIT = { 9, 70, 131 };
    public static final int MAX_HAMMER = 3;
    /** Distance the grip point sticks out of the wall. */
    public static final double OUT = 0.18;

    private static final EntityDataAccessor<Integer> FACE = SynchedEntityData.defineId(PitonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> HAMMERED = SynchedEntityData.defineId(PitonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> GRIP_USED = SynchedEntityData.defineId(PitonEntity.class, EntityDataSerializers.INT);

    private BlockPos attachPos = BlockPos.ZERO;
    private long lastGripTick = -1;

    public PitonEntity(EntityType<? extends PitonEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public static PitonEntity create(Level level, Vec3 surfacePoint, Direction face, BlockPos attachPos) {
        PitonEntity p = new PitonEntity(ClimberModEntities.PITON.get(), level);
        p.entityData.set(FACE, face.get3DDataValue());
        p.attachPos = attachPos.immutable();
        Vec3 c = surfacePoint.add(face.getStepX() * OUT, face.getStepY() * OUT, face.getStepZ() * OUT);
        p.setPos(c.x, c.y - p.getBbHeight() / 2.0, c.z);
        return p;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(FACE, Direction.NORTH.get3DDataValue());
        this.entityData.define(HAMMERED, 0);
        this.entityData.define(GRIP_USED, 0);
    }

    public Direction getFace() {
        int id = this.entityData.get(FACE);
        return Direction.from3DDataValue(id);
    }

    public int getHammered() { return this.entityData.get(HAMMERED); }
    public int getGripUsed() { return this.entityData.get(GRIP_USED); }
    public boolean isSecured() { return getHammered() >= MAX_HAMMER; }

    /** 0 = fresh, 1 = about to pop out. */
    public float getLooseness() {
        if (isSecured()) return 0f;
        return Math.min(1f, getGripUsed() / (float) GRIP_LIMIT[getHammered()]);
    }

    /** Point on the wall surface where the piton enters. */
    public Vec3 getSurfacePoint() {
        Direction f = getFace();
        return getGripPoint().subtract(f.getStepX() * OUT, f.getStepY() * OUT, f.getStepZ() * OUT);
    }

    @Override
    public Vec3 getGripPoint() {
        return position().add(0, getBbHeight() / 2.0, 0);
    }

    @Override
    public boolean canBeGrabbed() {
        return isAlive();
    }

    @Override
    public void onGripTick(Player player) {
        if (level().isClientSide() || isSecured()) return;
        long now = level().getGameTime();
        if (now == lastGripTick) return; // two hands on one piton don't double the wear
        lastGripTick = now;
        int used = getGripUsed() + 1;
        this.entityData.set(GRIP_USED, used);
        if (used >= GRIP_LIMIT[getHammered()]) {
            popOut();
        }
    }

    /** One hammer blow. */
    public void hammer(Player by) {
        if (level().isClientSide()) return;
        int h = getHammered();
        Vec3 g = getGripPoint();
        if (h >= MAX_HAMMER) {
            level().playSound(null, g.x, g.y, g.z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.35f, 1.9f);
            return;
        }
        this.entityData.set(HAMMERED, h + 1);
        level().playSound(null, g.x, g.y, g.z, SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.55f, 1.35f + 0.2f * h);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CRIT, g.x, g.y, g.z, 6, 0.05, 0.05, 0.05, 0.15);
        }
    }

    /** Charged hammer swing: fully secured in one hit. */
    public void secure(Player by) {
        if (level().isClientSide()) return;
        while (getHammered() < MAX_HAMMER) hammer(by);
    }

    public void popOut() {
        if (level().isClientSide() || !isAlive()) return;
        Vec3 g = getGripPoint();
        Direction f = getFace();
        ItemEntity item = new ItemEntity(level(), g.x, g.y, g.z, new ItemStack(ClimberModItems.PITON.get()));
        item.setDeltaMovement(f.getStepX() * 0.15, 0.15, f.getStepZ() * 0.15);
        item.setDefaultPickUpDelay();
        level().addFreshEntity(item);
        level().playSound(null, g.x, g.y, g.z, SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.0f, 1.3f);
        discard();
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide() && tickCount % 10 == 0) {
            if (level().isLoaded(attachPos)
                    && level().getBlockState(attachPos).getCollisionShape(level(), attachPos).isEmpty()) {
                popOut(); // the wall is gone
            }
        }
    }

    // ---- interaction ----

    @Override
    public boolean isPickable() {
        return isAlive();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    /** Left click: hammering with the hammer, otherwise nothing (and no damage). */
    @Override
    public boolean skipAttackInteraction(Entity attacker) {
        if (!level().isClientSide() && attacker instanceof Player p && p.getMainHandItem().getItem() instanceof HammerItem) {
            hammer(p);
        }
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(net.minecraft.tags.DamageTypeTags.IS_EXPLOSION)) popOut();
        return false;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof HammerItem) {
            if (!level().isClientSide()) {
                hammer(player);
                player.getCooldowns().addCooldown(held.getItem(), 8);
            }
            return InteractionResult.sidedSuccess(level().isClientSide());
        }
        if (player.isShiftKeyDown() && held.isEmpty() && hand == InteractionHand.MAIN_HAND) {
            if (!level().isClientSide()) {
                if (!player.getAbilities().instabuild) {
                    ItemStack stack = new ItemStack(ClimberModItems.PITON.get());
                    if (!player.getInventory().add(stack)) player.drop(stack, false);
                }
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 0.8f, 1.5f);
                discard();
            }
            return InteractionResult.sidedSuccess(level().isClientSide());
        }
        return InteractionResult.PASS;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distSq) {
        return distSq < 64.0 * 64.0;
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ClimberModItems.PITON.get());
    }

    // ---- persistence ----

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(FACE, tag.getInt("Face"));
        this.entityData.set(HAMMERED, tag.getInt("Hammered"));
        this.entityData.set(GRIP_USED, tag.getInt("GripUsed"));
        this.attachPos = BlockPos.of(tag.getLong("Attach"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Face", this.entityData.get(FACE));
        tag.putInt("Hammered", this.entityData.get(HAMMERED));
        tag.putInt("GripUsed", this.entityData.get(GRIP_USED));
        tag.putLong("Attach", attachPos.asLong());
    }
}
