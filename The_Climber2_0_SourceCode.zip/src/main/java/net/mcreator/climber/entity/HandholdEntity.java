package net.mcreator.climber.entity;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** An entity the climber can grab like a block hold (pitons, stuck rebar). */
public interface HandholdEntity {
    /** World point the hand attaches to. */
    Vec3 getGripPoint();

    /** False while flying, after being pulled out, etc. */
    boolean canBeGrabbed();

    /** Server, once per tick per hand holding it. */
    default void onGripTick(Player player) {}
}
