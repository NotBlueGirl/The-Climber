package net.mcreator.climber.entity;

import net.mcreator.climber.init.ClimberModEntities;
import net.mcreator.climber.init.ClimberModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** A thrown brick. Hurts what it hits, smashes glass, bounces once off walls and then drops as an item. */
public class ThrownBrickEntity extends ThrowableItemProjectile {
    private int bounces = 0;

    public ThrownBrickEntity(EntityType<? extends ThrownBrickEntity> type, Level level) {
        super(type, level);
    }

    public ThrownBrickEntity(Level level, LivingEntity thrower) {
        super(ClimberModEntities.THROWN_BRICK.get(), thrower, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ClimberModItems.THROWABLE_BRICK.get();
    }

    @Override
    protected float getGravity() {
        return 0.05f; // heavier than a snowball
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 3) {
            ItemParticleOption p = new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(getDefaultItem()));
            for (int i = 0; i < 8; i++) {
                level().addParticle(p, getX(), getY(), getZ(),
                        (random.nextDouble() - 0.5) * 0.15, random.nextDouble() * 0.15, (random.nextDouble() - 0.5) * 0.15);
            }
        } else {
            super.handleEntityEvent(id);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        double speed = getDeltaMovement().length();
        float dmg = (float) Mth.clamp(2.0 + speed * 3.5, 2.0, 8.0);
        Entity owner = getOwner();
        DamageSource src = damageSources().thrown(this, owner == null ? this : owner);
        if (target.hurt(src, dmg) && target instanceof LivingEntity le) {
            Vec3 k = getDeltaMovement().multiply(1, 0, 1).normalize();
            le.knockback(0.5, -k.x, -k.z);
        }
        if (!level().isClientSide()) {
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.STONE_HIT, SoundSource.NEUTRAL, 1.0f, 0.7f);
            setDeltaMovement(getDeltaMovement().scale(-0.15));
            land(getDeltaMovement());
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (level().isClientSide()) return;
        BlockPos pos = result.getBlockPos();
        BlockState state = level().getBlockState(pos);
        double speed = getDeltaMovement().length();

        // smash glass / panes / glowstone-like fragile blocks
        float hardness = state.getDestroySpeed(level(), pos);
        if (speed > 0.5 && state.getSoundType() == SoundType.GLASS && hardness >= 0 && hardness <= 0.5f) {
            level().destroyBlock(pos, true, this);
            setDeltaMovement(getDeltaMovement().scale(0.6)); // keeps flying through
            return;
        }

        level().playSound(null, getX(), getY(), getZ(), SoundEvents.STONE_HIT, SoundSource.NEUTRAL, 1.0f, 0.6f);
        Direction face = result.getDirection();
        Vec3 n = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
        Vec3 v = getDeltaMovement();
        if (bounces == 0 && speed > 0.45 && face.getAxis().isHorizontal()) {
            bounces++;
            Vec3 r = v.subtract(n.scale(2 * v.dot(n))).scale(0.3);
            setPos(result.getLocation().add(n.scale(0.1)));
            setDeltaMovement(r);
            return;
        }
        setPos(result.getLocation().add(n.scale(0.15)));
        land(v.scale(0.1));
    }

    private void land(Vec3 vel) {
        level().broadcastEntityEvent(this, (byte) 3);
        boolean creative = getOwner() instanceof Player p && p.getAbilities().instabuild;
        if (!creative) {
            ItemStack drop = getItem().copy();
            drop.setCount(1);
            ItemEntity ie = new ItemEntity(level(), getX(), getY(), getZ(), drop);
            ie.setDeltaMovement(vel.x, Math.max(0.05, vel.y), vel.z);
            ie.setPickUpDelay(10);
            level().addFreshEntity(ie);
        }
        discard();
    }
}
