package net.mcreator.climber.entity;

import net.mcreator.climber.init.ClimberModEntities;
import net.mcreator.climber.init.ClimberModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ForgeEventFactory;
import org.joml.Vector3f;

/**
 * Thrown rebar. Sticks into whatever it hits and becomes a permanent handhold. Ricochets when the
 * impact angle is too shallow.
 *
 * <p>NOTE: this deliberately extends {@link Projectile} and NOT AbstractArrow: the vanilla server
 * kicks a player with "Attempt to attack an invalid entity" when they left-click any AbstractArrow.
 *
 * <p>Pick it up: left click it (not while climbing), or right click / sneak + right click with an
 * empty hand. While stuck its hitbox covers the whole rod, so aiming at the rod targets the rebar,
 * not the wall behind.
 */
public class RebarEntity extends Projectile implements HandholdEntity {

  /**
   * Impacts flatter than this (cosine to the surface normal) ricochet. ~70 degrees from the normal.
   */
  public static final double RICOCHET_COS = 0.34;

  /** Distance from the wall to the grip point along the rod. */
  public static final double GRIP_OUT = 0.55;

  /** Length of the rod that sticks out of the wall (matches RebarRenderer). */
  public static final double ROD_OUT = 1.1;

  private static final EntityDataAccessor<Boolean> STUCK =
      SynchedEntityData.defineId(RebarEntity.class, EntityDataSerializers.BOOLEAN);
  private static final EntityDataAccessor<Vector3f> STUCK_DIR =
      SynchedEntityData.defineId(RebarEntity.class, EntityDataSerializers.VECTOR3);

  private int ricochets = 0;
  private BlockPos stuckPos;
  private BlockState stuckState;
  private int flightTicks = 0;
  private int haltTicks = 0;

  /** Client visual: wobble right after impact. */
  public int shakeTime = 0;

  /** Non-null while stuck; drives the rod-shaped bounding box (no initializer on purpose). */
  private Vec3 boxDir;

  public RebarEntity(EntityType<? extends RebarEntity> type, Level level) {
    super(type, level);
  }

  public RebarEntity(Level level, LivingEntity shooter) {
    this(ClimberModEntities.REBAR.get(), level);
    setOwner(shooter);
    setPos(shooter.getX(), shooter.getEyeY() - 0.1, shooter.getZ());
  }

  @Override
  protected void defineSynchedData() {
    this.entityData.define(STUCK, false);
    this.entityData.define(STUCK_DIR, new Vector3f(0, 0, 1));
  }

  public boolean isStuck() {
    return this.entityData.get(STUCK);
  }

  /** Flight direction at impact (points INTO the wall). */
  public Vec3 getStuckDir() {
    Vector3f v = this.entityData.get(STUCK_DIR);
    return new Vec3(v.x(), v.y(), v.z());
  }

  public ItemStack getPickupItem() {
    return new ItemStack(ClimberModItems.REBAR.get());
  }

  // ------------------------------------------------------------------ flight

  @Override
  public void tick() {
    super.tick();
    if (isStuck()) {
      if (shakeTime > 0) shakeTime--;
      setDeltaMovement(Vec3.ZERO);
      if (!level().isClientSide() && (tickCount & 3) == 0 && !anchorStillThere()) unstick();
      return;
    }

    if (haltTicks > 0) {
      haltTicks--;
      return;
    }
    flightTicks++;
    HitResult hit = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
    if (hit.getType() != HitResult.Type.MISS && !ForgeEventFactory.onProjectileImpact(this, hit)) {
      onHit(hit);
    }
    if (isRemoved() || isStuck()) return;

    Vec3 v = getDeltaMovement();
    setPos(getX() + v.x, getY() + v.y, getZ() + v.z);
    updateRotation();
    double drag = isInWater() ? 0.6 : 0.99;
    v = v.scale(drag);
    if (!isNoGravity()) v = v.add(0, -0.05, 0);
    setDeltaMovement(v);
    checkInsideBlocks();

    if (level().isClientSide() && flightTicks > 1) {
      level()
          .addParticle(
              ParticleTypes.CRIT, getX(), getY(), getZ(), -v.x * 0.1, -v.y * 0.1, -v.z * 0.1);
    }
    if (!level().isClientSide()
        && (getY() < level().getMinBuildHeight() - 64 || flightTicks > 1200)) discard();
  }

  private boolean anchorStillThere() {
    if (stuckPos == null) return false;
    if (!level().isLoaded(stuckPos)) return true;
    BlockState now = level().getBlockState(stuckPos);
    if (stuckState == null) stuckState = now;
    return !now.getCollisionShape(level(), stuckPos).isEmpty();
  }

  private void unstick() {
    this.entityData.set(STUCK, false);
    stuckPos = null;
    stuckState = null;
    ricochets = 99; // a falling rebar does not stick again
    setDeltaMovement(getStuckDir().scale(-0.05).add(0, 0.05, 0));
    this.hasImpulse = true;
  }

  @Override
  protected void onHitBlock(BlockHitResult result) {
    Vec3 v = getDeltaMovement();
    double speed = v.length();
    Direction face = result.getDirection();
    Vec3 n = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
    Vec3 dir = speed > 1.0e-4 ? v.scale(1.0 / speed) : n.scale(-1);
    double cos = -dir.dot(n);

    if (ricochets >= 99 || speed < 0.45) {
      // falling / tumbling rebar: lands and can be picked up as an item
      setDeltaMovement(Vec3.ZERO);
      if (!level().isClientSide()) {
        setPos(result.getLocation().add(n.scale(0.1)));
        dropAsItem();
      }
      return;
    }
    if (cos < RICOCHET_COS && ricochets < 4) {
      // glancing hit: bounce off and keep flying - it may stick into the next surface
      Vec3 reflected = dir.subtract(n.scale(2.0 * dir.dot(n))).scale(speed * 0.55);
      setPos(result.getLocation().add(n.scale(0.05)));
      setDeltaMovement(reflected);
      ricochets++;
      if (!level().isClientSide()) {
        level()
            .playSound(
                null,
                getX(),
                getY(),
                getZ(),
                SoundEvents.CHAIN_HIT,
                SoundSource.NEUTRAL,
                1.0f,
                1.6f);
      }
      return;
    }

    super.onHitBlock(result); // lets target blocks, bells... react
    setPos(result.getLocation());
    setDeltaMovement(Vec3.ZERO);
    if (level().isClientSide())
      haltTicks = 10; // wait for the server's STUCK flag instead of falling
    if (!level().isClientSide()) {
      stuckPos = result.getBlockPos();
      stuckState = level().getBlockState(stuckPos);
      this.entityData.set(STUCK_DIR, new Vector3f((float) dir.x, (float) dir.y, (float) dir.z));
      this.entityData.set(STUCK, true);
      this.hasImpulse = true; // push the final position to clients right away
      level()
          .playSound(
              null,
              getX(),
              getY(),
              getZ(),
              SoundEvents.TRIDENT_HIT_GROUND,
              SoundSource.NEUTRAL,
              1.0f,
              0.9f);
      if (level() instanceof ServerLevel sl) {
        sl.sendParticles(
            new BlockParticleOption(ParticleTypes.BLOCK, stuckState),
            getX(),
            getY(),
            getZ(),
            8,
            0.05,
            0.05,
            0.05,
            0.1);
      }
    }
  }

  @Override
  protected void onHitEntity(EntityHitResult result) {
    super.onHitEntity(result);
    if (level().isClientSide()) {
      setDeltaMovement(getDeltaMovement().scale(-0.1));
      return;
    }
    Entity target = result.getEntity();
    Entity owner = getOwner();
    double speed = getDeltaMovement().length();
    float dmg =
        (float)
            Mth.clamp(4.0 + speed * 2.5, 4.0, 12.0); // ~10.5 at full speed: one-shots small mobs
    DamageSource src = damageSources().thrown(this, owner == null ? this : owner);
    if (target.hurt(src, dmg)) {
      if (target instanceof LivingEntity le) {
        net.mcreator.climber.event.RebarKnockback.start(le, getDeltaMovement());
      }
      level()
          .playSound(
              null,
              getX(),
              getY(),
              getZ(),
              SoundEvents.TRIDENT_HIT,
              SoundSource.NEUTRAL,
              1.0f,
              1.0f);
    }
    // fall down next to the target
    setDeltaMovement(getDeltaMovement().scale(-0.08));
    ricochets = 99;
  }

  @Override
  protected boolean canHitEntity(Entity e) {
    return super.canHitEntity(e) && !(e instanceof HandholdEntity);
  }

  private void dropAsItem() {
    if (!(getOwner() instanceof Player p && p.getAbilities().instabuild))
      spawnAtLocation(getPickupItem(), 0.1f);
    discard();
  }

  // ------------------------------------------------------------------ pick up

  /**
   * Left click (attack) on the rebar: pull it out. Never "damages" it -> no invalid-attack kick, no
   * block breaking.
   */
  @Override
  public boolean skipAttackInteraction(Entity attacker) {
    if (attacker instanceof Player p && !level().isClientSide() && isAlive()) pickUp(p);
    return true;
  }

  @Override
  public boolean hurt(DamageSource source, float amount) {
    return false;
  }

  @Override
  public InteractionResult interact(Player player, InteractionHand hand) {
    if (hand == InteractionHand.MAIN_HAND && player.getItemInHand(hand).isEmpty()) {
      if (!level().isClientSide()) pickUp(player);
      return InteractionResult.sidedSuccess(level().isClientSide());
    }
    return InteractionResult.PASS;
  }

  public void pickUp(Player player) {
    if (!isAlive()) return;
    ItemStack stack = getPickupItem();
    boolean give = !player.getAbilities().instabuild || !player.getInventory().contains(stack);
    if (give && !player.getInventory().add(stack)) player.drop(stack, false);
    level()
        .playSound(
            null, getX(), getY(), getZ(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.5f, 0.8f);
    if (stuckState != null && level() instanceof ServerLevel sl) {
      sl.sendParticles(
          new BlockParticleOption(ParticleTypes.BLOCK, stuckState),
          getX(),
          getY(),
          getZ(),
          6,
          0.05,
          0.05,
          0.05,
          0.1);
    }
    discard();
  }

  @Override
  public boolean isPickable() {
    return isAlive() && (isStuck() || getDeltaMovement().lengthSqr() < 0.01);
  }

  @Override
  public boolean isAttackable() {
    return true;
  }

  @Override
  public float getPickRadius() {
    return 0.0f;
  }

  @Override
  public ItemStack getPickResult() {
    return getPickupItem();
  }

  // ------------------------------------------------------------------ rod-shaped hitbox

  @Override
  protected AABB makeBoundingBox() {
    Vec3 d = this.boxDir;
    if (d == null) return super.makeBoundingBox();
    Vec3 tip = position();
    Vec3 end = tip.subtract(d.scale(ROD_OUT));
    return new AABB(tip, end).inflate(0.12);
  }

  @Override
  public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
    super.onSyncedDataUpdated(key);
    if (STUCK.equals(key) || STUCK_DIR.equals(key)) {
      boolean stuck = isStuck();
      if (stuck && boxDir == null && level().isClientSide()) shakeTime = 7;
      boxDir = stuck ? getStuckDir() : null;
      setBoundingBox(makeBoundingBox());
    }
  }

  @Override
  public boolean shouldRenderAtSqrDistance(double d) {
    return d < 128 * 128;
  }

  // ------------------------------------------------------------------ HandholdEntity

  @Override
  public Vec3 getGripPoint() {
    return position().subtract(getStuckDir().scale(GRIP_OUT));
  }

  @Override
  public boolean canBeGrabbed() {
    return isStuck() && isAlive();
  }

  // ------------------------------------------------------------------ persistence

  @Override
  public void addAdditionalSaveData(CompoundTag tag) {
    super.addAdditionalSaveData(tag);
    tag.putBoolean("Stuck", isStuck());
    Vector3f d = this.entityData.get(STUCK_DIR);
    tag.putFloat("DirX", d.x());
    tag.putFloat("DirY", d.y());
    tag.putFloat("DirZ", d.z());
    if (stuckPos != null) tag.putLong("StuckPos", stuckPos.asLong());
  }

  @Override
  public void readAdditionalSaveData(CompoundTag tag) {
    super.readAdditionalSaveData(tag);
    if (tag.contains("DirX")) {
      this.entityData.set(
          STUCK_DIR,
          new Vector3f(tag.getFloat("DirX"), tag.getFloat("DirY"), tag.getFloat("DirZ")));
    }
    this.entityData.set(STUCK, tag.getBoolean("Stuck"));
    if (tag.contains("StuckPos")) stuckPos = BlockPos.of(tag.getLong("StuckPos"));
    else if (isStuck()) stuckPos = BlockPos.containing(position().add(getStuckDir().scale(0.1)));
  }
}
