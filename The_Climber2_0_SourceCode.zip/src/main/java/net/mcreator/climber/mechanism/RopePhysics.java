package net.mcreator.climber.mechanism;

import java.util.*;
import java.util.function.BiFunction;
import net.minecraft.nbt.*;
import net.minecraft.world.phys.Vec3;

/** Fixed-step, substepped Verlet rope; velocity is stored per substep, forces per game tick. */
public final class RopePhysics {
  private static final int SUBSTEPS = 4, ITERATIONS = 24;
  private static final double DT = 1.0 / SUBSTEPS;
  private final List<Vec3> nodes = new ArrayList<>(), previous = new ArrayList<>();
  private final double segment, totalLength;
  private Vec3 acceleration = Vec3.ZERO;

  public RopePhysics(Vec3 anchor, double length) {
    int count = Math.max(4, Math.min(48, (int) Math.ceil(length / .4)));
    totalLength = length;
    segment = length / count;
    for (int i = 0; i <= count; i++) {
      Vec3 p = anchor.add(0, -segment * i, 0);
      nodes.add(p);
      previous.add(p);
    }
  }

  public List<Vec3> points() {
    return List.copyOf(nodes);
  }

  public Vec3 end() {
    return nodes.get(nodes.size() - 1);
  }

  public Vec3 velocity() {
    int n = nodes.size() - 1;
    return nodes.get(n).subtract(previous.get(n)).scale(SUBSTEPS);
  }

  /** Spread momentum across the lower rope instead of snapping one isolated node. */
  public void impulse(Vec3 delta) {
    delta = limit(delta, .9);
    for (int i = 1; i < nodes.size(); i++) {
      double w = (double) i / (nodes.size() - 1);
      previous.set(i, previous.get(i).subtract(delta.scale(DT * w * w)));
    }
  }

  public void accelerate(Vec3 force) {
    acceleration = limit(force, .65);
  }

  public void step(Vec3 anchor, BiFunction<Vec3, Vec3, Vec3> collision) {
    for (int sub = 0; sub < SUBSTEPS; sub++) {
      nodes.set(0, anchor);
      previous.set(0, anchor);
      for (int i = 1; i < nodes.size(); i++) {
        Vec3 old = nodes.get(i),
            velocity = limit(old.subtract(previous.get(i)), 1.2 * DT).scale(.999);
        double w = (double) i / (nodes.size() - 1);
        Vec3 force = new Vec3(0, -.04, 0).add(acceleration.scale(w * w));
        Vec3 candidate = old.add(velocity).add(force.scale(DT * DT));
        nodes.set(i, collision.apply(old, candidate));
        previous.set(i, old);
      }
      // Alternate sweeps avoid a one-directional correction wave / visible kinks.
      for (int iteration = 0; iteration < ITERATIONS; iteration++) {
        if ((iteration & 1) == 0) for (int i = 1; i < nodes.size(); i++) constrain(i);
        else for (int i = nodes.size() - 1; i >= 1; i--) constrain(i);
        nodes.set(0, anchor);
      }
      for (int i = 1; i < nodes.size(); i++) {
        Vec3 candidate = nodes.get(i);
        Vec3 resolved = collision.apply(previous.get(i), candidate);
        if (resolved.distanceToSqr(candidate) > 1e-10) {
          // Collision removes only inward motion; do not inject a second bounce next substep.
          Vec3 v = resolved.subtract(previous.get(i));
          previous.set(i, resolved.subtract(v.scale(.25)));
        }
        nodes.set(i, resolved);
      }
    }
    acceleration = Vec3.ZERO;
  }

  private void constrain(int i) {
    Vec3 a = nodes.get(i - 1), b = nodes.get(i), d = b.subtract(a);
    double length = d.length();
    if (length < 1e-9) return;
    Vec3 c = d.scale((length - segment) / length);
    if (i == 1) nodes.set(i, b.subtract(c));
    else {
      nodes.set(i - 1, a.add(c.scale(.5)));
      nodes.set(i, b.subtract(c.scale(.5)));
    }
  }

  private static Vec3 limit(Vec3 v, double max) {
    return v.lengthSqr() > max * max ? v.normalize().scale(max) : v;
  }

  public CompoundTag save() {
    CompoundTag t = new CompoundTag();
    ListTag points = new ListTag(), old = new ListTag();
    for (int i = 0; i < nodes.size(); i++) {
      points.add(vector(nodes.get(i)));
      old.add(vector(previous.get(i)));
    }
    t.put("points", points);
    t.put("previous", old);
    t.putInt("solver", 2);
    return t;
  }

  public static List<Vec3> readPoints(CompoundTag tag) {
    ListTag p = tag.getList("points", Tag.TAG_COMPOUND);
    if (p.size() > 49) throw new IllegalArgumentException("Rope node limit");
    List<Vec3> result = new ArrayList<>();
    for (int i = 0; i < p.size(); i++) {
      Vec3 v = vec(p.getCompound(i));
      if (!Double.isFinite(v.lengthSqr())) throw new IllegalArgumentException("Rope point");
      result.add(v);
    }
    return List.copyOf(result);
  }

  public void restore(CompoundTag tag, Vec3 anchor) {
    var p = readPoints(tag);
    var old = tag.getList("previous", Tag.TAG_COMPOUND);
    if (p.size() != nodes.size() || old.size() != nodes.size()) return;
    for (int i = 0; i < nodes.size(); i++)
      if (p.get(i).distanceTo(anchor) > totalLength + 2
          || !Double.isFinite(vec(old.getCompound(i)).lengthSqr())) return;
    for (int i = 0; i < nodes.size(); i++) {
      nodes.set(i, p.get(i));
      Vec3 before = vec(old.getCompound(i));
      previous.set(
          i,
          tag.getInt("solver") == 2
              ? before
              : p.get(i).subtract(p.get(i).subtract(before).scale(DT)));
    }
    nodes.set(0, anchor);
    previous.set(0, anchor);
  }

  private static Vec3 vec(CompoundTag t) {
    var q = t.getCompound("v");
    return new Vec3(q.getDouble("x"), q.getDouble("y"), q.getDouble("z"));
  }

  private static CompoundTag vector(Vec3 v) {
    CompoundTag t = new CompoundTag(), q = new CompoundTag();
    q.putDouble("x", v.x);
    q.putDouble("y", v.y);
    q.putDouble("z", v.z);
    t.put("v", q);
    return t;
  }
}
