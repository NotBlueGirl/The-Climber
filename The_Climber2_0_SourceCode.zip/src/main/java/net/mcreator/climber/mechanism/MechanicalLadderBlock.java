package net.mcreator.climber.mechanism;

import net.minecraft.core.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.phys.shapes.*;

/** Two half-depth layers share one block; connected front layers deploy below the fixed column. */
public class MechanicalLadderBlock extends LadderBlock implements EntityBlock {
  public static final BooleanProperty EXTENSION = BooleanProperty.create("extension");
  public static final BooleanProperty DEPLOYED = BooleanProperty.create("deployed");
  public static final IntegerProperty LAYERS = IntegerProperty.create("layers", 1, 2);

  public MechanicalLadderBlock(Properties p) {
    super(p);
    registerDefaultState(
        stateDefinition
            .any()
            .setValue(FACING, Direction.NORTH)
            .setValue(WATERLOGGED, false)
            .setValue(EXTENSION, false)
            .setValue(DEPLOYED, false)
            .setValue(LAYERS, 1));
  }

  @Override
  protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
    super.createBlockStateDefinition(b);
    b.add(EXTENSION, DEPLOYED, LAYERS);
  }

  @Override
  public boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
    return s.getValue(EXTENSION) || super.canSurvive(s, l, p);
  }

  @Override
  public boolean canBeReplaced(BlockState s, BlockPlaceContext c) {
    return !c.isSecondaryUseActive()
        && c.getItemInHand().is(asItem())
        && !s.getValue(EXTENSION)
        && !s.getValue(DEPLOYED)
        && s.getValue(LAYERS) == 1;
  }

  @Override
  public BlockState getStateForPlacement(BlockPlaceContext c) {
    var s = c.getLevel().getBlockState(c.getClickedPos());
    if (s.is(this)) return canBeReplaced(s, c) ? s.setValue(LAYERS, 2) : null;
    return super.getStateForPlacement(c);
  }

  public static boolean addLayer(Level level, BlockPos pos) {
    var s = level.getBlockState(pos);
    if (!(s.getBlock() instanceof MechanicalLadderBlock)
        || s.getValue(EXTENSION)
        || s.getValue(DEPLOYED)
        || s.getValue(LAYERS) != 1) return false;
    level.setBlockAndUpdate(pos, s.setValue(LAYERS, 2));
    if (level instanceof ServerLevel sl) MechanismCatalog.ladder(sl, pos);
    return true;
  }

  @Override
  public VoxelShape getShape(BlockState s, BlockGetter level, BlockPos pos, CollisionContext c) {
    if (s.getValue(LAYERS) == 2) return Shapes.block();
    boolean front = s.getValue(EXTENSION);
    return switch (s.getValue(FACING)) {
      case NORTH -> box(0, 0, front ? 0 : 8, 16, 16, front ? 8 : 16);
      case SOUTH -> box(0, 0, front ? 8 : 0, 16, 16, front ? 16 : 8);
      case WEST -> box(front ? 0 : 8, 0, 0, front ? 8 : 16, 16, 16);
      case EAST -> box(front ? 8 : 0, 0, 0, front ? 16 : 8, 16, 16);
      default -> Shapes.empty();
    };
  }

  @Override
  public VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
    if (c instanceof EntityCollisionContext ec
        && ec.getEntity() instanceof net.minecraft.world.entity.projectile.Projectile)
      return getShape(s, l, p, c);
    // Collide with the side rails, not a full solid cube: the player must be able
    // to enter the middle of both layers for vanilla/Forge ladder climbing.
    var shape = getShape(s, l, p, c);
    var rails =
        s.getValue(FACING).getAxis() == Direction.Axis.Z
            ? Shapes.or(box(0, 0, 0, 2, 16, 16), box(14, 0, 0, 16, 16, 16))
            : Shapes.or(box(0, 0, 0, 16, 16, 2), box(0, 0, 14, 16, 16, 16));
    return Shapes.join(shape, rails, BooleanOp.AND);
  }

  @Override
  public BlockEntity newBlockEntity(BlockPos p, BlockState s) {
    return new MechanicalLadderBlockEntity(p, s);
  }

  @Override
  public <T extends BlockEntity> BlockEntityTicker<T> getTicker(
      Level l, BlockState s, BlockEntityType<T> t) {
    return l.isClientSide
        ? null
        : (world, pos, state, be) -> {
          if (be instanceof MechanicalLadderBlockEntity ladder) ladder.tick();
        };
  }

  @Override
  public void onRemove(BlockState s, Level l, BlockPos p, BlockState next, boolean moving) {
    if (!s.is(next.getBlock()) && l instanceof ServerLevel sl)
      MechanismCatalog.get(sl.getServer()).remove(MechanismCatalog.ladderId(sl, p));
    super.onRemove(s, l, p, next, moving);
  }

  public static BlockPos root(Level l, BlockPos pos) {
    if (l.getBlockEntity(pos) instanceof MechanicalLadderBlockEntity be && be.owner() != null)
      return be.owner();
    return pos;
  }

  public static void hit(Level l, BlockPos p) {
    if (l.getBlockEntity(root(l, p)) instanceof MechanicalLadderBlockEntity be) be.deploy();
  }
}
