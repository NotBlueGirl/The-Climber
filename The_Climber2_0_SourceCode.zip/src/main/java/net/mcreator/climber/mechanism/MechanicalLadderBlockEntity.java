package net.mcreator.climber.mechanism;

import java.util.*;
import net.mcreator.climber.init.ClimberModBlocks;
import net.minecraft.core.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** One controller owns a contiguous front chain; the fixed back halves never move. */
public class MechanicalLadderBlockEntity extends BlockEntity {
  public static final int MAX_CHAIN = 32;
  private BlockPos owner;
  private int chainLength;
  private boolean busy;

  public MechanicalLadderBlockEntity(BlockPos p, BlockState s) {
    super(ClimberModBlocks.LADDER_ENTITY.get(), p, s);
  }

  public BlockPos owner() {
    return owner;
  }

  @Override
  public void onLoad() {
    super.onLoad();
    if (level instanceof ServerLevel sl) MechanismCatalog.ladder(sl, worldPosition);
  }

  private boolean paired(BlockPos p, Direction facing) {
    if (!level.hasChunkAt(p)) return false;
    var s = level.getBlockState(p);
    return s.getBlock() instanceof MechanicalLadderBlock
        && s.getValue(LadderBlock.FACING) == facing
        && !s.getValue(MechanicalLadderBlock.EXTENSION)
        && !s.getValue(MechanicalLadderBlock.DEPLOYED)
        && s.getValue(MechanicalLadderBlock.LAYERS) == 2;
  }

  public void deploy() {
    if (level == null || level.isClientSide || busy) return;
    var s = getBlockState();
    if (s.getValue(MechanicalLadderBlock.EXTENSION)
        || s.getValue(MechanicalLadderBlock.DEPLOYED)
        || s.getValue(MechanicalLadderBlock.LAYERS) != 2) return;
    var face = s.getValue(LadderBlock.FACING);
    BlockPos top = worldPosition;
    int count = 1;
    while (paired(top.above(), face)) {
      if (++count > MAX_CHAIN) return;
      top = top.above();
    }
    BlockPos bottom = worldPosition;
    while (paired(bottom.below(), face)) {
      if (++count > MAX_CHAIN) return;
      bottom = bottom.below();
    }
    int n = top.getY() - bottom.getY() + 1;
    // Every destination is below the back column. Validate the entire move before changing
    // anything.
    for (int i = 0; i < n; i++) {
      BlockPos base = top.below(i), dest = base.below(n);
      if (level.hasNeighborSignal(base)
          || dest.getY() < level.getMinBuildHeight()
          || !level.hasChunkAt(dest)
          || !level.getBlockState(dest).isAir()) return;
    }
    if (!(level.getBlockEntity(top) instanceof MechanicalLadderBlockEntity root)) return;
    root.busy = true;
    for (int i = 0; i < n; i++) {
      BlockPos base = top.below(i), dest = base.below(n);
      var state = level.getBlockState(base);
      level.setBlockAndUpdate(
          base,
          state
              .setValue(MechanicalLadderBlock.LAYERS, 1)
              .setValue(MechanicalLadderBlock.DEPLOYED, true));
      var b = (MechanicalLadderBlockEntity) level.getBlockEntity(base);
      b.owner = i == 0 ? null : top.immutable();
      b.chainLength = i == 0 ? n : 0;
      b.setChanged();
      level.setBlockAndUpdate(
          dest,
          state
              .setValue(MechanicalLadderBlock.LAYERS, 1)
              .setValue(MechanicalLadderBlock.EXTENSION, true)
              .setValue(MechanicalLadderBlock.DEPLOYED, false)
              .setValue(LadderBlock.WATERLOGGED, false));
      var child = (MechanicalLadderBlockEntity) level.getBlockEntity(dest);
      child.owner = top.immutable();
      child.setChanged();
    }
    root.busy = false;
    root.sound(.7f);
  }

  private boolean owns(BlockPos p) {
    return level.getBlockEntity(p) instanceof MechanicalLadderBlockEntity child
        && worldPosition.equals(child.owner)
        && child.getBlockState().getValue(MechanicalLadderBlock.EXTENSION);
  }

  public void retract() {
    if (level == null || level.isClientSide || busy) return;
    if (owner != null) {
      if (level.getBlockEntity(owner) instanceof MechanicalLadderBlockEntity root) root.retract();
      return;
    }
    int n = chainLength;
    // 1.4.1 single-pair saves already contain the child's owner, but no length.
    if (n == 0 && getBlockState().getValue(MechanicalLadderBlock.DEPLOYED)) n = 1;
    if (n < 1) return;
    for (int i = 0; i < 2 * n; i++) if (!level.hasChunkAt(worldPosition.below(i))) return;
    busy = true;
    for (int i = 0; i < n; i++) {
      BlockPos base = worldPosition.below(i), dest = base.below(n);
      boolean present = owns(dest);
      if (present) level.removeBlock(dest, false);
      if (level.getBlockEntity(base) instanceof MechanicalLadderBlockEntity b
          && !b.getBlockState().getValue(MechanicalLadderBlock.EXTENSION)
          && (i == 0 || worldPosition.equals(b.owner))) {
        level.setBlockAndUpdate(
            base,
            b.getBlockState()
                .setValue(MechanicalLadderBlock.LAYERS, present ? 2 : 1)
                .setValue(MechanicalLadderBlock.DEPLOYED, false));
        b.owner = null;
        b.chainLength = 0;
        b.setChanged();
      } // Missing/mined front pieces are never recreated.
    }
    chainLength = 0;
    setChanged();
    busy = false;
    sound(1.3f);
  }

  public void tick() {
    if (level == null || busy) return;
    if (!getBlockState().getValue(MechanicalLadderBlock.EXTENSION)
        && level.getGameTime() % 20 == 0
        && level instanceof ServerLevel sl) MechanismCatalog.ladder(sl, worldPosition);
    if (level.hasNeighborSignal(worldPosition)
        && (owner != null || getBlockState().getValue(MechanicalLadderBlock.DEPLOYED))) retract();
  }

  private void sound(float pitch) {
    level.playSound(
        null,
        worldPosition,
        net.minecraft.sounds.SoundEvents.CHAIN_PLACE,
        net.minecraft.sounds.SoundSource.BLOCKS,
        1,
        pitch);
  }

  @Override
  protected void saveAdditional(CompoundTag t) {
    super.saveAdditional(t);
    if (owner != null) t.putLong("owner", owner.asLong());
    t.putInt("chainLength", chainLength);
  }

  @Override
  public void load(CompoundTag t) {
    super.load(t);
    owner = t.contains("owner") ? BlockPos.of(t.getLong("owner")) : null;
    chainLength = Math.max(0, Math.min(MAX_CHAIN, t.getInt("chainLength")));
  }
}
