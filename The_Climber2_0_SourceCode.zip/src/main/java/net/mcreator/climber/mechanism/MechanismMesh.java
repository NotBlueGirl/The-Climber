package net.mcreator.climber.mechanism;

import com.google.gson.*;
import java.io.Reader;
import java.util.*;

/** Small immutable, side-independent mesh format. Model units are Minecraft blocks. */
public record MechanismMesh(String name, List<Face> faces) {
  public record Face(String part, float[][] positions, float[][] uv, float[] normal) {}

  public static MechanismMesh read(Reader reader) {
    JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
    if (root.get("format_version").getAsInt() != 1)
      throw new IllegalArgumentException("Mesh version");
    List<Face> faces = new ArrayList<>();
    for (JsonElement element : root.getAsJsonArray("faces")) {
      JsonObject f = element.getAsJsonObject();
      float[][] p = matrix(f.getAsJsonArray("positions"), 3);
      float[][] uv = matrix(f.getAsJsonArray("uv"), 2);
      if ((p.length != 3 && p.length != 4) || uv.length != p.length)
        throw new IllegalArgumentException("Only triangles and quads supported");
      float[] n = vector(f.getAsJsonArray("normal"), 3);
      double length = n[0] * n[0] + n[1] * n[1] + n[2] * n[2];
      if (Math.abs(length - 1) > .001) throw new IllegalArgumentException("Non-unit normal");
      for (float[] v : uv)
        for (float a : v) if (a < 0 || a > 1) throw new IllegalArgumentException("UV range");
      double[] a = new double[3], b = new double[3];
      for (int i = 0; i < 3; i++) {
        a[i] = p[1][i] - p[0][i];
        b[i] = p[2][i] - p[0][i];
      }
      double area =
          Math.pow(a[1] * b[2] - a[2] * b[1], 2)
              + Math.pow(a[2] * b[0] - a[0] * b[2], 2)
              + Math.pow(a[0] * b[1] - a[1] * b[0], 2);
      if (area < 1e-18) throw new IllegalArgumentException("Degenerate face");
      faces.add(new Face(f.get("part").getAsString(), p, uv, n));
    }
    if (faces.isEmpty()) throw new IllegalArgumentException("Empty mesh");
    return new MechanismMesh(root.get("name").getAsString(), List.copyOf(faces));
  }

  private static float[][] matrix(JsonArray a, int columns) {
    float[][] result = new float[a.size()][];
    for (int i = 0; i < a.size(); i++) result[i] = vector(a.get(i).getAsJsonArray(), columns);
    return result;
  }

  private static float[] vector(JsonArray a, int count) {
    if (a.size() != count) throw new IllegalArgumentException("Vector size");
    float[] result = new float[count];
    for (int i = 0; i < count; i++) {
      result[i] = a.get(i).getAsFloat();
      if (!Float.isFinite(result[i])) throw new IllegalArgumentException("Non-finite coordinate");
    }
    return result;
  }
}
