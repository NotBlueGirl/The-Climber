package net.mcreator.climber.mechanism;

import java.util.*;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

/** World-fixed, wall-local rail coordinates. Never depend on interpolated vehicle position. */
public final class PlatformRails {
  private PlatformRails() {}

  public static List<List<Vec3>> tracks(Vec3 origin, Direction face, List<Vec3> route) {
    Vec3 normal = new Vec3(face.getStepX(), 0, face.getStepZ()),
        side = new Vec3(normal.z, 0, -normal.x);
    double vertical = 0, horizontal = 0;
    for (int i = 1; i < route.size(); i++) {
      var d = route.get(i).subtract(route.get(i - 1));
      vertical += Math.abs(d.y);
      horizontal += Math.abs(d.dot(side));
    }
    Vec3 across = vertical >= horizontal ? side.scale(.85) : new Vec3(0, .65, 0);
    Vec3 center = origin.add(0, 1, 0).subtract(normal.scale(.12));
    var result = new ArrayList<List<Vec3>>();
    for (int sign : new int[] {-1, 1}) {
      var track = new ArrayList<Vec3>();
      for (var p : route) track.add(center.add(p).add(across.scale(sign)));
      result.add(List.copyOf(track));
    }
    return List.copyOf(result);
  }
}
