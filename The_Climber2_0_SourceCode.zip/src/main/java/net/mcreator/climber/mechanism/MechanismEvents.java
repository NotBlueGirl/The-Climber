package net.mcreator.climber.mechanism;

import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class MechanismEvents {
  @SubscribeEvent
  public void joined(net.minecraftforge.event.entity.EntityJoinLevelEvent event) {
    if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel level
        && event.getEntity() instanceof MechanismEntity e)
      MechanismCatalog.get(level.getServer()).track(e);
  }

  @SubscribeEvent
  public void left(net.minecraftforge.event.entity.EntityLeaveLevelEvent event) {
    if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel level
        && event.getEntity() instanceof MechanismEntity e
        && e.getRemovalReason() != null) {
      if (!e.getRemovalReason().shouldSave())
        MechanismCatalog.get(level.getServer()).remove("entity:" + e.getUUID());
      else MechanismCatalog.get(level.getServer()).track(e);
    }
  }

  @SubscribeEvent
  public void impact(ProjectileImpactEvent e) {
    if (!e.getEntity().level().isClientSide()
        && e.getRayTraceResult() instanceof BlockHitResult b
        && e.getEntity().level().getBlockState(b.getBlockPos()).getBlock()
            instanceof MechanicalLadderBlock)
      MechanicalLadderBlock.hit(e.getEntity().level(), b.getBlockPos());
  }
}
