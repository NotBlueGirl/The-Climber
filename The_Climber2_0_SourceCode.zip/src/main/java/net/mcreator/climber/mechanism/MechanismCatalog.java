package net.mcreator.climber.mechanism;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Persistent world-wide authoring index. Unloading a chunk does not remove its records. */
public final class MechanismCatalog extends SavedData {
  public record Entry(String id, String dimension, String kind, BlockPos pos) {
    public CompoundTag save() {
      CompoundTag t = new CompoundTag();
      t.putString("id", id);
      t.putString("dimension", dimension);
      t.putString("kind", kind);
      t.putLong("pos", pos.asLong());
      return t;
    }

    public static Entry load(CompoundTag t) {
      return new Entry(
          t.getString("id"),
          t.getString("dimension"),
          t.getString("kind"),
          BlockPos.of(t.getLong("pos")));
    }
  }

  private final Map<String, Entry> entries = new HashMap<>();

  public static MechanismCatalog get(MinecraftServer server) {
    return server
        .overworld()
        .getDataStorage()
        .computeIfAbsent(MechanismCatalog::load, MechanismCatalog::new, "climber_mechanisms");
  }

  public static MechanismCatalog load(CompoundTag tag) {
    var c = new MechanismCatalog();
    var rows = tag.getList("objects", Tag.TAG_COMPOUND);
    for (int i = 0; i < rows.size(); i++) {
      var e = Entry.load(rows.getCompound(i));
      c.entries.put(e.id(), e);
    }
    return c;
  }

  @Override
  public CompoundTag save(CompoundTag tag) {
    ListTag rows = new ListTag();
    entries.values().forEach(e -> rows.add(e.save()));
    tag.put("objects", rows);
    return tag;
  }

  public void put(Entry e) {
    if (!e.equals(entries.put(e.id(), e))) setDirty();
  }

  public void remove(String id) {
    if (entries.remove(id) != null) setDirty();
  }

  public List<Entry> query(String filter) {
    String q = filter.toLowerCase(Locale.ROOT);
    return entries.values().stream()
        .filter(
            e ->
                (e.kind() + " " + e.dimension() + " " + e.pos().toShortString() + " " + e.id())
                    .toLowerCase(Locale.ROOT)
                    .contains(q))
        .sorted(
            Comparator.comparing(Entry::kind)
                .thenComparing(Entry::dimension)
                .thenComparing(Entry::id))
        .toList();
  }

  public void track(MechanismEntity e) {
    if (e.level() instanceof ServerLevel level && !e.isChild())
      put(
          new Entry(
              "entity:" + e.getUUID(),
              level.dimension().location().toString(),
              e.spec().kind.name(),
              e.blockPosition()));
  }

  public static String ladderId(ServerLevel level, BlockPos pos) {
    return "ladder:" + level.dimension().location() + ":" + pos.asLong();
  }

  public static void ladder(ServerLevel level, BlockPos pos) {
    var catalog = get(level.getServer());
    var state = level.getBlockState(pos);
    if (state.getBlock() instanceof MechanicalLadderBlock
        && !state.getValue(MechanicalLadderBlock.EXTENSION))
      catalog.put(
          new Entry(
              ladderId(level, pos),
              level.dimension().location().toString(),
              "LADDER",
              pos.immutable()));
    else catalog.remove(ladderId(level, pos));
  }
}
