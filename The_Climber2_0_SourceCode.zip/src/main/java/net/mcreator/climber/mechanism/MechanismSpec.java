package net.mcreator.climber.mechanism;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import net.minecraft.world.phys.Vec3;

/** Bounded, shared authoring model. Coordinates in path are offsets from the placement point. */
public final class MechanismSpec {
  public enum Kind {
    VALVE,
    ROPE,
    PLATFORM,
    HOOK,
    WEAK_HOOK,
    LADDER
  }

  public Kind kind = Kind.HOOK;
  public double ropeLength = 6,
      weakSeconds = 3,
      valveStep = 1,
      valveMax = 10,
      roundTripSeconds = 10;
  public int repeats = 0;
  public boolean redstone = false, trigger = false;
  public String action = "OPEN";
  public boolean curved = false;
  public BlockPos valveTarget;
  public List<BlockPos> railBlocks = new ArrayList<>();
  private List<Vec3> cachedRoute;
  private int routeKey;

  /** Catmull-Rom passes through selected control points; shared arc table for renderer/server. */
  public List<Vec3> route() {
    int key = 31 * path.hashCode() + Boolean.hashCode(curved);
    if (cachedRoute != null && routeKey == key) return cachedRoute;
    List<Vec3> result = new ArrayList<>();
    if (!curved || path.size() < 3) result.addAll(path);
    else {
      result.add(path.get(0));
      for (int i = 0; i < path.size() - 1; i++) {
        Vec3 p0 = path.get(Math.max(0, i - 1)),
            p1 = path.get(i),
            p2 = path.get(i + 1),
            p3 = path.get(Math.min(path.size() - 1, i + 2));
        for (int j = 1; j <= 12; j++) {
          double t = j / 12.0, t2 = t * t, t3 = t2 * t;
          Vec3 v =
              p1.scale(2)
                  .add(p2.subtract(p0).scale(t))
                  .add(p0.scale(2).subtract(p1.scale(5)).add(p2.scale(4)).subtract(p3).scale(t2))
                  .add(p0.scale(-1).add(p1.scale(3)).subtract(p2.scale(3)).add(p3).scale(t3))
                  .scale(.5);
          // Keep each curve segment inside the selected blocks' coordinate bounds.
          v =
              new Vec3(
                  Math.max(Math.min(p1.x, p2.x), Math.min(Math.max(p1.x, p2.x), v.x)),
                  Math.max(Math.min(p1.y, p2.y), Math.min(Math.max(p1.y, p2.y), v.y)),
                  Math.max(Math.min(p1.z, p2.z), Math.min(Math.max(p1.z, p2.z), v.z)));
          if (v.distanceToSqr(result.get(result.size() - 1)) > 1e-12) result.add(v);
        }
      }
    }
    routeKey = key;
    cachedRoute = List.copyOf(result);
    return cachedRoute;
  }

  public double routeLength() {
    double n = 0;
    var r = route();
    for (int i = 1; i < r.size(); i++) n += r.get(i).distanceTo(r.get(i - 1));
    return n;
  }

  public void selectRailBlocks(List<BlockPos> blocks) {
    if (blocks.size() < 2 || blocks.size() > 32)
      throw new IllegalArgumentException("Select 2..32 rail blocks");
    railBlocks = new ArrayList<>(blocks);
    path = new ArrayList<>();
    Vec3 first = Vec3.atCenterOf(blocks.get(0));
    for (BlockPos b : blocks) path.add(Vec3.atCenterOf(b).subtract(first));
  }

  public List<Vec3> path = new ArrayList<>(List.of(Vec3.ZERO, new Vec3(0, 3, 0)));

  public void validate() {
    range(ropeLength, .5, 32, "Rope length");
    range(weakSeconds, .1, 600, "Weak-hook lifetime");
    range(valveStep, .01, 100000, "Valve increment");
    range(valveMax, .01, 1000000, "Valve maximum");
    range(roundTripSeconds, 1, 3600, "Round-trip duration");
    if (repeats < 0 || repeats > 100000)
      throw new IllegalArgumentException("Repeat count must be 0..100000 (0 = continuous)");
    if (!Set.of("OPEN", "CLOSE", "TOGGLE", "PULSE").contains(action))
      throw new IllegalArgumentException("Unknown valve action");
    if (path.size() < 2 || path.size() > 32)
      throw new IllegalArgumentException("Path needs 2..32 points");
    if (path.get(0).lengthSqr() > .000001)
      throw new IllegalArgumentException("First path point must be 0,0,0");
    for (Vec3 p : path) {
      range(p.x, -64, 64, "Path X");
      range(p.y, -64, 64, "Path Y");
      range(p.z, -64, 64, "Path Z");
    }
    if (railBlocks.size() > 32) throw new IllegalArgumentException("Too many rail blocks");
    if (!railBlocks.isEmpty()) {
      if (railBlocks.size() != path.size())
        throw new IllegalArgumentException("Rail blocks and path differ");
      for (int i = 0; i < path.size(); i++)
        if (Vec3.atCenterOf(railBlocks.get(i))
                .subtract(Vec3.atCenterOf(railBlocks.get(0)))
                .distanceToSqr(path.get(i))
            > 1e-8) throw new IllegalArgumentException("Rail route mismatch");
    }
    double distance = 0;
    for (int i = 1; i < path.size(); i++) {
      double d = path.get(i).distanceTo(path.get(i - 1));
      if (d < .01) throw new IllegalArgumentException("Adjacent path points must differ");
      distance += d;
    }
    if (kind == Kind.PLATFORM && routeLength() > roundTripSeconds * 5 + .000001)
      throw new IllegalArgumentException(
          "Increase round-trip time: rail speed must not exceed 0.5 blocks/tick");
  }

  static void range(double n, double min, double max, String label) {
    if (!Double.isFinite(n) || n < min || n > max)
      throw new IllegalArgumentException(label + " must be " + min + ".." + max);
  }

  public CompoundTag save() {
    CompoundTag t = new CompoundTag();
    t.putString("kind", kind.name());
    t.putDouble("ropeLength", ropeLength);
    t.putDouble("weakSeconds", weakSeconds);
    t.putDouble("valveStep", valveStep);
    t.putDouble("valveMax", valveMax);
    t.putDouble("roundTripSeconds", roundTripSeconds);
    t.putInt("repeats", repeats);
    t.putBoolean("redstone", redstone);
    t.putBoolean("trigger", trigger);
    t.putString("action", action);
    t.putBoolean("curved", curved);
    if (valveTarget != null) t.putLong("valveTarget", valveTarget.asLong());
    long[] blocks = new long[railBlocks.size()];
    for (int i = 0; i < blocks.length; i++) blocks[i] = railBlocks.get(i).asLong();
    t.putLongArray("railBlocks", blocks);
    ListTag a = new ListTag();
    for (Vec3 p : path) {
      CompoundTag q = new CompoundTag();
      q.putDouble("x", p.x);
      q.putDouble("y", p.y);
      q.putDouble("z", p.z);
      a.add(q);
    }
    t.put("path", a);
    return t;
  }

  public static MechanismSpec load(CompoundTag t) {
    MechanismSpec s = new MechanismSpec();
    if (t.isEmpty()) return s;
    s.kind = Kind.valueOf(t.getString("kind"));
    s.ropeLength = t.getDouble("ropeLength");
    s.weakSeconds = t.getDouble("weakSeconds");
    s.valveStep = t.getDouble("valveStep");
    s.valveMax = t.getDouble("valveMax");
    s.roundTripSeconds = t.getDouble("roundTripSeconds");
    s.repeats = t.getInt("repeats");
    s.redstone = t.getBoolean("redstone");
    s.trigger = t.getBoolean("trigger");
    s.action = t.getString("action");
    s.curved = t.getBoolean("curved");
    if (t.contains("valveTarget")) s.valveTarget = BlockPos.of(t.getLong("valveTarget"));
    long[] selected = t.getLongArray("railBlocks");
    if (selected.length > 32) throw new IllegalArgumentException("Too many rail blocks");
    for (long b : selected) s.railBlocks.add(BlockPos.of(b));
    s.path.clear();
    ListTag a = t.getList("path", Tag.TAG_COMPOUND);
    if (a.size() > 32) throw new IllegalArgumentException("Too many path points");
    for (int i = 0; i < a.size(); i++) {
      CompoundTag p = a.getCompound(i);
      s.path.add(new Vec3(p.getDouble("x"), p.getDouble("y"), p.getDouble("z")));
    }
    s.validate();
    return s;
  }

  public String pathText() {
    List<String> a = new ArrayList<>();
    for (Vec3 p : path) a.add(p.x + "," + p.y + "," + p.z);
    return String.join("; ", a);
  }

  public void setPath(String text) {
    if (text.length() > 4096) throw new IllegalArgumentException("Path text too long");
    List<Vec3> p = new ArrayList<>();
    for (String q : text.split(";")) {
      String[] v = q.trim().split("\\s*,\\s*");
      if (v.length != 3) throw new IllegalArgumentException("Use x,y,z; x,y,z offsets");
      p.add(new Vec3(Double.parseDouble(v[0]), Double.parseDouble(v[1]), Double.parseDouble(v[2])));
    }
    path = p;
    railBlocks.clear();
  }

  /** Constant-speed arc-length interpolation; one cycle is out and back. */
  public Vec3 pointAt(double phase) {
    double p = Math.max(0, Math.min(1, phase));
    double t = p < .5 ? p * 2 : (1 - p) * 2;
    List<Vec3> path = route();
    double total = routeLength();
    double at = t * total;
    for (int i = 1; i < path.size(); i++) {
      Vec3 a = path.get(i - 1), b = path.get(i);
      double len = a.distanceTo(b);
      if (at <= len) return a.lerp(b, at / len);
      at -= len;
    }
    return path.get(path.size() - 1);
  }

  public static Vec3 constrain(Vec3 anchor, Vec3 endpoint, double length) {
    Vec3 d = endpoint.subtract(anchor);
    return d.lengthSqr() < 1e-12
        ? anchor.add(0, -length, 0)
        : anchor.add(d.normalize().scale(length));
  }
}
