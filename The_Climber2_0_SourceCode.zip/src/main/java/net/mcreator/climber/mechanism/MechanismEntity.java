package net.mcreator.climber.mechanism;

import java.util.*;
import net.mcreator.climber.entity.HandholdEntity;
import net.mcreator.climber.init.ClimberModEntities;
import net.mcreator.climber.item.DebuggerToolItem;
import net.minecraft.core.*;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.*;
import net.minecraft.world.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.*;

/**
 * Server-owned placeable mechanisms. Syncs authoring data as well as live state to late joiners.
 */
public class MechanismEntity extends Entity implements HandholdEntity {
  private static final EntityDataAccessor<CompoundTag> DATA =
      SynchedEntityData.defineId(MechanismEntity.class, EntityDataSerializers.COMPOUND_TAG);
  private static final EntityDataAccessor<Float> PROGRESS =
      SynchedEntityData.defineId(MechanismEntity.class, EntityDataSerializers.FLOAT);
  private static final EntityDataAccessor<Boolean> RUNNING =
      SynchedEntityData.defineId(MechanismEntity.class, EntityDataSerializers.BOOLEAN);
  private static final EntityDataAccessor<CompoundTag> ROPE_NODES =
      SynchedEntityData.defineId(MechanismEntity.class, EntityDataSerializers.COMPOUND_TAG);
  private RopePhysics rope;
  private List<Vec3> ropeClient = List.of(), ropePrevious = List.of();
  private int ropeSnapshotTick, clientLerpSteps;
  private Vec3 clientTarget = Vec3.ZERO;

  @Override
  public void lerpTo(
      double x, double y, double z, float yaw, float pitch, int steps, boolean teleport) {
    if (!level().isClientSide()) {
      super.lerpTo(x, y, z, yaw, pitch, steps, teleport);
      return;
    }
    clientTarget = new Vec3(x, y, z);
    clientLerpSteps = Math.max(1, Math.min(6, steps));
    setYRot(yaw);
    setXRot(pitch);
  }

  public Vec3 renderPosition(float partial) {
    if (parent != null && level().isClientSide() && clientParent() != null)
      return cachedParent.renderPosition(partial).add(parentOffset);
    return new Vec3(
        net.minecraft.util.Mth.lerp(partial, xo, getX()),
        net.minecraft.util.Mth.lerp(partial, yo, getY()),
        net.minecraft.util.Mth.lerp(partial, zo, getZ()));
  }

  private Vec3 gripMotion = Vec3.ZERO;
  private final Map<UUID, SwingControl> swingControls = new HashMap<>();

  private record SwingControl(Vec3 force, long tick) {}

  private MechanismEntity cachedParent;

  public void swingInput(Player player, Vec3 force) {
    if (!level().isClientSide() && spec.kind == MechanismSpec.Kind.ROPE)
      swingControls.put(player.getUUID(), new SwingControl(force, level().getGameTime()));
  }

  public Vec3 gripVelocity() {
    if (parent != null && level().isClientSide() && clientParent() != null)
      return cachedParent.gripVelocity();
    if (level().isClientSide()
        && spec.kind == MechanismSpec.Kind.ROPE
        && ropeClient.size() > 1
        && ropePrevious.size() == ropeClient.size())
      return ropeClient
          .get(ropeClient.size() - 1)
          .subtract(ropePrevious.get(ropePrevious.size() - 1))
          .scale(.5);
    return level().isClientSide() ? position().subtract(new Vec3(xo, yo, zo)) : gripMotion;
  }

  private MechanismEntity clientParent() {
    if (parent == null) return null;
    if (cachedParent != null && cachedParent.isAlive() && cachedParent.getUUID().equals(parent))
      return cachedParent;
    for (var e :
        level().getEntities(this, getBoundingBox().inflate(8), e -> e instanceof MechanismEntity))
      if (e instanceof MechanismEntity m && m.getUUID().equals(parent)) {
        cachedParent = m;
        return m;
      }
    return null;
  }

  private MechanismSpec spec = new MechanismSpec();
  private BlockPos attached = BlockPos.ZERO;
  private Vec3 origin = Vec3.ZERO, ceiling = Vec3.ZERO, ropeVelocity = Vec3.ZERO;
  private Direction face = Direction.NORTH;
  private UUID parent;
  private Vec3 parentOffset = Vec3.ZERO;
  private int parentMissingTicks;
  private long gripTick = -1, lastUse = -100;
  private int wear = 0, cycleTicks = 0, cycles = 0, pulseTicks = 0;
  private boolean completed = false;
  private List<UUID> children = new ArrayList<>();

  public MechanismEntity(EntityType<? extends MechanismEntity> t, Level l) {
    super(t, l);
    noPhysics = true;
  }

  @Override
  protected void defineSynchedData() {
    entityData.define(DATA, new CompoundTag());
    entityData.define(PROGRESS, 0f);
    entityData.define(RUNNING, false);
    entityData.define(ROPE_NODES, new CompoundTag());
  }

  public MechanismSpec spec() {
    return spec;
  }

  public Direction face() {
    return face;
  }

  public Vec3 origin() {
    return origin;
  }

  public Vec3 ceiling() {
    return ceiling;
  }

  public float progress() {
    return entityData.get(PROGRESS);
  }

  public boolean running() {
    return entityData.get(RUNNING);
  }

  public boolean isChild() {
    return parent != null;
  }

  public static MechanismEntity place(
      Level l, Vec3 hit, Direction f, BlockPos block, MechanismSpec s) {
    MechanismEntity e = new MechanismEntity(ClimberModEntities.MECHANISM.get(), l);
    e.spec = s;
    e.face = f;
    e.attached = block.immutable();
    e.ceiling = hit.add(0, -.05, 0);
    e.origin = hit.add(f.getStepX() * .13, f.getStepY() * .13, f.getStepZ() * .13);
    if (s.kind == MechanismSpec.Kind.PLATFORM)
      e.origin = e.origin.add(f.getStepX() * .1, -1, f.getStepZ() * .1);
    Vec3 p = s.kind == MechanismSpec.Kind.ROPE ? e.ceiling.add(0, -s.ropeLength, 0) : e.origin;
    e.setPos(p);
    e.entityData.set(RUNNING, !s.trigger);
    e.syncData();
    l.addFreshEntity(e);
    if (s.kind == MechanismSpec.Kind.ROPE) {
      e.rope = new RopePhysics(e.ceiling, s.ropeLength);
      e.syncRope();
    }
    if (s.kind == MechanismSpec.Kind.PLATFORM) e.addHooks();
    return e;
  }

  private void syncData() {
    CompoundTag t = new CompoundTag();
    t.put("spec", spec.save());
    t.putInt("face", face.get3DDataValue());
    t.putLong("attached", attached.asLong());
    vec(t, "origin", origin);
    vec(t, "ceiling", ceiling);
    if (parent != null) {
      t.putUUID("parent", parent);
      vec(t, "parentOffset", parentOffset);
    }
    entityData.set(DATA, t);
    refreshDimensions();
  }

  public static void vec(CompoundTag t, String key, Vec3 v) {
    CompoundTag a = new CompoundTag();
    a.putDouble("x", v.x);
    a.putDouble("y", v.y);
    a.putDouble("z", v.z);
    t.put(key, a);
  }

  public static Vec3 vec(CompoundTag t, String key) {
    CompoundTag a = t.getCompound(key);
    return new Vec3(a.getDouble("x"), a.getDouble("y"), a.getDouble("z"));
  }

  @Override
  public void onSyncedDataUpdated(EntityDataAccessor<?> a) {
    super.onSyncedDataUpdated(a);
    if (a.equals(ROPE_NODES) && level().isClientSide()) {
      try {
        var points = RopePhysics.readPoints(entityData.get(ROPE_NODES));
        ropePrevious = ropeClient.size() == points.size() ? ropePoints(0) : points;
        ropeClient = points;
        ropeSnapshotTick = tickCount;
      } catch (RuntimeException ignored) {
      }
    }
    if (a.equals(DATA)) {
      CompoundTag t = entityData.get(DATA);
      if (!t.isEmpty()) {
        try {
          spec = MechanismSpec.load(t.getCompound("spec"));
          face = Direction.from3DDataValue(t.getInt("face"));
          attached = BlockPos.of(t.getLong("attached"));
          origin = vec(t, "origin");
          ceiling = vec(t, "ceiling");
          parent = t.hasUUID("parent") ? t.getUUID("parent") : null;
          parentOffset = vec(t, "parentOffset");
          refreshDimensions();
        } catch (RuntimeException ex) {
          net.mcreator.climber.ClimberMod.LOGGER.warn("Bad mechanism data", ex);
        }
      }
    }
  }

  @Override
  public EntityDimensions getDimensions(Pose p) {
    return spec != null && spec.kind == MechanismSpec.Kind.PLATFORM
        ? EntityDimensions.fixed(3, 2)
        : EntityDimensions.fixed(.55f, .3f);
  }

  @Override
  protected AABB makeBoundingBox() {
    if (spec != null && spec.kind == MechanismSpec.Kind.PLATFORM) {
      return face.getAxis() == Direction.Axis.X
          ? new AABB(getX() - .16, getY(), getZ() - 1.5, getX() + .16, getY() + 2, getZ() + 1.5)
          : new AABB(getX() - 1.5, getY(), getZ() - .16, getX() + 1.5, getY() + 2, getZ() + .16);
    }
    return super.makeBoundingBox();
  }

  private void addHooks() {
    for (double y : new double[] {.5, 1.22}) {
      MechanismEntity h = new MechanismEntity(ClimberModEntities.MECHANISM.get(), level());
      h.spec.kind = MechanismSpec.Kind.HOOK;
      h.parent = getUUID();
      h.face = face;
      h.attached = attached;
      h.parentOffset = new Vec3(face.getStepX() * .2, y, face.getStepZ() * .2);
      h.setPos(position().add(h.parentOffset));
      h.origin = h.position();
      h.syncData();
      level().addFreshEntity(h);
      children.add(h.getUUID());
    }
  }

  public void reconfigure(MechanismSpec s) {
    if (isChild() || s.kind != spec.kind)
      throw new IllegalArgumentException(
          "Type is fixed after placement; place a new object to change it");
    if (pulseTicks > 0) {
      endPulse();
      pulseTicks = 0;
    }
    if (spec.kind == MechanismSpec.Kind.PLATFORM) {
      setPos(origin);
      setDeltaMovement(Vec3.ZERO);
      gripMotion = Vec3.ZERO;
      for (var uuid : children)
        if (level() instanceof net.minecraft.server.level.ServerLevel sl
            && sl.getEntity(uuid) instanceof MechanismEntity child)
          child.setPos(origin.add(child.parentOffset));
    }
    spec = s;
    wear = cycleTicks = cycles = 0;
    completed = false;
    entityData.set(PROGRESS, 0f);
    entityData.set(RUNNING, !s.trigger);
    if (spec.kind == MechanismSpec.Kind.ROPE) {
      rope = new RopePhysics(ceiling, spec.ropeLength);
      setPos(rope.end());
      syncRope();
    }
    syncData();
  }

  public void trigger() {
    if (spec.kind == MechanismSpec.Kind.PLATFORM) {
      completed = false;
      cycles = 0;
      entityData.set(RUNNING, !running());
    }
  }

  @Override
  public Vec3 getGripPoint() {
    if (level().isClientSide() && parent != null && clientParent() != null)
      return cachedParent.position().add(parentOffset).add(0, .15, 0);
    if (level().isClientSide() && spec.kind == MechanismSpec.Kind.ROPE) {
      var points = ropePoints(1);
      if (!points.isEmpty()) return points.get(points.size() - 1).add(0, .15, 0);
    }
    return position().add(0, .15, 0);
  }

  @Override
  public boolean canBeGrabbed() {
    return isAlive()
        && (spec.kind == MechanismSpec.Kind.HOOK
            || spec.kind == MechanismSpec.Kind.WEAK_HOOK
            || spec.kind == MechanismSpec.Kind.ROPE);
  }

  @Override
  public void onGripTick(Player p) {
    if (level().isClientSide()) return;
    if (gripTick == level().getGameTime()) return;
    long previous = gripTick;
    gripTick = level().getGameTime();
    if (spec.kind == MechanismSpec.Kind.WEAK_HOOK) {
      wear++;
      entityData.set(PROGRESS, (float) (wear / (spec.weakSeconds * 20)));
      if (wear >= Math.ceil(spec.weakSeconds * 20)) {
        level()
            .playSound(
                null,
                blockPosition(),
                net.minecraft.sounds.SoundEvents.CHAIN_BREAK,
                net.minecraft.sounds.SoundSource.BLOCKS,
                1,
                1.5f);
        discard();
      }
    }
    if (spec.kind == MechanismSpec.Kind.ROPE) {
      ensureRope();
      if (previous < gripTick - 2) rope.impulse(p.getDeltaMovement().multiply(.85, .25, .85));
    }
  }

  @Override
  public boolean isPickable() {
    return isAlive();
  }

  @Override
  public boolean isPushable() {
    return false;
  }

  @Override
  public boolean canBeCollidedWith() {
    return spec.kind == MechanismSpec.Kind.PLATFORM;
  }

  @Override
  public boolean skipAttackInteraction(Entity by) {
    if (by instanceof Player p
        && p.isCreative()
        && p.isShiftKeyDown()
        && p.getMainHandItem().getItem() instanceof DebuggerToolItem) {
      if (!level().isClientSide() && level().mayInteract(p, attached)) removeWithChildren();
    }
    return true;
  }

  @Override
  public InteractionResult interact(Player p, InteractionHand hand) {
    if (p.getItemInHand(hand).getItem() instanceof DebuggerToolItem) {
      if (p.isCreative() && level().isClientSide())
        DebuggerToolItem.OPEN.accept(authoringRoot().getId());
      return InteractionResult.sidedSuccess(level().isClientSide());
    }
    if (spec.kind == MechanismSpec.Kind.VALVE) {
      if (!level().isClientSide()
          && level().mayInteract(p, attached)
          && level().getGameTime() - lastUse >= 4) {
        lastUse = level().getGameTime();
        float n = (float) Math.min(spec.valveMax, progress() + spec.valveStep);
        entityData.set(PROGRESS, n);
        level()
            .playSound(
                null,
                blockPosition(),
                net.minecraft.sounds.SoundEvents.LEVER_CLICK,
                net.minecraft.sounds.SoundSource.BLOCKS,
                .6f,
                .8f);
        if (n >= spec.valveMax) {
          activate(p);
          entityData.set(PROGRESS, 0f);
        }
      }
      return InteractionResult.sidedSuccess(level().isClientSide());
    }
    if (spec.kind == MechanismSpec.Kind.PLATFORM) {
      if (!level().isClientSide()) trigger();
      return InteractionResult.sidedSuccess(level().isClientSide());
    }
    return InteractionResult.PASS;
  }

  private void activate(Player p) {
    BlockPos target = valveTarget();
    if (!level().hasChunkAt(target) || !level().mayInteract(p, target)) return;
    if (target.distSqr(attached) > 64 * 64) return;
    BlockState b = level().getBlockState(target);
    boolean on = !spec.action.equals("CLOSE");
    if (b.getBlock() instanceof DoorBlock d) {
      if (spec.action.equals("TOGGLE")) on = !b.getValue(DoorBlock.OPEN);
      d.setOpen(p, level(), b, target, on);
    } else if (b.hasProperty(BlockStateProperties.OPEN)) {
      if (spec.action.equals("TOGGLE")) on = !b.getValue(BlockStateProperties.OPEN);
      level().setBlockAndUpdate(target, b.setValue(BlockStateProperties.OPEN, on));
    } else if (b.getBlock() instanceof LeverBlock lever) {
      boolean wanted = spec.action.equals("TOGGLE") ? !b.getValue(LeverBlock.POWERED) : on;
      if (b.getValue(LeverBlock.POWERED) != wanted) lever.pull(b, level(), target);
    } else if (b.getBlock() instanceof ButtonBlock button) button.press(b, level(), target);
    else {
      p.displayClientMessage(
          Component.literal("Valve target needs a door, trapdoor, fence gate, lever or button."),
          true);
      return;
    }
    if (spec.action.equals("PULSE")) pulseTicks = 20;
  }

  private void endPulse() {
    BlockPos target = valveTarget();
    if (!level().hasChunkAt(target)) return;
    BlockState b = level().getBlockState(target);
    if (b.getBlock() instanceof DoorBlock d) d.setOpen(null, level(), b, target, false);
    else if (b.hasProperty(BlockStateProperties.OPEN))
      level().setBlockAndUpdate(target, b.setValue(BlockStateProperties.OPEN, false));
    else if (b.getBlock() instanceof LeverBlock l && b.getValue(LeverBlock.POWERED))
      l.pull(b, level(), target);
  }

  @Override
  public void tick() {
    super.tick();
    if (level().isClientSide()) {
      if (parent != null && clientParent() != null) {
        setPos(cachedParent.position().add(parentOffset));
        return;
      }
      if (clientLerpSteps > 0) {
        setPos(position().lerp(clientTarget, 1.0 / clientLerpSteps));
        clientLerpSteps--;
      }
      return;
    }
    if (parent != null) {
      if (level() instanceof net.minecraft.server.level.ServerLevel sl) {
        Entity e = sl.getEntity(parent);
        if (e != null && e.isAlive()) {
          if (e instanceof MechanismEntity platform
              && platform.spec.kind == MechanismSpec.Kind.PLATFORM
              && parentOffset.y > 1.3) {
            parentOffset = new Vec3(parentOffset.x, 1.22, parentOffset.z);
            syncData();
          }
          Vec3 old = position();
          setPos(e.position().add(parentOffset));
          gripMotion = position().subtract(old);
          origin = e.position();
          if (tickCount % 20 == 0) syncData();
          parentMissingTicks = 0;
        } else if (++parentMissingTicks > 200
            && level().hasChunkAt(BlockPos.containing(origin))
            && level().hasChunkAt(blockPosition())) discard();
      }
      return;
    }
    if (spec.kind == MechanismSpec.Kind.ROPE) {
      ensureRope();
      Vec3 oldEnd = position();
      long now = level().getGameTime();
      swingControls
          .entrySet()
          .removeIf(
              entry ->
                  now - entry.getValue().tick() > 8
                      || !(level() instanceof net.minecraft.server.level.ServerLevel sl)
                      || sl.getPlayerByUUID(entry.getKey()) == null
                      || !isHolding(sl.getPlayerByUUID(entry.getKey())));
      Vec3 force = Vec3.ZERO;
      for (var control : swingControls.values()) force = force.add(control.force());
      rope.accelerate(force);
      rope.step(
          ceiling,
          (old, next) -> {
            var hit =
                level()
                    .clip(
                        new net.minecraft.world.level.ClipContext(
                            old,
                            next,
                            net.minecraft.world.level.ClipContext.Block.COLLIDER,
                            net.minecraft.world.level.ClipContext.Fluid.NONE,
                            this));
            if (hit.getType() != HitResult.Type.MISS)
              return hit.getLocation()
                  .add(Vec3.atLowerCornerOf(hit.getDirection().getNormal()).scale(.035));
            return level()
                    .noCollision(
                        this, new AABB(next.add(-.025, -.025, -.025), next.add(.025, .025, .025)))
                ? next
                : old;
          });
      setPos(rope.end());
      gripMotion = position().subtract(oldEnd);
      if (tickCount % 2 == 0) syncRope();
    }
    if (spec.kind == MechanismSpec.Kind.PLATFORM) gripMotion = Vec3.ZERO;
    if (spec.kind == MechanismSpec.Kind.PLATFORM
        && running()
        && !completed
        && (!spec.redstone || level().hasNeighborSignal(attached))) {
      int ticks = (int) Math.round(spec.roundTripSeconds * 20);
      int nextTick = cycleTicks + 1;
      Vec3 next = origin.add(spec.pointAt(Math.min(1, nextTick / (double) ticks)));
      Vec3 delta = next.subtract(position());
      if (level().hasChunkAt(BlockPos.containing(next))
          && level().noCollision(this, getBoundingBox().move(delta).deflate(.015))) {
        AABB top =
            new AABB(
                getBoundingBox().minX - .05,
                getBoundingBox().maxY - .05,
                getBoundingBox().minZ - .05,
                getBoundingBox().maxX + .05,
                getBoundingBox().maxY + .15,
                getBoundingBox().maxZ + .05);
        List<Entity> riders = level().getEntities(this, top, e -> e instanceof LivingEntity);
        boolean clear = true;
        for (Entity e : riders)
          if (!level().noCollision(e, e.getBoundingBox().move(delta))) clear = false;
        if (clear) {
          setPos(next);
          gripMotion = delta;
          for (Entity e : riders) {
            e.move(MoverType.PISTON, delta);
            e.fallDistance = 0;
            e.hurtMarked = true;
          }
          cycleTicks = nextTick;
          if (cycleTicks >= ticks) {
            cycleTicks = 0;
            cycles++;
            if (spec.repeats > 0 && cycles >= spec.repeats) {
              completed = true;
              entityData.set(RUNNING, false);
            }
          }
        }
      }
    }
    if (tickCount % 20 == 0
        && !isChild()
        && level() instanceof net.minecraft.server.level.ServerLevel sl)
      MechanismCatalog.get(sl.getServer()).track(this);
    if (pulseTicks > 0 && --pulseTicks == 0) endPulse();
    if (tickCount % 20 == 0
        && spec.kind != MechanismSpec.Kind.PLATFORM
        && level().isLoaded(attached)
        && level().getBlockState(attached).isAir()) discard();
  }

  public void removeWithChildren() {
    if (level() instanceof net.minecraft.server.level.ServerLevel sl) {
      for (UUID id : children) {
        Entity e = sl.getEntity(id);
        if (e != null) e.discard();
      }
      for (MechanismEntity e :
          sl.getEntitiesOfClass(MechanismEntity.class, getBoundingBox().inflate(4)))
        if (getUUID().equals(e.parent)) e.discard();
    }
    discard();
  }

  @Override
  public boolean hurt(DamageSource s, float amount) {
    return false;
  }

  @Override
  protected void addAdditionalSaveData(CompoundTag t) {
    ListTag ids = new ListTag();
    for (UUID id : children) ids.add(StringTag.valueOf(id.toString()));
    t.put("children", ids);
    t.put("data", entityData.get(DATA));
    t.putFloat("progress", progress());
    t.putBoolean("running", running());
    t.putInt("wear", wear);
    t.putInt("cycleTicks", cycleTicks);
    t.putInt("cycles", cycles);
    t.putBoolean("completed", completed);
    t.putInt("pulse", pulseTicks);
    vec(t, "velocity", ropeVelocity);
    if (rope != null) t.put("ropePhysics", rope.save());
  }

  @Override
  protected void readAdditionalSaveData(CompoundTag t) {
    try {
      children.clear();
      ListTag ids = t.getList("children", Tag.TAG_STRING);
      for (int i = 0; i < Math.min(2, ids.size()); i++)
        children.add(UUID.fromString(ids.getString(i)));
      CompoundTag d = t.getCompound("data");
      MechanismSpec.load(d.getCompound("spec"));
      entityData.set(DATA, d);
      entityData.set(PROGRESS, t.getFloat("progress"));
      entityData.set(RUNNING, t.getBoolean("running"));
      wear = Math.max(0, t.getInt("wear"));
      cycleTicks = Math.max(0, t.getInt("cycleTicks"));
      cycles = Math.max(0, t.getInt("cycles"));
      completed = t.getBoolean("completed");
      pulseTicks = Math.max(0, Math.min(20, t.getInt("pulse")));
      ropeVelocity = vec(t, "velocity");
      if (!Double.isFinite(ropeVelocity.lengthSqr())) ropeVelocity = Vec3.ZERO;
      if (spec.kind == MechanismSpec.Kind.ROPE) {
        ensureRope();
        if (t.contains("ropePhysics")) rope.restore(t.getCompound("ropePhysics"), ceiling);
        else rope.impulse(ropeVelocity);
        setPos(rope.end());
        syncRope();
      }
    } catch (RuntimeException ex) {
      discard();
    }
  }

  /** Platform-owned hooks route authoring back to their parent. */
  public MechanismEntity authoringRoot() {
    if (parent != null)
      for (var e : level().getEntitiesOfClass(MechanismEntity.class, getBoundingBox().inflate(8)))
        if (e.getUUID().equals(parent)) return e;
    return this;
  }

  public BlockPos valveTarget() {
    return spec.valveTarget == null ? attached : spec.valveTarget;
  }

  public BlockPos attachedBlock() {
    return attached;
  }

  private void ensureRope() {
    if (rope == null) rope = new RopePhysics(ceiling, spec.ropeLength);
  }

  private void syncRope() {
    CompoundTag t = rope.save();
    t.remove("previous");
    entityData.set(ROPE_NODES, t);
  }

  public List<Vec3> ropePoints(float partial) {
    if (!level().isClientSide()) {
      ensureRope();
      return rope.points();
    }
    if (ropeClient.isEmpty()) return List.of(ceiling, position());
    // Snapshot interval is two ticks. Interpolate without changing interaction bounds.
    double alpha = Math.min(1, Math.max(0, (tickCount - ropeSnapshotTick + partial) / 2.0));
    List<Vec3> result = new ArrayList<>();
    for (int i = 0; i < ropeClient.size(); i++)
      result.add(ropePrevious.get(i).lerp(ropeClient.get(i), alpha));
    return result;
  }

  private boolean isHolding(Player p) {
    return net.mcreator.climber.capability.ClimbCapability.get(p)
        .map(
            d ->
                d.isClimbEnabled()
                    && (d.isRightHandGrabbing() && d.getRightHoldEntity() == getId()
                        || d.isLeftHandGrabbing() && d.getLeftHoldEntity() == getId()))
        .orElse(false);
  }

  @Override
  public AABB getBoundingBoxForCulling() {
    AABB box = getBoundingBox();
    if (spec.kind == MechanismSpec.Kind.ROPE) {
      box = box.minmax(new AABB(ceiling, position()).inflate(.2));
      for (Vec3 v : ropePoints(1)) box = box.minmax(new AABB(v, v).inflate(.1));
    }
    if (spec.kind == MechanismSpec.Kind.PLATFORM)
      for (Vec3 v : spec.route())
        box = box.minmax(new AABB(origin.add(v), origin.add(v)).inflate(1.6));
    return box;
  }

  @Override
  public boolean shouldRenderAtSqrDistance(double d) {
    return d < 128 * 128;
  }
}
