package net.mcreator.climber.event;

import java.util.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Collision-limited horizontal displacement budget in blocks, not an uncalibrated velocity. */
@Mod.EventBusSubscriber(modid = "climber")
public final class RebarKnockback {
  private record Push(LivingEntity entity, Vec3 direction, double left) {}

  private static final Map<UUID, Push> ACTIVE = new HashMap<>();

  public static void start(LivingEntity entity, Vec3 velocity) {
    double distance =
        net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("RebarKnockback");
    Vec3 dir = new Vec3(velocity.x, 0, velocity.z).normalize();
    if (!entity.level().isClientSide && distance > 0 && dir.lengthSqr() > .5)
      ACTIVE.put(entity.getUUID(), new Push(entity, dir, distance));
  }

  @SubscribeEvent
  public static void tick(TickEvent.ServerTickEvent e) {
    if (e.phase != TickEvent.Phase.END) return;
    var it = ACTIVE.entrySet().iterator();
    while (it.hasNext()) {
      var entry = it.next();
      var push = entry.getValue();
      var entity = push.entity;
      if (!entity.isAlive() || entity.isRemoved()) {
        it.remove();
        continue;
      }
      double step = Math.min(.4, push.left);
      Vec3 before = entity.position();
      entity.move(MoverType.SELF, push.direction.scale(step));
      double moved = entity.position().subtract(before).dot(push.direction);
      if (entity instanceof net.minecraft.server.level.ServerPlayer player)
        player.connection.teleport(
            entity.getX(), entity.getY(), entity.getZ(), entity.getYRot(), entity.getXRot());
      entity.hurtMarked = true;
      if (moved < step - .001 || push.left - step < .001) it.remove();
      else entry.setValue(new Push(entity, push.direction, push.left - step));
    }
  }

  @SubscribeEvent
  public static void stopped(ServerStoppedEvent e) {
    ACTIVE.clear();
  }
}
