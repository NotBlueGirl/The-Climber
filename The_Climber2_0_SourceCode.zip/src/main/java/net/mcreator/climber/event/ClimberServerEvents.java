package net.mcreator.climber.event;

import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.capability.ClimbCapability;
import net.mcreator.climber.network.AnchorSyncPacket;
import net.mcreator.climber.network.ClimbStatePacket;
import net.mcreator.climber.network.GripModeSyncPacket;
import net.mcreator.climber.network.StaminaSyncPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

public class ClimberServerEvents {

  /** Синхронизирует текущий режим захвата новому/переподключившемуся игроку. */
  @SubscribeEvent
  public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
    if (event.getEntity() instanceof ServerPlayer sp) {
      ClimberMod.PACKET_HANDLER.send(
          PacketDistributor.PLAYER.with(() -> sp),
          new GripModeSyncPacket(
              ClimberConfig.INSTANCE.getGripMode(), ClimberConfig.INSTANCE.getAutoGripMode()));
      net.mcreator.climber.network.ConfigUpdatePacket.sendTo(sp);
    }
  }

  @SubscribeEvent
  public void onPlayerTick(TickEvent.PlayerTickEvent event) {
    if (event.phase != TickEvent.Phase.END) return;
    Player player = event.player;

    if (player.level().isClientSide()) return;
    if (!player.isAlive()
        || player.isPassenger()
        || player.isSpectator()
        || player.getAbilities().flying) return;

    ClimbCapability.get(player)
        .ifPresent(
            data -> {
              if (!data.isClimbEnabled()
                  || (!data.isRightHandGrabbing() && !data.isLeftHandGrabbing())) {
                player.setNoGravity(false);

                if (ClimberConfig.INSTANCE.isStaminaEnabled()) {
                  tickStaminaRecovery(player, data);
                }
                return;
              }

              // Holds can disappear: block mined, piton pulled out, rebar knocked loose.
              validateHolds(player, data);
              if (!data.isRightHandGrabbing() && !data.isLeftHandGrabbing()) {
                player.setNoGravity(false);
                return;
              }

              applyClimbPhysics(
                  player,
                  data.isRightHandGrabbing(),
                  data.isLeftHandGrabbing(),
                  data.getRightAnchor(),
                  data.getLeftAnchor(),
                  supportVelocity(
                      player,
                      data.isRightHandGrabbing() ? data.getRightHoldEntity() : -1,
                      data.isLeftHandGrabbing() ? data.getLeftHoldEntity() : -1));

              if (ClimberConfig.INSTANCE.isStaminaEnabled()) {
                tickStaminaDrain(player, data);
              }

              // >>> FIX: periodic full sync so newly-tracking players catch up <<<
              if (player instanceof ServerPlayer sp && player.tickCount % 20 == 0) {
                syncStamina(sp, data);
                ClimberMod.PACKET_HANDLER.send(
                    PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
                    new AnchorSyncPacket(
                        sp.getUUID(),
                        data.getRightAnchor(),
                        data.getLeftAnchor(),
                        data.getRightHoldEntity(),
                        data.getLeftHoldEntity()));
                ClimberMod.PACKET_HANDLER.send(
                    PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
                    new ClimbStatePacket(
                        sp.getUUID(),
                        data.isClimbEnabled(),
                        data.isRightHandGrabbing(),
                        data.isLeftHandGrabbing()));
              }
            });
  }

  // -----------------------------------------------------------------------
  // Stamina logic
  // -----------------------------------------------------------------------

  private static void tickStaminaDrain(Player player, ClimbCapability.IClimbData data) {
    boolean changed = false;

    if (data.isRightHandGrabbing()) {
      float s = data.getRightStamina() - ClimberConfig.INSTANCE.getStaminaDrainRate();
      data.setRightStamina(s);
      if (s <= 0 && !data.isRightExhausted()) {
        data.setRightExhausted(true);
        forceReleaseHand(player, data, true);
      }
      changed = true;
    } else if (!data.isRightExhausted()) {
      float s = data.getRightStamina() + ClimberConfig.INSTANCE.getStaminaRegenRate();
      data.setRightStamina(s);
      if (s >= ClimberConfig.INSTANCE.getStaminaMax())
        data.setRightStamina(ClimberConfig.INSTANCE.getStaminaMax());
      changed = true;
    }

    if (data.isLeftHandGrabbing()) {
      float s = data.getLeftStamina() - ClimberConfig.INSTANCE.getStaminaDrainRate();
      data.setLeftStamina(s);
      if (s <= 0 && !data.isLeftExhausted()) {
        data.setLeftExhausted(true);
        forceReleaseHand(player, data, false);
      }
      changed = true;
    } else if (!data.isLeftExhausted()) {
      float s = data.getLeftStamina() + ClimberConfig.INSTANCE.getStaminaRegenRate();
      data.setLeftStamina(s);
      if (s >= ClimberConfig.INSTANCE.getStaminaMax())
        data.setLeftStamina(ClimberConfig.INSTANCE.getStaminaMax());
      changed = true;
    }

    if (changed && player instanceof ServerPlayer sp) {
      syncStamina(sp, data);
    }
  }

  private static void tickStaminaRecovery(Player player, ClimbCapability.IClimbData data) {
    boolean changed = false;

    if (!data.isRightHandGrabbing()) {
      float newR =
          Math.min(
              ClimberConfig.INSTANCE.getStaminaMax(),
              data.getRightStamina() + ClimberConfig.INSTANCE.getStaminaRegenRate());
      data.setRightStamina(newR);
      if (data.isRightExhausted() && newR >= ClimberConfig.INSTANCE.getStaminaMax()) {
        data.setRightExhausted(false);
      }
      changed = true;
    }

    if (!data.isLeftHandGrabbing()) {
      float newL =
          Math.min(
              ClimberConfig.INSTANCE.getStaminaMax(),
              data.getLeftStamina() + ClimberConfig.INSTANCE.getStaminaRegenRate());
      data.setLeftStamina(newL);
      if (data.isLeftExhausted() && newL >= ClimberConfig.INSTANCE.getStaminaMax()) {
        data.setLeftExhausted(false);
      }
      changed = true;
    }

    if (changed && player instanceof ServerPlayer sp) {
      syncStamina(sp, data);
    }
  }

  private static void validateHolds(Player player, ClimbCapability.IClimbData data) {
    var rightHand =
        player.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT
            ? net.minecraft.world.InteractionHand.MAIN_HAND
            : net.minecraft.world.InteractionHand.OFF_HAND;
    var leftHand =
        rightHand == net.minecraft.world.InteractionHand.MAIN_HAND
            ? net.minecraft.world.InteractionHand.OFF_HAND
            : net.minecraft.world.InteractionHand.MAIN_HAND;
    if (data.isRightHandGrabbing() && !player.getItemInHand(rightHand).isEmpty())
      forceReleaseHand(player, data, true);
    if (data.isLeftHandGrabbing() && !player.getItemInHand(leftHand).isEmpty())
      forceReleaseHand(player, data, false);
    boolean moved = false;
    if (data.isRightHandGrabbing()
        && player.level().getEntity(data.getRightHoldEntity())
            instanceof net.mcreator.climber.entity.HandholdEntity h
        && h.canBeGrabbed()) {
      Vec3 a = h.getGripPoint();
      if (!a.equals(data.getRightAnchor())) {
        data.setRightAnchor(a);
        moved = true;
      }
    }
    if (data.isLeftHandGrabbing()
        && player.level().getEntity(data.getLeftHoldEntity())
            instanceof net.mcreator.climber.entity.HandholdEntity h
        && h.canBeGrabbed()) {
      Vec3 a = h.getGripPoint();
      if (!a.equals(data.getLeftAnchor())) {
        data.setLeftAnchor(a);
        moved = true;
      }
    }
    if (moved && player instanceof ServerPlayer sp)
      ClimberMod.PACKET_HANDLER.send(
          PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
          new AnchorSyncPacket(
              sp.getUUID(),
              data.getRightAnchor(),
              data.getLeftAnchor(),
              data.getRightHoldEntity(),
              data.getLeftHoldEntity()));
    if (data.isRightHandGrabbing()
        && !holdStillValid(player, data.getRightHoldEntity(), data.getRightAnchor())) {
      forceReleaseHand(player, data, true);
    }
    if (data.isLeftHandGrabbing()
        && !holdStillValid(player, data.getLeftHoldEntity(), data.getLeftAnchor())) {
      forceReleaseHand(player, data, false);
    }
  }

  private static boolean holdStillValid(Player player, int entityId, Vec3 anchor) {
    if (anchor == null) return false;
    if (entityId >= 0) {
      net.minecraft.world.entity.Entity e = player.level().getEntity(entityId);
      if (!(e instanceof net.mcreator.climber.entity.HandholdEntity h) || !h.canBeGrabbed())
        return false;
      h.onGripTick(player);
      return h.canBeGrabbed();
    }
    if (player.tickCount % 4 != 0) return true;
    // a block must still be there, right at the anchor
    net.minecraft.world.phys.AABB box =
        new net.minecraft.world.phys.AABB(
            anchor.x - 0.08,
            anchor.y - 0.08,
            anchor.z - 0.08,
            anchor.x + 0.08,
            anchor.y + 0.08,
            anchor.z + 0.08);
    return !net.mcreator.climber.grip.LedgeDetector.isFree(player.level(), box);
  }

  public static void forceReleaseHand(
      Player player, ClimbCapability.IClimbData data, boolean right) {
    if (right) {
      data.setRightHandGrabbing(false);
      data.setRightAnchor(null);
      data.setRightHoldEntity(-1);
    } else {
      data.setLeftHandGrabbing(false);
      data.setLeftAnchor(null);
      data.setLeftHoldEntity(-1);
    }

    if (player instanceof ServerPlayer sp) {
      ClimberMod.PACKET_HANDLER.send(
          PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
          new AnchorSyncPacket(
              sp.getUUID(),
              data.getRightAnchor(),
              data.getLeftAnchor(),
              data.getRightHoldEntity(),
              data.getLeftHoldEntity()));
      ClimberMod.PACKET_HANDLER.send(
          PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
          new ClimbStatePacket(
              sp.getUUID(),
              data.isClimbEnabled(),
              data.isRightHandGrabbing(),
              data.isLeftHandGrabbing()));
    }
  }

  private static void syncStamina(ServerPlayer player, ClimbCapability.IClimbData data) {
    ClimberMod.PACKET_HANDLER.send(
        PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player),
        new StaminaSyncPacket(
            player.getUUID(),
            data.getRightStamina(),
            data.getLeftStamina(),
            data.isRightExhausted(),
            data.isLeftExhausted()));
  }

  // -----------------------------------------------------------------------
  // Physics (unchanged)
  // -----------------------------------------------------------------------

  // -----------------------------------------------------------------------
  // Physics (updated for smooth pull toward grab point)
  // -----------------------------------------------------------------------
  public static void applyClimbPhysics(
      Player player, boolean rightGrab, boolean leftGrab, Vec3 rightAnchor, Vec3 leftAnchor) {
    applyClimbPhysics(player, rightGrab, leftGrab, rightAnchor, leftAnchor, Vec3.ZERO);
  }

  public static Vec3 supportVelocity(Player player, int right, int left) {
    Vec3 v = Vec3.ZERO;
    int n = 0;
    for (int id : new int[] {right, left})
      if (id >= 0
          && player.level().getEntity(id)
              instanceof net.mcreator.climber.mechanism.MechanismEntity e) {
        v = v.add(e.gripVelocity());
        n++;
      }
    return n == 0 ? Vec3.ZERO : v.scale(1.0 / n);
  }

  public static void applyClimbPhysics(
      Player player,
      boolean rightGrab,
      boolean leftGrab,
      Vec3 rightAnchor,
      Vec3 leftAnchor,
      Vec3 support) {
    player.setNoGravity(true);
    player.fallDistance = 0;
    Vec3 pos = player.position().add(0, player.getEyeHeight() * 0.5, 0);
    Vec3 vel = player.getDeltaMovement().subtract(support);
    boolean bothGrabbing = rightGrab && leftGrab && rightAnchor != null && leftAnchor != null;
    Vec3 target = null;
    if (bothGrabbing) {
      target = rightAnchor.add(leftAnchor).scale(0.5);
    } else if (rightGrab && rightAnchor != null) {
      target = rightAnchor;
    } else if (leftGrab && leftAnchor != null) {
      target = leftAnchor;
    }
    if (target != null) {
      Vec3 delta = target.subtract(pos);
      double dist = delta.length();
      Vec3 dir = dist > 0.001 ? delta.normalize() : Vec3.ZERO;

      // Целевое расстояние от якоря (игрок подтягивается к этой точке)
      double restDist = bothGrabbing ? 0.25 : 0.35;

      // Пружинная сила притяжения (Hooke's law)
      // Чем дальше игрок, тем сильнее притяжение
      double stretch = dist - restDist;
      if (Math.abs(stretch) > 0.01) {
        double springForce = stretch * 0.12;
        vel = vel.add(dir.scale(springForce));
      }

      // Ослабленная гравитация (игрок держится за блок)
      vel =
          vel.add(
              0,
              -0.015
                  * net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("ClimberGravity"),
              0);

      // Затухание для плавности движения и остановки
      vel = vel.scale(0.85);

      // Ограничение максимальной скорости для плавности
      double maxSpeed = 0.5;
      double speed = vel.length();
      if (speed > maxSpeed) {
        vel = vel.scale(maxSpeed / speed);
      }
    }
    player.setDeltaMovement(vel.add(support));
    if (!player.onGround()) {
      player.resetFallDistance();
    }
  }

  // -----------------------------------------------------------------------
  // Jump handling (unchanged logic, packet fix handled in ClimbJumpPacket)
  // -----------------------------------------------------------------------

  public static void handleClimbJump(Player player, boolean bothHands) {
    ClimbCapability.get(player)
        .ifPresent(
            data -> {
              if (!data.isClimbEnabled()) return;
              if (!data.isRightHandGrabbing() && !data.isLeftHandGrabbing()) return;

              Vec3 impulse;

              if (bothHands
                  && data.isRightHandGrabbing()
                  && data.isLeftHandGrabbing()
                  && data.getRightAnchor() != null
                  && data.getLeftAnchor() != null) {

                Vec3 look = player.getLookAngle();
                float strength = ClimberConfig.INSTANCE.getStrengthJumpBothHands();
                impulse = new Vec3(look.x, look.y + 0.55, look.z).normalize().scale(strength);

              } else {
                Vec3 look = player.getLookAngle();
                float strength = ClimberConfig.INSTANCE.getStrengthJumpOneHand();
                impulse = new Vec3(look.x, look.y + 0.3, look.z).normalize().scale(strength);
              }

              player.setDeltaMovement(impulse);
              player.setNoGravity(false);

              data.setRightHandGrabbing(false);
              data.setLeftHandGrabbing(false);
              data.setRightAnchor(null);
              data.setLeftAnchor(null);
              player.fallDistance = 0;
            });
  }

  public static void handleClimbJump(Player player) {
    handleClimbJump(player, false);
  }
}
