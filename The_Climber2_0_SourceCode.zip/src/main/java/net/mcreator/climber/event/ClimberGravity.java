package net.mcreator.climber.event;

import java.util.UUID;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Attribute-based multiplier preserves other mods' gravity changes and syncs client prediction. */
@Mod.EventBusSubscriber(modid = "climber")
public final class ClimberGravity {
  private static final UUID ID = UUID.fromString("a810ff46-4053-444f-bfbe-b18a67093531");

  public static void update(Player player) {
    var attribute = player.getAttribute(ForgeMod.ENTITY_GRAVITY.get());
    if (attribute == null) return;
    boolean enabled =
        net.mcreator.climber.capability.ClimbCapability.get(player)
            .map(d -> d.isClimbEnabled())
            .orElse(false);
    double amount =
        enabled
            ? net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("ClimberGravity") - 1
            : 0;
    var old = attribute.getModifier(ID);
    if (old != null && Math.abs(old.getAmount() - amount) < 1e-9) return;
    if (old != null) attribute.removeModifier(ID);
    if (amount != 0)
      attribute.addTransientModifier(
          new AttributeModifier(
              ID, "Climber mode gravity", amount, AttributeModifier.Operation.MULTIPLY_TOTAL));
  }

  @SubscribeEvent
  public static void tick(TickEvent.PlayerTickEvent e) {
    if (e.phase == TickEvent.Phase.START && !e.player.level().isClientSide) update(e.player);
  }
}
