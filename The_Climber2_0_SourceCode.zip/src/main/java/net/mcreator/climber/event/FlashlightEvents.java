package net.mcreator.climber.event;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.mcreator.climber.item.CrankFlashlightItem;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Server side of the crank flashlight: while a player holds a lit flashlight invisible {@code
 * minecraft:light} blocks follow the beam from the player outwards (only ever placed into air and
 * removed again as soon as the beam moves, the flashlight is put away, the player leaves, ...).
 */
public class FlashlightEvents {
  public static final double RANGE = 28.0;
  private static final int FLAGS = Block.UPDATE_CLIENTS;

  /** Light blocks currently placed for one player (spot, mid-beam fill, near glow). */
  private record Lit(ResourceKey<Level> dim, Map<BlockPos, Integer> blocks) {}

  private static final Map<UUID, Lit> LIT = new HashMap<>();

  @SubscribeEvent
  public void onPlayerTick(TickEvent.PlayerTickEvent event) {
    if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer sp)) return;

    ItemStack light = null;
    for (InteractionHand h : InteractionHand.values()) {
      ItemStack s = sp.getItemInHand(h);
      if (CrankFlashlightItem.isShining(s)) {
        light = s;
        break;
      }
    }
    if (light == null || !sp.isAlive() || sp.isSpectator()) {
      remove(sp.server, sp.getUUID());
      return;
    }

    // charge drains in CrankFlashlightItem.inventoryTick (also while it sits in the inventory)
    int charge = CrankFlashlightItem.getCharge(light);
    int level = CrankFlashlightItem.brightness(charge);
    // an almost empty dynamo flickers and stutters
    float frac = (float) charge / CrankFlashlightItem.maxCharge();
    if (frac < 0.1f) {
      float p = 0.35f * (1f - frac / 0.1f) + 0.05f;
      if (sp.getRandom().nextFloat() < p)
        level = Math.max(0, level - 1 - sp.getRandom().nextInt(2));
    }

    ServerLevel lvl = sp.serverLevel();
    Map<BlockPos, Integer> want = beam(lvl, sp, level);
    Lit old = LIT.get(sp.getUUID());
    if (old != null && old.dim == lvl.dimension() && old.blocks.equals(want)) return;

    // remove the blocks that are no longer wanted, place / update the rest
    if (old != null) {
      if (old.dim != lvl.dimension()) {
        remove(sp.server, sp.getUUID());
        old = null;
      } else {
        for (Map.Entry<BlockPos, Integer> e : old.blocks.entrySet()) {
          if (!want.containsKey(e.getKey())) clear(lvl, e.getKey());
        }
      }
    }
    Map<BlockPos, Integer> placed = new HashMap<>();
    for (Map.Entry<BlockPos, Integer> e : want.entrySet()) {
      BlockPos bp = e.getKey();
      boolean mine = old != null && old.blocks.containsKey(bp);
      BlockState st = lvl.getBlockState(bp);
      if (!(st.isAir() || mine && st.is(Blocks.LIGHT))) continue;
      if (!st.is(Blocks.LIGHT) || st.getValue(LightBlock.LEVEL) != e.getValue()) {
        lvl.setBlock(
            bp, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, e.getValue()), FLAGS);
      }
      placed.put(bp, e.getValue());
    }
    if (placed.isEmpty()) LIT.remove(sp.getUUID());
    else LIT.put(sp.getUUID(), new Lit(lvl.dimension(), placed));
  }

  /**
   * Light along the beam, starting at the player: a chain of light sources every few blocks of the
   * ray (dimmer the further out), ending with a soft glow where the beam meets a surface.
   */
  private static Map<BlockPos, Integer> beam(ServerLevel level, ServerPlayer sp, int bright) {
    Map<BlockPos, Integer> out = new HashMap<>();
    if (bright <= 0) return out;
    Vec3 eye = sp.getEyePosition();
    Vec3 look = sp.getViewVector(1f);
    double range = 6 + RANGE * bright / 15.0;
    Vec3 end = eye.add(look.scale(range));
    BlockHitResult hit =
        level.clip(new ClipContext(eye, end, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, sp));
    boolean miss = hit.getType() == HitResult.Type.MISS;
    // the beam leaves from the centre of the body and points at what the player looks at
    Vec3 target = miss ? end : hit.getLocation();
    Vec3 flat = new Vec3(look.x, 0, look.z);
    flat = flat.lengthSqr() < 1.0e-4 ? Vec3.ZERO : flat.normalize();
    eye = sp.position().add(0, sp.getBbHeight() * 0.58, 0).add(flat.scale(0.32));
    if (target.distanceToSqr(eye) > 1.0e-4) look = target.subtract(eye).normalize();
    double dist = target.distanceTo(eye);
    // glow right at the torch, so even pressed against a wall the beam lights its surroundings
    put(
        out,
        level,
        sp,
        eye,
        look,
        Math.max(0.0, Math.min(1.0, dist - 0.3)),
        Math.max(1, bright - 1));
    int n = 0;
    for (double d = 2.5; d < dist - 1.0 && n < 6; d += 3.5, n++) {
      int lv = bright - (int) (d / 4.0);
      if (lv <= 0) break;
      put(out, level, sp, eye, look, d, lv);
    }
    if (!miss && dist > 1.5)
      put(out, level, sp, eye, look, dist - 0.4, Math.max(1, bright - 2 - (int) (dist / 5.0)));
    return out;
  }

  private static void put(
      Map<BlockPos, Integer> out,
      ServerLevel level,
      ServerPlayer sp,
      Vec3 eye,
      Vec3 look,
      double d,
      int lightLevel) {
    for (int i = 0; i < 6 && d >= 0.0; i++, d -= 0.5) {
      BlockPos bp = BlockPos.containing(eye.add(look.scale(d)));
      if (out.containsKey(bp)) return;
      if (canUse(level, bp, sp)) {
        out.put(bp, lightLevel);
        return;
      }
    }
  }

  private static boolean canUse(ServerLevel level, BlockPos bp, ServerPlayer sp) {
    if (!level.isLoaded(bp) || !level.isInWorldBounds(bp)) return false;
    BlockState st = level.getBlockState(bp);
    if (st.isAir()) return true;
    Lit mine = LIT.get(sp.getUUID());
    return mine != null && mine.blocks.containsKey(bp) && st.is(Blocks.LIGHT);
  }

  private static void clear(ServerLevel level, BlockPos pos) {
    if (level.isLoaded(pos) && level.getBlockState(pos).is(Blocks.LIGHT)) {
      level.setBlock(pos, Blocks.AIR.defaultBlockState(), FLAGS);
    }
  }

  private static void remove(MinecraftServer server, UUID id) {
    Lit lit = LIT.remove(id);
    if (lit == null || server == null) return;
    ServerLevel level = server.getLevel(lit.dim);
    if (level != null) for (BlockPos p : lit.blocks.keySet()) clear(level, p);
  }

  @SubscribeEvent
  public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
    if (event.getEntity() instanceof ServerPlayer sp) remove(sp.server, sp.getUUID());
  }

  @SubscribeEvent
  public void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
    if (event.getEntity() instanceof ServerPlayer sp) remove(sp.server, sp.getUUID());
  }

  @SubscribeEvent
  public void onStopping(ServerStoppingEvent event) {
    for (UUID id : LIT.keySet().toArray(new UUID[0])) remove(event.getServer(), id);
    LIT.clear();
  }
}
