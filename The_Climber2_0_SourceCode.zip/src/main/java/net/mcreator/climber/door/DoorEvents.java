package net.mcreator.climber.door;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ChunkWatchEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class DoorEvents {

    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.level instanceof ServerLevel sl) {
            DoorGrabManager.tick(sl);
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            DoorGrabManager.releaseAll(sp);
        }
    }

    @SubscribeEvent
    public void onChangeDim(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            DoorGrabManager.releaseAll(sp);
        }
    }

    /** Any door removal (by any player) drops its physics state and releases all hands on it. */
    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getLevel() instanceof ServerLevel sl)) return;
        BlockState st = event.getState();
        if (st.getBlock() instanceof DoorBlock) {
            BlockPos lower = DoorGrabManager.lowerOf(st, event.getPos());
            DoorGrabManager.forget(sl, lower);
        }
    }

    /** Every time a client starts tracking a chunk, it receives the angles of physics doors in it. */
    @SubscribeEvent
    public void onChunkWatch(ChunkWatchEvent.Watch event) {
        ServerPlayer sp = event.getPlayer();
        ServerLevel level = event.getLevel();
        DoorGrabManager.sendChunk(sp, level, event.getPos().x, event.getPos().z);
    }

    @SubscribeEvent
    public void onServerStopped(ServerStoppedEvent event) {
        DoorGrabManager.clearAll();
    }
}
