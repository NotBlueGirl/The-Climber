package net.mcreator.climber.door;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;

/** Persistent + runtime state of one physics door (keyed by its lower half). */
public class DoorRotationState {
    public final BlockPos lowerPos;
    public final Direction facing;
    public final boolean hingeRight;
    /** 0 = closed, {@link DoorGeometry#vanillaOpenAngle(boolean)} = vanilla open. */
    public float angleDeg;

    // ---- runtime only (not saved) ----
    /** Angular velocity in degrees per tick. */
    public float angularVel = 0f;
    /** When non-null the door is driven towards this angle (redstone, villagers, shift-click). */
    public Float motorTarget = null;
    /** Last angle broadcast to clients. */
    public float lastSent = Float.NaN;
    /** Ticks the door has been at rest (used to put it to sleep). */
    public int restTicks = 0;

    public DoorRotationState(BlockPos lowerPos, Direction facing, boolean hingeRight, float angleDeg) {
        this.lowerPos = lowerPos;
        this.facing = facing;
        this.hingeRight = hingeRight;
        this.angleDeg = angleDeg;
    }

    public void setAngle(float deg) {
        this.angleDeg = deg;
    }

    public BlockPos upperPos() {
        return lowerPos.above();
    }

    public CompoundTag write() {
        CompoundTag t = new CompoundTag();
        t.putLong("pos", lowerPos.asLong());
        t.putInt("facing", facing.get3DDataValue());
        t.putBoolean("hingeRight", hingeRight);
        t.putFloat("angle", angleDeg);
        return t;
    }

    public static DoorRotationState read(CompoundTag t) {
        return new DoorRotationState(
                BlockPos.of(t.getLong("pos")),
                Direction.from3DDataValue(t.getInt("facing")),
                t.getBoolean("hingeRight"),
                t.getFloat("angle"));
    }
}
