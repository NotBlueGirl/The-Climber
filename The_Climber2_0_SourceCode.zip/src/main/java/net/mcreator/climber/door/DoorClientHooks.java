package net.mcreator.climber.door;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Dist-safe bridge: common code and mixins must never reference classes from the {@code client}
 * package directly (a dedicated server crashes while applying the mixins). The client installs its
 * implementations in {@code ClimberClientSetup.init}.
 */
public final class DoorClientHooks {
  private DoorClientHooks() {}

  public static volatile BiFunction<Level, BlockPos, Float> angleLookup = (l, p) -> null;
  public static volatile BiConsumer<BlockPos, Vec3> grabPress = (p, h) -> {};

  public static Float clientAngle(Level level, BlockPos lower) {
    return net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()
        ? angleLookup.apply(level, lower)
        : null;
  }
}
