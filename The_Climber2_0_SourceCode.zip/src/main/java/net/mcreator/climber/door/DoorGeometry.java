package net.mcreator.climber.door;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Door geometry shared by the server physics, the collision/outline mixins and the renderer.
 *
 * <p>The pivot is placed exactly where vanilla's closed slab and vanilla's open slab overlap
 * (1.5/16 from both block edges). Because of this, rotating the closed model by {@link
 * #vanillaOpenAngle(boolean)} lands exactly on the vanilla "open" model/hitbox, so switching
 * between the physics door and the vanilla door never makes it jump.
 *
 * <p>Angle convention: positive angles rotate the (x, z) plank vector from +X towards +Z (clockwise
 * when seen from above, same direction as increasing player yaw).
 */
public final class DoorGeometry {
  /** Half of the 3/16 vanilla door thickness. */
  public static final double HALF_THICK = 3.0 / 32.0;

  public static final int SEGMENTS = 8;

  /** Pivot distance from the block centre, sideways (towards the hinge side). */
  private static final double HINGE_OFFSET = 0.5 - HALF_THICK; // 6.5/16

  /** The plank starts slightly behind the pivot and ends at the far edge of the frame. */
  public static final double PLANK_START = -HALF_THICK;

  public static final double PLANK_END = 1.0 - HALF_THICK;
  public static final double PLANK_LEN = PLANK_END; // usable lever length

  private DoorGeometry() {}

  /** Angle that matches the vanilla OPEN model for the given hinge side. */
  public static float vanillaOpenAngle(boolean hingeRight) {
    return hingeRight ? 90f : -90f;
  }

  /** Pivot offset from the block centre (local XZ). */
  public static double[] hingeOffsetLocal(Direction facing, boolean hingeRight) {
    Direction side = hingeRight ? facing.getClockWise() : facing.getCounterClockWise();
    double sideX = side.getStepX() * HINGE_OFFSET;
    double sideZ = side.getStepZ() * HINGE_OFFSET;
    // the closed slab lies against the block face OPPOSITE to "facing"
    double faceX = facing.getStepX() * (0.5 - HALF_THICK);
    double faceZ = facing.getStepZ() * (0.5 - HALF_THICK);
    return new double[] {sideX - faceX, sideZ - faceZ};
  }

  /** World XZ position of the pivot. */
  public static double[] hingeXZ(BlockPos lower, Direction facing, boolean hingeRight) {
    double[] o = hingeOffsetLocal(facing, hingeRight);
    return new double[] {lower.getX() + 0.5 + o[0], lower.getZ() + 0.5 + o[1]};
  }

  /** Closed (angle = 0) plank direction: from the pivot towards the far edge of the frame. */
  public static double[] closedDirection(Direction facing, boolean hingeRight) {
    Direction side = hingeRight ? facing.getClockWise() : facing.getCounterClockWise();
    return new double[] {-side.getStepX(), -side.getStepZ()};
  }

  /** Unit vector pivot -> free edge for a given angle. */
  public static double[] getPlankDirection(Direction facing, boolean hingeRight, float angleDeg) {
    double[] w = closedDirection(facing, hingeRight);
    double rad = Math.toRadians(angleDeg);
    double cos = Math.cos(rad), sin = Math.sin(rad);
    return new double[] {w[0] * cos - w[1] * sin, w[0] * sin + w[1] * cos};
  }

  /**
   * @deprecated kept for older call sites
   */
  @Deprecated
  public static double[] plankDir(Direction facing, boolean hingeRight, float angleDeg) {
    return getPlankDirection(facing, hingeRight, angleDeg);
  }

  /** Angle at which the plank points from the pivot towards world point (x, z). */
  public static float angleTowards(
      BlockPos lower, Direction facing, boolean hingeRight, double x, double z) {
    double[] h = hingeXZ(lower, facing, hingeRight);
    double[] w = closedDirection(facing, hingeRight);
    double target = Math.atan2(z - h[1], x - h[0]);
    double base = Math.atan2(w[1], w[0]);
    return Mth.wrapDegrees((float) Math.toDegrees(target - base));
  }

  /** Segment boxes in LOCAL coordinates (Y 0..1). */
  private static List<AABB> localSegments(Direction facing, boolean hingeRight, float angleDeg) {
    double[] offset = hingeOffsetLocal(facing, hingeRight);
    double hingeX = 0.5 + offset[0];
    double hingeZ = 0.5 + offset[1];
    double[] dir = getPlankDirection(facing, hingeRight, angleDeg);
    var settings = net.mcreator.climber.ClimberConfig.INSTANCE.gameplay();
    // Door-local X points from the hinge toward the free edge. Local Z is its
    // perpendicular (-dirZ, dirX); both rotate with the door, without moving its pivot/model.
    double posX = settings.number("DoorHitboxPosX"), posZ = settings.number("DoorHitboxPosZ");
    hingeX += dir[0] * posX - dir[1] * posZ;
    hingeZ += dir[1] * posX + dir[0] * posZ;
    List<AABB> out = new ArrayList<>(SEGMENTS);
    double span = net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("DoorHitboxX");
    double halfDepth =
        net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("DoorHitboxZ") * .5;
    for (int s = 0; s < SEGMENTS; s++) {
      double t0 = PLANK_START + span * s / SEGMENTS;
      double t1 = PLANK_START + span * (s + 1) / SEGMENTS;
      double cx = hingeX + dir[0] * (t0 + t1) * 0.5;
      double cz = hingeZ + dir[1] * (t0 + t1) * 0.5;
      double px = Math.abs(dir[1]) * halfDepth;
      double pz = Math.abs(dir[0]) * halfDepth;
      double hx = Math.abs(dir[0]) * (t1 - t0) * 0.5;
      double hz = Math.abs(dir[1]) * (t1 - t0) * 0.5;
      out.add(new AABB(cx - px - hx, 0.0, cz - pz - hz, cx + px + hx, 1.0, cz + pz + hz));
    }
    return out;
  }

  /** Door shape in local block coordinates (one half). */
  public static VoxelShape rotatedShape(
      BlockPos lower, Direction facing, boolean hingeRight, float angleDeg, int half) {
    VoxelShape shape = Shapes.empty();
    for (AABB box : localSegments(facing, hingeRight, angleDeg)) {
      // Split at the seam between the two real door blocks, retaining overhang
      // below the lower block and above the upper block for signed offsets.
      var settings = net.mcreator.climber.ClimberConfig.INSTANCE.gameplay();
      double bottom = settings.number("DoorHitboxPosY");
      double top = bottom + settings.number("DoorHitboxY");
      double lo = half == 0 ? bottom : Math.max(bottom, 1);
      double hi = half == 0 ? Math.min(top, 1) : top;
      if (hi > lo)
        shape =
            Shapes.or(
                shape,
                Shapes.create(
                    new AABB(box.minX, lo - half, box.minZ, box.maxX, hi - half, box.maxZ)));
    }
    return shape.optimize();
  }

  /** World-space boxes of the whole 2-high door. */
  public static List<AABB> worldSegments(
      BlockPos lower, Direction facing, boolean hingeRight, float angleDeg) {
    List<AABB> local = localSegments(facing, hingeRight, angleDeg);
    List<AABB> out = new ArrayList<>(local.size());
    for (AABB b : local) {
      out.add(
          new AABB(
              b.minX + lower.getX(),
              lower.getY()
                  + net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("DoorHitboxPosY"),
              b.minZ + lower.getZ(),
              b.maxX + lower.getX(),
              lower.getY()
                  + net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("DoorHitboxPosY")
                  + net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("DoorHitboxY"),
              b.maxZ + lower.getZ()));
    }
    return out;
  }

  private static final double COLLISION_EPSILON = 0.03D;

  /** True when the door at this angle would intersect a solid block (other doors are ignored). */
  public static boolean collides(
      Level level, BlockPos lower, Direction facing, boolean hingeRight, float angleDeg) {
    for (AABB raw : worldSegments(lower, facing, hingeRight, angleDeg)) {
      AABB box = raw.deflate(COLLISION_EPSILON);
      if (box.maxX <= box.minX || box.maxY <= box.minY || box.maxZ <= box.minZ) continue;
      if (boxCollides(level, lower, box)) return true;
    }
    return false;
  }

  private static boolean boxCollides(Level level, BlockPos lower, AABB box) {
    int minX = Mth.floor(box.minX), maxX = Mth.floor(box.maxX);
    int minY = Mth.floor(box.minY), maxY = Mth.floor(box.maxY);
    int minZ = Mth.floor(box.minZ), maxZ = Mth.floor(box.maxZ);
    BlockPos above = lower.above();
    BlockPos.MutableBlockPos bp = new BlockPos.MutableBlockPos();
    for (int y = minY; y <= maxY; y++) {
      for (int x = minX; x <= maxX; x++) {
        for (int z = minZ; z <= maxZ; z++) {
          bp.set(x, y, z);
          if (bp.equals(lower) || bp.equals(above)) continue;
          BlockState bs = level.getBlockState(bp);
          if (bs.isAir() || bs.getBlock() instanceof DoorBlock) continue;
          VoxelShape sh = bs.getCollisionShape(level, bp);
          if (sh.isEmpty()) continue;
          for (AABB aabb : sh.toAabbs()) {
            if (aabb.move(bp).intersects(box)) return true;
          }
        }
      }
    }
    return false;
  }
}
