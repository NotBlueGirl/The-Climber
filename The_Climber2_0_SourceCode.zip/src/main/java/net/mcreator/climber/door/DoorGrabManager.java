package net.mcreator.climber.door;

import java.util.*;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.network.DoorAnglePacket;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/**
 * Server-authoritative door physics.
 *
 * <ul>
 *   <li>Grabbing: the grabbed point of the plank is dragged towards the point the player is looking
 *       at (like White Knuckle / Amnesia), instead of mapping mouse yaw 1:1 to the door angle.
 *   <li>The door has angular velocity, hinge friction, bounces off blocks and keeps swinging after
 *       release.
 *   <li>Players walking into a door push it (see {@link #push}).
 *   <li>A door swinging into a player nudges the player and is stopped instead of clipping through
 *       them.
 *   <li>Redstone / villagers / shift-click toggles animate the physics door to the vanilla pose.
 *   <li>A door that comes to rest in an exact vanilla pose is handed back to vanilla (state
 *       removed).
 * </ul>
 */
public final class DoorGrabManager {

  private DoorGrabManager() {}

  private static final double MAX_START_REACH = 4.5; // eye -> clicked point
  private static final double MAX_HOLD_REACH = 4.75; // eye -> handle while holding
  private static final float MAX_ANGULAR_VEL = 22f; // deg / tick
  private static final float ANGLE_LIMIT = 178f;

  private static final class Grab {
    final ResourceKey<Level> dim;
    final BlockPos lower;
    final double radius; // distance pivot -> handle along the plank
    final double reach; // eye -> handle distance at grab time
    final double handleY; // world Y of the handle

    Grab(ResourceKey<Level> dim, BlockPos lower, double radius, double reach, double handleY) {
      this.dim = dim;
      this.lower = lower;
      this.radius = radius;
      this.reach = reach;
      this.handleY = handleY;
    }
  }

  private static final Map<UUID, Grab> SESSIONS = new HashMap<>();
  private static final Map<ResourceKey<Level>, Set<BlockPos>> ACTIVE = new HashMap<>();

  /** Strongest push impulse received this tick, per door. */
  private static final Map<ResourceKey<Level>, Map<BlockPos, Float>> PUSHES = new HashMap<>();

  /** Guard so our own OPEN-flag syncing does not re-trigger {@link #onVanillaStateChanged}. */
  private static boolean syncingVanilla = false;

  // ------------------------------------------------------------------
  // Public API
  // ------------------------------------------------------------------

  public static boolean isGrabbing(UUID id) {
    return SESSIONS.containsKey(id);
  }

  public static boolean canOpenByHand(BlockState st) {
    return st.getBlock() instanceof DoorBlock door && door.type().canOpenByHand();
  }

  public static BlockPos lowerOf(BlockState st, BlockPos pos) {
    return st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? pos.below() : pos;
  }

  /** Start dragging the door at the clicked point. */
  public static void start(ServerPlayer sp, BlockPos anyDoorPos, Vec3 hit) {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()) return;
    ServerLevel level = sp.serverLevel();
    BlockState st = level.getBlockState(anyDoorPos);
    if (!canOpenByHand(st)) return;
    BlockPos lower = lowerOf(st, anyDoorPos);

    Grab existing = SESSIONS.get(sp.getUUID());
    if (existing != null && existing.lower.equals(lower) && existing.dim == level.dimension())
      return; // RMB auto-repeat

    if (hit == null) hit = Vec3.atCenterOf(anyDoorPos);
    Vec3 eye = sp.getEyePosition();
    if (eye.distanceTo(hit) > MAX_START_REACH) return;

    DoorStateManager mgr = DoorStateManager.get(level);
    DoorRotationState rs = mgr.getOrCreate(level, lower);
    if (rs == null) return;

    double[] h = DoorGeometry.hingeXZ(lower, rs.facing, rs.hingeRight);
    double[] d = DoorGeometry.getPlankDirection(rs.facing, rs.hingeRight, rs.angleDeg);
    double radius = (hit.x - h[0]) * d[0] + (hit.z - h[1]) * d[1];
    radius = Mth.clamp(radius, 0.25, DoorGeometry.PLANK_LEN);
    double reach = Mth.clamp(eye.distanceTo(hit), 0.6, 3.5);
    double handleY = Mth.clamp(hit.y, lower.getY() + 0.1, lower.getY() + 1.9);

    SESSIONS.put(sp.getUUID(), new Grab(level.dimension(), lower, radius, reach, handleY));
    rs.motorTarget = null;
    activate(level, lower);
    broadcast(level, lower, rs.angleDeg);
    rs.lastSent = rs.angleDeg;
  }

  /** Fallback used by the old packet path (no exact hit point). */
  public static void start(ServerPlayer sp, BlockPos anyDoorPos) {
    start(sp, anyDoorPos, null);
  }

  public static void release(ServerPlayer sp) {
    SESSIONS.remove(sp.getUUID());
    // the door keeps its momentum and stays active until it settles
  }

  public static void releaseAll(ServerPlayer sp) {
    release(sp);
  }

  /** Release every session on this door (door broken / replaced). */
  public static void releaseDoor(ServerLevel level, BlockPos lower) {
    SESSIONS.values().removeIf(g -> g.dim == level.dimension() && g.lower.equals(lower));
  }

  /** A player walked into the door. wish = intended horizontal velocity (blocks/tick). */
  public static void push(ServerPlayer sp, BlockPos anyDoorPos, double wishX, double wishZ) {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()) return;
    ServerLevel level = sp.serverLevel();
    BlockState st = level.getBlockState(anyDoorPos);
    if (!canOpenByHand(st)) return;
    BlockPos lower = lowerOf(st, anyDoorPos);
    if (sp.position().distanceToSqr(Vec3.atBottomCenterOf(lower)) > 3.0 * 3.0) return;
    Grab g = SESSIONS.get(sp.getUUID());
    if (g != null && g.lower.equals(lower)) return; // already dragging it

    double speed = Math.sqrt(wishX * wishX + wishZ * wishZ);
    if (speed < 1.0e-3) return;
    if (speed > 0.6) {
      wishX *= 0.6 / speed;
      wishZ *= 0.6 / speed;
    } // anti-cheat clamp

    DoorRotationState rs = DoorStateManager.get(level).getOrCreate(level, lower);
    if (rs == null) return;

    double[] h = DoorGeometry.hingeXZ(lower, rs.facing, rs.hingeRight);
    double[] d = DoorGeometry.getPlankDirection(rs.facing, rs.hingeRight, rs.angleDeg);
    double cx = sp.getX() - h[0], cz = sp.getZ() - h[1];
    double r = Mth.clamp(cx * d[0] + cz * d[1], 0.2, DoorGeometry.PLANK_LEN);
    // direction in which a point of the plank moves for increasing angle
    double nx = -d[1], nz = d[0];
    double side = Math.signum(cx * nx + cz * nz);
    double vn = wishX * nx + wishZ * nz;
    if (side == 0 || Math.signum(vn) != -side) return; // moving away from / along the plank

    float omega = (float) Math.toDegrees(vn / r) * 1.1f;
    omega = Mth.clamp(omega, -MAX_ANGULAR_VEL, MAX_ANGULAR_VEL);
    Map<BlockPos, Float> m = PUSHES.computeIfAbsent(level.dimension(), k -> new HashMap<>());
    Float prev = m.get(lower);
    if (prev == null || Math.abs(omega) > Math.abs(prev)) m.put(lower, omega);
    rs.motorTarget = null;
    activate(level, lower);
  }

  /** Called after vanilla changed OPEN (redstone, villagers, shift-click, other mods). */
  public static void onVanillaStateChanged(Level level, BlockPos pos) {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()) return;
    if (syncingVanilla || !(level instanceof ServerLevel sl)) return;
    BlockState st = sl.getBlockState(pos);
    if (!(st.getBlock() instanceof DoorBlock)) return;
    BlockPos lower = lowerOf(st, pos);
    DoorRotationState rs = DoorStateManager.get(sl).get(lower);
    if (rs == null) return; // pure vanilla door, nothing to do
    boolean open = st.getValue(DoorBlock.OPEN);
    boolean physOpen = Math.abs(rs.angleDeg) > 45f;
    if (open == physOpen) return;
    if (isDoorGrabbed(sl, lower)) return;
    rs.motorTarget = open ? DoorGeometry.vanillaOpenAngle(rs.hingeRight) : 0f;
    activate(sl, lower);
  }

  public static void clearAll() {
    SESSIONS.clear();
    ACTIVE.clear();
    PUSHES.clear();
  }

  // ------------------------------------------------------------------
  // Simulation
  // ------------------------------------------------------------------

  private static void activate(ServerLevel level, BlockPos lower) {
    ACTIVE.computeIfAbsent(level.dimension(), k -> new HashSet<>()).add(lower.immutable());
    DoorRotationState rs = DoorStateManager.get(level).get(lower);
    if (rs != null) rs.restTicks = 0;
  }

  private static boolean isDoorGrabbed(ServerLevel level, BlockPos lower) {
    for (Grab g : SESSIONS.values())
      if (g.dim == level.dimension() && g.lower.equals(lower)) return true;
    return false;
  }

  public static void tick(ServerLevel level) {
    if (!net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().doorPhysics()) {
      for (var p : level.players()) releaseAll(p);
      var mgr = DoorStateManager.get(level);
      var positions = new java.util.ArrayList<BlockPos>();
      for (var state : mgr.all()) positions.add(state.lowerPos);
      for (var pos : positions) {
        mgr.remove(pos);
        if (level.isLoaded(pos)) broadcast(level, pos, Float.NaN);
      }
      ACTIVE.remove(level.dimension());
      PUSHES.remove(level.dimension());
      return;
    }
    ResourceKey<Level> dim = level.dimension();

    // drop invalid sessions
    Iterator<Map.Entry<UUID, Grab>> sit = SESSIONS.entrySet().iterator();
    while (sit.hasNext()) {
      Map.Entry<UUID, Grab> e = sit.next();
      Grab g = e.getValue();
      if (g.dim != dim) continue;
      Player p = level.getPlayerByUUID(e.getKey());
      if (!(p instanceof ServerPlayer)
          || !p.isAlive()
          || p.isSpectator()
          || !(level.getBlockState(g.lower).getBlock() instanceof DoorBlock)) {
        sit.remove();
        continue;
      }
      activate(level, g.lower);
    }

    Set<BlockPos> active = ACTIVE.get(dim);
    if (active == null || active.isEmpty()) return;
    Map<BlockPos, Float> pushes = PUSHES.getOrDefault(dim, Collections.emptyMap());
    DoorStateManager mgr = DoorStateManager.get(level);

    Iterator<BlockPos> it = active.iterator();
    while (it.hasNext()) {
      BlockPos lower = it.next();
      if (!level.isLoaded(lower)) {
        it.remove();
        continue;
      }
      BlockState st = level.getBlockState(lower);
      DoorRotationState rs = mgr.get(lower);
      if (!(st.getBlock() instanceof DoorBlock) || rs == null) {
        it.remove();
        continue;
      }
      if (!stepDoor(level, mgr, rs, pushes.get(lower))) {
        it.remove();
      }
    }
    pushes.clear();
  }

  /**
   * @return false when the door went to sleep.
   */
  private static boolean stepDoor(
      ServerLevel level, DoorStateManager mgr, DoorRotationState rs, Float push) {
    BlockPos lower = rs.lowerPos;
    float angle = rs.angleDeg;
    float omega = rs.angularVel;
    boolean grabbed = false;
    UUID grabber = null;

    // ---- forces ----
    for (Map.Entry<UUID, Grab> e : SESSIONS.entrySet()) {
      Grab g = e.getValue();
      if (g.dim != level.dimension() || !g.lower.equals(lower)) continue;
      Player p = level.getPlayerByUUID(e.getKey());
      if (p == null) continue;
      Vec3 eye = p.getEyePosition();
      double[] h = DoorGeometry.hingeXZ(lower, rs.facing, rs.hingeRight);
      double[] d = DoorGeometry.getPlankDirection(rs.facing, rs.hingeRight, angle);
      Vec3 handle = new Vec3(h[0] + d[0] * g.radius, g.handleY, h[1] + d[1] * g.radius);
      if (eye.distanceTo(handle) > MAX_HOLD_REACH) { // pulled too far: hand slips off
        SESSIONS.remove(e.getKey());
        break;
      }
      Vec3 target = eye.add(p.getLookAngle().scale(g.reach));
      double tx = target.x - h[0], tz = target.z - h[1];
      if (tx * tx + tz * tz > 0.04) {
        float desired =
            DoorGeometry.angleTowards(lower, rs.facing, rs.hingeRight, target.x, target.z);
        float err = Mth.wrapDegrees(desired - angle);
        omega += err * 0.28f;
        omega *= 0.55f; // heavy damping while held -> responsive, no oscillation
      } else {
        omega *= 0.6f;
      }
      grabbed = true;
      grabber = e.getKey();
      break; // first grabber drives the door
    }

    if (!grabbed && push != null) {
      // walking into the door: it moves at least as fast as the player
      if (Math.signum(push) != Math.signum(omega) || Math.abs(push) > Math.abs(omega)) omega = push;
      rs.motorTarget = null;
    }

    if (!grabbed && rs.motorTarget != null) {
      float err = rs.motorTarget - angle;
      omega += err * 0.12f;
      omega *= 0.72f;
      if (Math.abs(err) < 0.6f && Math.abs(omega) < 0.4f) {
        angle = rs.motorTarget;
        omega = 0f;
        rs.motorTarget = null;
      }
    } else if (!grabbed && push == null) {
      omega *= 0.90f; // hinge friction
      if (Math.abs(omega) < 0.08f) omega = 0f;
    }

    omega = Mth.clamp(omega, -MAX_ANGULAR_VEL, MAX_ANGULAR_VEL);

    // ---- integrate with collisions ----
    if (omega != 0f) {
      float next = angle + omega;
      if (next > ANGLE_LIMIT) {
        next = ANGLE_LIMIT;
        omega = -omega * 0.3f;
      }
      if (next < -ANGLE_LIMIT) {
        next = -ANGLE_LIMIT;
        omega = -omega * 0.3f;
      }

      boolean startBlocked = DoorGeometry.collides(level, lower, rs.facing, rs.hingeRight, angle);
      if (!startBlocked && DoorGeometry.collides(level, lower, rs.facing, rs.hingeRight, next)) {
        // binary search the contact angle
        float lo = angle, hi = next;
        for (int i = 0; i < 6; i++) {
          float mid = (lo + hi) * 0.5f;
          if (DoorGeometry.collides(level, lower, rs.facing, rs.hingeRight, mid)) hi = mid;
          else lo = mid;
        }
        next = lo;
        omega = -omega * 0.25f; // small bounce off the wall
        if (Math.abs(omega) < 0.5f) omega = 0f;
      }

      if (entityBlocks(level, rs, angle, next, omega, grabber)) {
        next = angle;
        omega *= 0.4f;
      }
      angle = next;
    }

    rs.angularVel = omega;
    if (angle != rs.angleDeg) mgr.setAngle(lower, angle);

    // ---- vanilla OPEN flag (AI / pathfinding / redstone comparators) ----
    syncOpenFlag(level, lower, angle);

    // ---- network ----
    boolean resting = !grabbed && omega == 0f && rs.motorTarget == null;
    if (resting && tryReturnToVanilla(level, mgr, rs)) return false;

    if (Float.isNaN(rs.lastSent)
        || Math.abs(angle - rs.lastSent) > 0.05f
        || (resting && angle != rs.lastSent)) {
      broadcast(level, lower, angle);
      rs.lastSent = angle;
    }

    if (resting) {
      rs.restTicks++;
      return rs.restTicks < 3;
    }
    rs.restTicks = 0;
    return true;
  }

  /** Door swinging into a living entity: nudge the entity, block the door. */
  private static boolean entityBlocks(
      ServerLevel level, DoorRotationState rs, float from, float to, float omega, UUID grabber) {
    AABB area = new AABB(rs.lowerPos).expandTowards(0, 1, 0).inflate(1.1, 0.1, 1.1);
    List<LivingEntity> list =
        level.getEntitiesOfClass(
            LivingEntity.class, area, e -> e.isAlive() && !e.isSpectator() && !e.noPhysics);
    if (list.isEmpty()) return false;
    List<AABB> nextBoxes = DoorGeometry.worldSegments(rs.lowerPos, rs.facing, rs.hingeRight, to);
    double[] d = DoorGeometry.getPlankDirection(rs.facing, rs.hingeRight, to);
    double sgn = Math.signum(omega);
    double mx = -d[1] * sgn, mz = d[0] * sgn;
    boolean blocked = false;
    for (LivingEntity e : list) {
      AABB bb = e.getBoundingBox().deflate(0.02);
      boolean hits = false;
      for (AABB b : nextBoxes)
        if (b.intersects(bb)) {
          hits = true;
          break;
        }
      if (!hits) continue;
      blocked = true;
      if (grabber != null && e.getUUID().equals(grabber)) continue; // you can't shove yourself
      double strength = Mth.clamp(Math.abs(omega) * 0.012, 0.06, 0.35);
      e.push(mx * strength, 0.0, mz * strength);
      e.hurtMarked = true; // sync velocity to the client of a player
    }
    return blocked;
  }

  private static void syncOpenFlag(ServerLevel level, BlockPos lower, float angle) {
    BlockState st = level.getBlockState(lower);
    if (!(st.getBlock() instanceof DoorBlock)) return;
    boolean open = Math.abs(angle) > 45f;
    if (st.getValue(DoorBlock.OPEN) != open) {
      syncingVanilla = true;
      try {
        level.setBlock(lower, st.setValue(DoorBlock.OPEN, open), 10);
      } finally {
        syncingVanilla = false;
      }
    }
  }

  /**
   * If the door rests in an exact vanilla pose, remove the physics state (back to vanilla
   * rendering).
   */
  private static boolean tryReturnToVanilla(
      ServerLevel level, DoorStateManager mgr, DoorRotationState rs) {
    float open = DoorGeometry.vanillaOpenAngle(rs.hingeRight);
    boolean atClosed = Math.abs(rs.angleDeg) < 1.0f;
    boolean atOpen = Math.abs(rs.angleDeg - open) < 1.0f;
    if (!atClosed && !atOpen) return false;
    if (isDoorGrabbed(level, rs.lowerPos)) return false;
    syncOpenFlag(level, rs.lowerPos, atOpen ? open : 0f);
    mgr.remove(rs.lowerPos);
    broadcast(level, rs.lowerPos, Float.NaN);
    return true;
  }

  /** Door broken / replaced. */
  public static void forget(ServerLevel level, BlockPos lower) {
    releaseDoor(level, lower);
    Set<BlockPos> a = ACTIVE.get(level.dimension());
    if (a != null) a.remove(lower);
    DoorStateManager.get(level).remove(lower);
    broadcast(level, lower, Float.NaN);
  }

  public static void broadcast(ServerLevel level, BlockPos lower, float angle) {
    ClimberMod.PACKET_HANDLER.send(
        PacketDistributor.TRACKING_CHUNK.with(() -> level.getChunkAt(lower)),
        new DoorAnglePacket(lower, angle));
  }

  /** Sends the angles of all physics doors inside a chunk to one player. */
  public static void sendChunk(ServerPlayer sp, ServerLevel level, int chunkX, int chunkZ) {
    for (DoorRotationState rs : DoorStateManager.get(level).all()) {
      if ((rs.lowerPos.getX() >> 4) == chunkX && (rs.lowerPos.getZ() >> 4) == chunkZ) {
        ClimberMod.PACKET_HANDLER.send(
            PacketDistributor.PLAYER.with(() -> sp), new DoorAnglePacket(rs.lowerPos, rs.angleDeg));
      }
    }
  }
}
