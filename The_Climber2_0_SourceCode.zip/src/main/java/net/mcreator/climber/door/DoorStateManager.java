package net.mcreator.climber.door;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

public class DoorStateManager extends SavedData {
    private static final String DATA_NAME = "climber_door_states";

    private final Map<BlockPos, DoorRotationState> states = new HashMap<>();

    public static DoorStateManager get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                DoorStateManager::load,
                DoorStateManager::new,
                DATA_NAME
        );
    }

    public static DoorStateManager load(CompoundTag tag) {
        DoorStateManager m = new DoorStateManager();
        ListTag list = tag.getList("doors", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            DoorRotationState s = DoorRotationState.read(list.getCompound(i));
            m.states.put(s.lowerPos, s);
        }
        return m;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (DoorRotationState s : states.values()) {
            list.add(s.write());
        }
        tag.put("doors", list);
        return tag;
    }

    /**
     * Получить состояние для двери по любой её позиции (верх или низ).
     * Если состояния ещё нет — создаёт его на основе ванильного состояния двери.
     */
    @Nullable
    public DoorRotationState getOrCreate(ServerLevel level, BlockPos anyDoorPos) {
        BlockState state = level.getBlockState(anyDoorPos);
        if (!(state.getBlock() instanceof DoorBlock)) return null;

        BlockPos lower = state.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER
                ? anyDoorPos
                : anyDoorPos.below();

        BlockState lowerState = level.getBlockState(lower);
        if (!(lowerState.getBlock() instanceof DoorBlock)) return null;

        var facing = lowerState.getValue(DoorBlock.FACING);
        var hinge  = lowerState.getValue(DoorBlock.HINGE);
        boolean open = lowerState.getValue(DoorBlock.OPEN);
        boolean rightHinge = (hinge == net.minecraft.world.level.block.state.properties.DoorHingeSide.RIGHT);

        DoorRotationState existing = states.get(lower);
        // A different door (other facing/hinge) may have been placed at the same spot: drop stale data.
        if (existing != null && existing.facing == facing && existing.hingeRight == rightHinge) return existing;

        // Vanilla "open" door = the angle that matches the vanilla open model.
        float startAngle = open ? DoorGeometry.vanillaOpenAngle(rightHinge) : 0f;

        DoorRotationState s = new DoorRotationState(lower, facing, rightHinge, startAngle);
        states.put(lower, s);
        setDirty();
        return s;
    }

    public void setAngle(BlockPos lowerPos, float angleDeg) {
        DoorRotationState s = states.get(lowerPos);
        if (s != null) {
            s.setAngle(angleDeg);
            setDirty();
        }
    }

    public Iterable<DoorRotationState> all() {
        return states.values();
    }

    @Nullable
    public DoorRotationState get(BlockPos lowerPos) {
        return states.get(lowerPos);
    }

    public void remove(BlockPos lowerPos) {
        if (states.remove(lowerPos) != null) setDirty();
    }
}