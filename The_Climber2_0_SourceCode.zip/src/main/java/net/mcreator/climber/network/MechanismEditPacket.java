package net.mcreator.climber.network;

import java.util.function.Supplier;
import net.mcreator.climber.item.DebuggerToolItem;
import net.mcreator.climber.mechanism.*;
import net.minecraft.nbt.*;
import net.minecraft.network.*;
import net.minecraft.network.chat.Component;
import net.minecraftforge.network.*;

/**
 * Untrusted client authoring request; bounds, creative permission, reach and held tool checked
 * server-side.
 */
public record MechanismEditPacket(CompoundTag tag, int target, int action) {
  public static void encode(MechanismEditPacket m, FriendlyByteBuf b) {
    b.writeUtf(m.tag.toString(), 8192);
    b.writeInt(m.target);
    b.writeByte(m.action);
  }

  public static MechanismEditPacket decode(FriendlyByteBuf b) {
    String text = b.readUtf(8192);
    int target = b.readInt(), action = b.readByte();
    try {
      return new MechanismEditPacket(TagParser.parseTag(text), target, action);
    } catch (Exception e) {
      return new MechanismEditPacket(new CompoundTag(), target, -1);
    }
  }

  public static void handle(MechanismEditPacket m, Supplier<NetworkEvent.Context> supplier) {
    var c = supplier.get();
    if (c.getDirection() != NetworkDirection.PLAY_TO_SERVER) {
      c.setPacketHandled(true);
      return;
    }
    c.enqueueWork(
        () -> {
          var p = c.getSender();
          if (p == null || !p.isCreative() || p.isSpectator() || m.action < 0 || m.action > 2)
            return;
          var stack =
              p.getMainHandItem().getItem() instanceof DebuggerToolItem
                  ? p.getMainHandItem()
                  : p.getOffhandItem();
          if (!(stack.getItem() instanceof DebuggerToolItem)) return;
          try {
            MechanismSpec s = MechanismSpec.load(m.tag);
            s.validate();
            for (var block : s.railBlocks)
              if (!p.level().hasChunkAt(block)
                  || !p.level().mayInteract(p, block)
                  || p.level().getBlockState(block).isAir()
                  || block.distSqr(p.blockPosition()) > 96 * 96)
                throw new IllegalArgumentException(
                    "Rail block unavailable or out of authoring range");
            if (m.target >= 0) {
              var e = p.level().getEntity(m.target);
              if (!(e instanceof MechanismEntity obj)
                  || obj.isChild()
                  || obj.getBoundingBox().distanceToSqr(p.getEyePosition()) > 36
                  || !p.level().mayInteract(p, obj.blockPosition()))
                throw new IllegalArgumentException("Target not editable or out of reach");
              if (s.valveTarget != null && m.action == 0) {
                var block = s.valveTarget;
                if (obj.spec().kind != MechanismSpec.Kind.VALVE
                    || !p.level().hasChunkAt(block)
                    || !p.level().mayInteract(p, block)
                    || block.distSqr(obj.attachedBlock()) > 64 * 64
                    || p.level().getBlockState(block).isAir())
                  throw new IllegalArgumentException(
                      "Valve target unavailable or beyond 64 blocks");
              }
              if (m.action == 1) obj.removeWithChildren();
              else if (m.action == 2) obj.trigger();
              else obj.reconfigure(s);
            }
            if (m.action == 0) stack.getOrCreateTag().put("mechanism", s.save());
            p.sendSystemMessage(
                Component.literal(
                    m.action == 0
                        ? "Debugger configuration saved on server."
                        : m.action == 1 ? "Mechanism removed." : "Platform start/stop toggled."));
          } catch (RuntimeException ex) {
            p.sendSystemMessage(Component.literal("Debugger: " + ex.getMessage()));
          }
        });
    c.setPacketHandled(true);
  }
}
