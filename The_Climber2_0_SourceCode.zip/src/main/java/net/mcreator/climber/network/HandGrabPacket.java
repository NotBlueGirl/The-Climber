package net.mcreator.climber.network;

import java.util.function.Supplier;
import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.capability.ClimbCapability;
import net.mcreator.climber.entity.HandholdEntity;
import net.mcreator.climber.grip.GripMode;
import net.mcreator.climber.grip.LedgeDetector;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

public class HandGrabPacket {

  public static final byte HAND_RIGHT = 0;
  public static final byte HAND_LEFT = 1;

  private static final double MAX_REACH_SQ = 5.0 * 5.0;

  private final byte hand;
  private final boolean grabbing;
  private final double anchorX, anchorY, anchorZ;
  private final int faceId; // -1 = unknown
  private final long blockPos; // block that was hit
  private final int entityId; // -1 = block grab, otherwise a HandholdEntity

  public HandGrabPacket(
      byte hand,
      boolean grabbing,
      double ax,
      double ay,
      double az,
      Direction face,
      BlockPos pos,
      int entityId) {
    this.hand = hand;
    this.grabbing = grabbing;
    this.anchorX = ax;
    this.anchorY = ay;
    this.anchorZ = az;
    this.faceId = face != null ? face.get3DDataValue() : -1;
    this.blockPos = pos != null ? pos.asLong() : BlockPos.containing(ax, ay, az).asLong();
    this.entityId = entityId;
  }

  /** Block grab. */
  public static HandGrabPacket block(byte hand, Vec3 anchor, Direction face, BlockPos pos) {
    return new HandGrabPacket(hand, true, anchor.x, anchor.y, anchor.z, face, pos, -1);
  }

  /** Handhold-entity grab. */
  public static HandGrabPacket entity(byte hand, Vec3 anchor, int entityId) {
    return new HandGrabPacket(hand, true, anchor.x, anchor.y, anchor.z, null, null, entityId);
  }

  public HandGrabPacket(byte hand, boolean grabbing) {
    this(hand, grabbing, 0, 0, 0, null, BlockPos.ZERO, -1);
  }

  public static void encode(HandGrabPacket msg, FriendlyByteBuf buf) {
    buf.writeByte(msg.hand);
    buf.writeBoolean(msg.grabbing);
    buf.writeDouble(msg.anchorX);
    buf.writeDouble(msg.anchorY);
    buf.writeDouble(msg.anchorZ);
    buf.writeByte(msg.faceId);
    buf.writeLong(msg.blockPos);
    buf.writeInt(msg.entityId);
  }

  public static HandGrabPacket decode(FriendlyByteBuf buf) {
    byte hand = buf.readByte();
    boolean grabbing = buf.readBoolean();
    double ax = buf.readDouble(), ay = buf.readDouble(), az = buf.readDouble();
    int faceId = buf.readByte();
    long pos = buf.readLong();
    int entityId = buf.readInt();
    Direction face = faceId >= 0 && faceId < 6 ? Direction.from3DDataValue(faceId) : null;
    return new HandGrabPacket(hand, grabbing, ax, ay, az, face, BlockPos.of(pos), entityId);
  }

  public static void handle(HandGrabPacket msg, Supplier<NetworkEvent.Context> ctx) {
    ctx.get()
        .enqueueWork(
            () -> {
              ServerPlayer player = ctx.get().getSender();
              if (player == null) return;

              ClimbCapability.get(player)
                  .ifPresent(
                      data -> {
                        if (!data.isClimbEnabled() || msg.hand < HAND_RIGHT || msg.hand > HAND_LEFT)
                          return;
                        if (msg.grabbing) {
                          boolean main =
                              (msg.hand == HAND_RIGHT)
                                  == (player.getMainArm()
                                      == net.minecraft.world.entity.HumanoidArm.RIGHT);
                          if (!player
                              .getItemInHand(
                                  main
                                      ? net.minecraft.world.InteractionHand.MAIN_HAND
                                      : net.minecraft.world.InteractionHand.OFF_HAND)
                              .isEmpty()) return;
                        }

                        if (msg.grabbing) {
                          boolean exhausted =
                              (msg.hand == HAND_RIGHT)
                                  ? data.isRightExhausted()
                                  : data.isLeftExhausted();
                          if (exhausted) return;
                        }

                        Vec3 anchor = null;
                        int holdEntity = -1;
                        if (msg.grabbing) {
                          Level level = player.level();
                          if (msg.entityId >= 0) {
                            Entity e = level.getEntity(msg.entityId);
                            if (e instanceof HandholdEntity h
                                && h.canBeGrabbed()
                                && h.getGripPoint().distanceToSqr(player.getEyePosition())
                                    <= MAX_REACH_SQ) {
                              anchor = h.getGripPoint();
                              holdEntity = msg.entityId;
                              h.onGripTick(player);
                            }
                          } else {
                            Vec3 candidate = new Vec3(msg.anchorX, msg.anchorY, msg.anchorZ);
                            BlockPos pos = BlockPos.of(msg.blockPos);
                            Direction face =
                                msg.faceId >= 0 ? Direction.from3DDataValue(msg.faceId) : null;
                            boolean nearBlock = new AABB(pos).inflate(0.05).contains(candidate);
                            if (nearBlock
                                && level.isLoaded(pos)
                                && candidate.distanceToSqr(player.getEyePosition()) <= MAX_REACH_SQ
                                && isGrabbableCandidate(
                                    level,
                                    candidate,
                                    pos,
                                    face,
                                    ClimberConfig.INSTANCE.getGripMode())) {
                              anchor = candidate;
                            }
                          }
                        }

                        boolean valid = (anchor != null);
                        if (msg.hand == HAND_RIGHT) {
                          data.setRightHandGrabbing(valid);
                          data.setRightAnchor(anchor);
                          data.setRightHoldEntity(holdEntity);
                        } else {
                          data.setLeftHandGrabbing(valid);
                          data.setLeftAnchor(anchor);
                          data.setLeftHoldEntity(holdEntity);
                        }

                        ClimberMod.PACKET_HANDLER.send(
                            PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player),
                            new AnchorSyncPacket(
                                player.getUUID(),
                                data.getRightAnchor(),
                                data.getLeftAnchor(),
                                data.getRightHoldEntity(),
                                data.getLeftHoldEntity()));
                        ClimberMod.PACKET_HANDLER.send(
                            PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player),
                            new ClimbStatePacket(
                                player.getUUID(),
                                data.isClimbEnabled(),
                                data.isRightHandGrabbing(),
                                data.isLeftHandGrabbing()));
                      });
            });
    ctx.get().setPacketHandled(true);
  }

  /**
   * Can the hand hold on to {@code hit} (a point on face {@code face} of block {@code pos})?
   *
   * <ul>
   *   <li>{@link GripMode#LIP_HANDS}: any solid, allowed block.
   *   <li>{@link GripMode#REALISTIC}: only real holds – lips, top edges and outside corners (see
   *       {@link LedgeDetector}); partial blocks count through their collision shape.
   * </ul>
   *
   * The mode is passed explicitly so the client uses the server's synced mode, not its own config
   * file.
   */
  public static boolean isGrabbableCandidate(
      Level level, Vec3 hit, BlockPos pos, Direction face, GripMode mode) {
    BlockState state = level.getBlockState(pos);
    if (state.getBlock() instanceof DoorBlock) return false; // doors have their own mechanic
    if (mode == GripMode.REALISTIC) {
      if (face == null || !isAllowed(state)) return false;
      if (state.getCollisionShape(level, pos).isEmpty()) return false;
      return LedgeDetector.isLedge(level, pos, face, hit);
    }
    return isSolidAllowed(level, pos);
  }

  /**
   * @deprecated kept for compatibility; resolves the block from the hit point.
   */
  @Deprecated
  public static boolean isGrabbableCandidate(Level level, Vec3 candidate, Direction face) {
    BlockPos bp = BlockPos.containing(candidate);
    if (face != null) {
      BlockPos inside =
          BlockPos.containing(
              candidate.subtract(
                  face.getStepX() * 0.01, face.getStepY() * 0.01, face.getStepZ() * 0.01));
      bp = inside;
    }
    return isGrabbableCandidate(level, candidate, bp, face, ClimberConfig.INSTANCE.getGripMode());
  }

  private static boolean isSolidAllowed(Level level, BlockPos pos) {
    BlockState state = level.getBlockState(pos);
    if (state.isAir() || !state.isSolidRender(level, pos)) return false;
    return isAllowed(state);
  }

  private static boolean isAllowed(BlockState state) {
    ResourceLocation id = ForgeRegistries.BLOCKS.getKey(state.getBlock());
    return id != null && ClimberConfig.INSTANCE.isGrabbable(id.toString());
  }
}
