package net.mcreator.climber.network;

import net.mcreator.climber.animation.RigAnimation;
import net.mcreator.climber.client.animation.AnimationClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import java.util.UUID;
import java.util.function.Supplier;

public record AnimationSyncPacket(int kind, UUID player, String text, long elapsed) {
    public static final int RESET = 0, DEFINITION = 1, PLAY = 2, STOP = 3, MESSAGE = 4;
    public static final UUID NONE = new UUID(0, 0);
    public static AnimationSyncPacket text(int kind, String text) { return new AnimationSyncPacket(kind, NONE, text, 0); }
    public static void encode(AnimationSyncPacket m, FriendlyByteBuf b) { b.writeVarInt(m.kind); b.writeUUID(m.player); b.writeUtf(m.text, RigAnimation.MAX_JSON); b.writeLong(m.elapsed); }
    public static AnimationSyncPacket decode(FriendlyByteBuf b) { return new AnimationSyncPacket(b.readVarInt(), b.readUUID(), b.readUtf(RigAnimation.MAX_JSON), b.readLong()); }
    public static void handle(AnimationSyncPacket m, Supplier<NetworkEvent.Context> supplier) {
        var c = supplier.get();
        if (c.getDirection() != NetworkDirection.PLAY_TO_CLIENT) { c.setPacketHandled(true); return; }
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> AnimationClient.receive(m))); c.setPacketHandled(true);
    }
}
