package net.mcreator.climber.network;

import net.mcreator.climber.client.ClientDoorAngles;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class DoorAnglePacket {
    private final BlockPos lower;
    private final float angle;

    public DoorAnglePacket(BlockPos lower, float angle) {
        this.lower = lower;
        this.angle = angle;
    }

    public static void encode(DoorAnglePacket msg, FriendlyByteBuf buf) {
        buf.writeLong(msg.lower.asLong());
        buf.writeFloat(msg.angle);
    }

    public static DoorAnglePacket decode(FriendlyByteBuf buf) {
        return new DoorAnglePacket(BlockPos.of(buf.readLong()), buf.readFloat());
    }

    public static void handle(DoorAnglePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                        ClientDoorAngles.set(msg.lower, msg.angle))
        );
        ctx.get().setPacketHandled(true);
    }
}