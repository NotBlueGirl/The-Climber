package net.mcreator.climber.network;

import java.util.*;
import java.util.function.Supplier;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.item.DebuggerToolItem;
import net.mcreator.climber.mechanism.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.*;
import net.minecraft.network.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.*;
import net.minecraft.server.level.*;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.*;

/** Creative-only catalog authorization, short-lived chunk tickets and optimistic revisions. */
@Mod.EventBusSubscriber(modid = "climber")
public record RemoteObjectPacket(String id, int action, CompoundTag tag, int revision) {
  private static final TicketType<UUID> TICKET =
      TicketType.create("climber_author", UUID::compareTo, 200);

  private record Pending(
      ServerPlayer player,
      ServerLevel level,
      MechanismCatalog.Entry entry,
      RemoteObjectPacket request,
      long deadline) {}

  private static final Map<UUID, Pending> PENDING = new HashMap<>();
  private static final Map<UUID, Long> LAST = new HashMap<>();

  public static void encode(RemoteObjectPacket m, FriendlyByteBuf b) {
    b.writeUtf(m.id, 180);
    b.writeByte(m.action);
    b.writeNbt(m.tag);
    b.writeInt(m.revision);
  }

  public static RemoteObjectPacket decode(FriendlyByteBuf b) {
    return new RemoteObjectPacket(
        b.readUtf(180),
        b.readByte(),
        Objects.requireNonNullElseGet(b.readNbt(), CompoundTag::new),
        b.readInt());
  }

  public static boolean allowed(ServerPlayer p) {
    return p != null
        && p.isAlive()
        && p.isCreative()
        && !p.isSpectator()
        && (p.getMainHandItem().getItem() instanceof DebuggerToolItem
            || p.getOffhandItem().getItem() instanceof DebuggerToolItem);
  }

  public static void handle(RemoteObjectPacket m, Supplier<NetworkEvent.Context> s) {
    var c = s.get();
    if (c.getDirection() == NetworkDirection.PLAY_TO_SERVER)
      c.enqueueWork(
          () -> {
            var p = c.getSender();
            if (!allowed(p) || m.action < 0 || m.action > 4) return;
            if (PENDING.containsKey(p.getUUID())) {
              p.sendSystemMessage(
                  Component.literal("Debugger: wait for the previous remote request."));
              return;
            }
            long now = p.server.overworld().getGameTime();
            if (now - LAST.getOrDefault(p.getUUID(), -1000L) < 5) return;
            LAST.put(p.getUUID(), now);
            var found =
                MechanismCatalog.get(p.server).query(m.id).stream()
                    .filter(e -> e.id().equals(m.id))
                    .findFirst();
            if (found.isEmpty()) {
              p.sendSystemMessage(
                  Component.literal("Debugger: object no longer exists in catalog."));
              return;
            }
            var e = found.get();
            var l =
                p.server.getLevel(
                    ResourceKey.create(Registries.DIMENSION, new ResourceLocation(e.dimension())));
            if (l == null || !l.mayInteract(p, e.pos())) {
              p.sendSystemMessage(
                  Component.literal("Debugger: object is protected or dimension unavailable."));
              return;
            }
            l.getChunkSource().addRegionTicket(TICKET, new ChunkPos(e.pos()), 3, p.getUUID());
            l.getChunkAt(e.pos());
            PENDING.put(p.getUUID(), new Pending(p, l, e, m, p.server.getTickCount() + 100));
          });
    c.setPacketHandled(true);
  }

  @SubscribeEvent
  public static void tick(TickEvent.ServerTickEvent e) {
    if (e.phase != TickEvent.Phase.END) return;
    var it = PENDING.entrySet().iterator();
    while (it.hasNext()) {
      var q = it.next().getValue();
      boolean finish = false;
      try {
        if (!allowed(q.player) || q.player.hasDisconnected()) finish = true;
        else if (q.entry.id().startsWith("entity:")) {
          var entity = q.level.getEntity(UUID.fromString(q.entry.id().substring(7)));
          if (entity instanceof MechanismEntity obj) {
            editEntity(q, obj);
            finish = true;
          }
        } else {
          editLadder(q);
          finish = true;
        }
        if (!finish && q.player.server.getTickCount() > q.deadline) {
          q.player.sendSystemMessage(
              Component.literal("Debugger: object could not be loaded; refresh list."));
          finish = true;
        }
      } catch (RuntimeException ex) {
        q.player.sendSystemMessage(Component.literal("Debugger: " + ex.getMessage()));
        finish = true;
      }
      if (finish) {
        q.level
            .getChunkSource()
            .removeRegionTicket(TICKET, new ChunkPos(q.entry.pos()), 3, q.player.getUUID());
        it.remove();
      }
    }
  }

  @SubscribeEvent
  public static void stopped(net.minecraftforge.event.server.ServerStoppedEvent e) {
    PENDING.clear();
    LAST.clear();
  }

  private static void reply(Pending q, String kind, CompoundTag t, int revision) {
    ClimberMod.PACKET_HANDLER.send(
        PacketDistributor.PLAYER.with(() -> q.player),
        new RemoteObjectReply(q.entry.id(), q.entry.dimension(), q.entry.pos(), kind, t, revision));
  }

  private static void editEntity(Pending q, MechanismEntity obj) {
    var m = q.request;
    if (obj.isChild() || !q.level.mayInteract(q.player, obj.blockPosition()))
      throw new IllegalArgumentException("Object not editable");
    int revision = obj.spec().save().hashCode();
    if (m.action == 0) {
      reply(q, obj.spec().kind.name(), obj.spec().save(), revision);
      return;
    }
    if (revision != m.revision)
      throw new IllegalArgumentException("Object changed since opened; reopen it before saving.");
    if (m.action == 1) RemoteAuthoring.save(q.player, obj, m.tag, m.revision);
    else if (m.action == 2) obj.removeWithChildren();
    else if (m.action == 3) obj.trigger();
    q.player.sendSystemMessage(Component.literal("Debugger: remote object updated."));
    if (m.action == 1)
      reply(q, obj.spec().kind.name(), obj.spec().save(), obj.spec().save().hashCode());
  }

  private static void editLadder(Pending q) {
    var b = q.entry.pos();
    var state = q.level.getBlockState(b);
    if (!(state.getBlock() instanceof MechanicalLadderBlock)
        || !(q.level.getBlockEntity(b) instanceof MechanicalLadderBlockEntity be))
      throw new IllegalArgumentException("Ladder no longer exists");
    int rev = state.toString().hashCode();
    if (q.request.action != 0)
      for (int y = -64; y <= 32; y++) {
        var check = b.offset(0, y, 0);
        if (check.getY() >= q.level.getMinBuildHeight()
            && check.getY() < q.level.getMaxBuildHeight()
            && !q.level.mayInteract(q.player, check))
          throw new IllegalArgumentException("Ladder chain crosses protected area");
      }
    if (q.request.action != 0) {
      if (rev != q.request.revision)
        throw new IllegalArgumentException("Ladder changed; reopen it");
      if (q.request.action == 2) {
        be.retract();
        q.level.destroyBlock(b, true);
        return;
      }
      if (q.request.action == 3) be.deploy();
      if (q.request.action == 4) be.retract();
    }
    CompoundTag t = new CompoundTag();
    t.putInt("layers", q.level.getBlockState(b).getValue(MechanicalLadderBlock.LAYERS));
    t.putBoolean("deployed", q.level.getBlockState(b).getValue(MechanicalLadderBlock.DEPLOYED));
    reply(q, "LADDER", t, q.level.getBlockState(b).toString().hashCode());
  }
}
