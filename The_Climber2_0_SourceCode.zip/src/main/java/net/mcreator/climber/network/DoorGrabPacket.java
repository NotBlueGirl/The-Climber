package net.mcreator.climber.network;

import net.mcreator.climber.door.DoorGrabManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class DoorGrabPacket {
    private final BlockPos pos;
    private final boolean grab;

    public DoorGrabPacket(BlockPos pos, boolean grab) {
        this.pos = pos;
        this.grab = grab;
    }

    public static void encode(DoorGrabPacket msg, FriendlyByteBuf buf) {
        buf.writeBlockPos(msg.pos);
        buf.writeBoolean(msg.grab);
    }

    public static DoorGrabPacket decode(FriendlyByteBuf buf) {
        return new DoorGrabPacket(buf.readBlockPos(), buf.readBoolean());
    }

    public static void handle(DoorGrabPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            if (msg.grab) {
                if (player.level().isLoaded(msg.pos)) DoorGrabManager.start(player, msg.pos);
            }
            else DoorGrabManager.release(player);
        });
        ctx.get().setPacketHandled(true);
    }
}