package net.mcreator.climber.network;

import net.mcreator.climber.door.DoorGrabManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: the local player is walking into a door (intended horizontal velocity). */
public class DoorPushPacket {
    private final BlockPos pos;
    private final float wishX, wishZ;

    public DoorPushPacket(BlockPos pos, float wishX, float wishZ) {
        this.pos = pos; this.wishX = wishX; this.wishZ = wishZ;
    }

    public static void encode(DoorPushPacket msg, FriendlyByteBuf buf) {
        buf.writeBlockPos(msg.pos);
        buf.writeFloat(msg.wishX);
        buf.writeFloat(msg.wishZ);
    }

    public static DoorPushPacket decode(FriendlyByteBuf buf) {
        return new DoorPushPacket(buf.readBlockPos(), buf.readFloat(), buf.readFloat());
    }

    public static void handle(DoorPushPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null || !Float.isFinite(msg.wishX) || !Float.isFinite(msg.wishZ)) return;
            if (!player.level().isLoaded(msg.pos)) return;
            DoorGrabManager.push(player, msg.pos, msg.wishX, msg.wishZ);
        });
        ctx.get().setPacketHandled(true);
    }
}
