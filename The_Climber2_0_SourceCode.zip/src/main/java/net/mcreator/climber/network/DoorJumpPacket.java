package net.mcreator.climber.network;

import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.door.DoorGrabManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class DoorJumpPacket {

    public DoorJumpPacket() {
    }

    public static void encode(DoorJumpPacket msg, FriendlyByteBuf buf) {
    }

    public static DoorJumpPacket decode(FriendlyByteBuf buf) {
        return new DoorJumpPacket();
    }

    public static void handle(DoorJumpPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            DoorGrabManager.release(player);

            Vec3 look = player.getLookAngle();
            float strength = ClimberConfig.INSTANCE.getStrengthJumpOneHand();

            Vec3 impulse = new Vec3(look.x, look.y + 0.3D, look.z)
                .normalize()
                .scale(strength);

            player.setDeltaMovement(impulse);
            player.setNoGravity(false);
            player.fallDistance = 0.0F;
        });

        ctx.get().setPacketHandled(true);
    }
}