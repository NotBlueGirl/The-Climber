package net.mcreator.climber.network;

import net.mcreator.climber.ClimberConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: current gameplay settings (shown and edited in the settings screen). */
public class ConfigSyncPacket {
    private final CompoundTag tag;
    private final boolean canEdit;

    public ConfigSyncPacket(CompoundTag tag, boolean canEdit) {
        this.tag = tag;
        this.canEdit = canEdit;
    }

    public static void encode(ConfigSyncPacket m, FriendlyByteBuf buf) {
        buf.writeNbt(m.tag);
        buf.writeBoolean(m.canEdit);
    }

    public static ConfigSyncPacket decode(FriendlyByteBuf buf) {
        CompoundTag t = buf.readNbt();
        return new ConfigSyncPacket(t == null ? new CompoundTag() : t, buf.readBoolean());
    }

    /** Last permission flag received from the server (client side). */
    public static volatile boolean clientCanEdit = true;
    public static volatile long clientRevision;

    public static void handle(ConfigSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            if (!c.getDirection().getReceptionSide().isClient()) return;
            // In single player this is the same object the integrated server uses: harmless, same values.
            ClimberConfig.INSTANCE.applySyncTag(m.tag);
            clientCanEdit = m.canEdit;
            clientRevision++;
        });
        c.setPacketHandled(true);
    }
}
