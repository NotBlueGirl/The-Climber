package net.mcreator.climber.network;

import net.mcreator.climber.client.ClimberClientData;
import net.mcreator.climber.grip.AutoGripMode;
import net.mcreator.climber.grip.GripMode;

import net.minecraft.network.FriendlyByteBuf;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Синхронизирует текущий серверный {@link GripMode} и {@link AutoGripMode} с клиентом —
 * нужен, чтобы клиент знал, доступен ли auto-grip и в каком режиме, а также для
 * отображения текущего режима в интерфейсе/сообщениях.
 */
public class GripModeSyncPacket {

    private final GripMode gripMode;
    private final AutoGripMode autoGripMode;

    public GripModeSyncPacket(GripMode gripMode, AutoGripMode autoGripMode) {
        this.gripMode = gripMode;
        this.autoGripMode = autoGripMode;
    }

    public static void encode(GripModeSyncPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.gripMode.ordinal());
        buf.writeByte(msg.autoGripMode.ordinal());
    }

    public static GripModeSyncPacket decode(FriendlyByteBuf buf) {
        GripMode gm = GripMode.values()[buf.readByte()];
        AutoGripMode agm = AutoGripMode.values()[buf.readByte()];
        return new GripModeSyncPacket(gm, agm);
    }

    public static void handle(GripModeSyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
                ClimberClientData.gripModeRealistic = (msg.gripMode == GripMode.REALISTIC);
                ClimberClientData.autoGripMode = msg.autoGripMode;
            })
        );
        ctx.get().setPacketHandled(true);
    }
}
