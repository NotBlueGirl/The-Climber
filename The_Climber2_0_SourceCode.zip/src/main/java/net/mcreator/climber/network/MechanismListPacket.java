package net.mcreator.climber.network;

import java.util.*;
import java.util.function.Supplier;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.item.DebuggerToolItem;
import net.mcreator.climber.mechanism.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.*;

public final class MechanismListPacket {
  public record Request(int request, String search, int page, int size) {
    public static void encode(Request m, FriendlyByteBuf b) {
      b.writeInt(m.request);
      b.writeUtf(m.search, 80);
      b.writeVarInt(m.page);
      b.writeVarInt(m.size);
    }

    public static Request decode(FriendlyByteBuf b) {
      return new Request(b.readInt(), b.readUtf(80), b.readVarInt(), b.readVarInt());
    }

    public static void handle(Request m, Supplier<NetworkEvent.Context> supplier) {
      var c = supplier.get();
      if (c.getDirection() != NetworkDirection.PLAY_TO_SERVER) {
        c.setPacketHandled(true);
        return;
      }
      c.enqueueWork(
          () -> {
            var p = c.getSender();
            if (p == null
                || !p.isCreative()
                || p.isSpectator()
                || !(p.getMainHandItem().getItem() instanceof DebuggerToolItem
                    || p.getOffhandItem().getItem() instanceof DebuggerToolItem)) return;
            var catalog = MechanismCatalog.get(p.server);
            for (var l : p.server.getAllLevels())
              for (var e : l.getAllEntities())
                if (e instanceof MechanismEntity mechanism) catalog.track(mechanism);
            var all = catalog.query(m.search);
            int size = Math.max(3, Math.min(12, m.size)),
                page = Math.max(0, Math.min(Math.max(0, (all.size() - 1) / size), m.page));
            List<CompoundTag> rows = new ArrayList<>();
            for (int i = page * size; i < Math.min(all.size(), (page + 1) * size); i++) {
              var entry = all.get(i);
              var tag = entry.save();
              var level =
                  p.server.getLevel(
                      ResourceKey.create(
                          Registries.DIMENSION, new ResourceLocation(entry.dimension())));
              boolean loaded = false;
              int id = -1;
              if (level != null) {
                if (entry.id().startsWith("entity:")) {
                  var entity = level.getEntity(UUID.fromString(entry.id().substring(7)));
                  loaded = entity != null;
                  if (entity != null && level == p.serverLevel()) id = entity.getId();
                } else loaded = level.hasChunkAt(entry.pos());
              }
              tag.putBoolean("loaded", loaded);
              tag.putInt("entityId", id);
              rows.add(tag);
            }
            ClimberMod.PACKET_HANDLER.send(
                PacketDistributor.PLAYER.with(() -> p),
                new Response(m.request, page, all.size(), rows));
          });
      c.setPacketHandled(true);
    }
  }

  public record Response(int request, int page, int total, List<CompoundTag> rows) {
    public static void encode(Response m, FriendlyByteBuf b) {
      b.writeInt(m.request);
      b.writeVarInt(m.page);
      b.writeVarInt(m.total);
      b.writeVarInt(m.rows.size());
      m.rows.forEach(b::writeNbt);
    }

    public static Response decode(FriendlyByteBuf b) {
      int request = b.readInt(),
          page = b.readVarInt(),
          total = b.readVarInt(),
          count = b.readVarInt();
      if (count < 0 || count > 12) throw new IllegalArgumentException("Object page limit");
      List<CompoundTag> rows = new ArrayList<>();
      for (int i = 0; i < count; i++) {
        var t = b.readNbt();
        rows.add(t == null ? new CompoundTag() : t);
      }
      return new Response(request, page, total, rows);
    }

    public static void handle(Response m, Supplier<NetworkEvent.Context> supplier) {
      var c = supplier.get();
      if (c.getDirection() == NetworkDirection.PLAY_TO_CLIENT)
        c.enqueueWork(
            () ->
                DistExecutor.unsafeRunWhenOn(
                    Dist.CLIENT,
                    () ->
                        () ->
                            net.mcreator.climber.client.screens.MechanismObjectScreen.receive(m)));
      c.setPacketHandled(true);
    }
  }
}
