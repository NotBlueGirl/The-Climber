package net.mcreator.climber.network;

import java.util.function.Supplier;
import net.mcreator.climber.capability.ClimbCapability;
import net.mcreator.climber.mechanism.*;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.*;

/** Desired horizontal swing direction, never a client-authored rope position or velocity. */
public record RopeSwingPacket(float x, float z, boolean sprint) {
  public static void encode(RopeSwingPacket m, FriendlyByteBuf b) {
    b.writeFloat(m.x);
    b.writeFloat(m.z);
    b.writeBoolean(m.sprint);
  }

  public static RopeSwingPacket decode(FriendlyByteBuf b) {
    return new RopeSwingPacket(b.readFloat(), b.readFloat(), b.readBoolean());
  }

  public static void handle(RopeSwingPacket m, Supplier<NetworkEvent.Context> supplier) {
    var c = supplier.get();
    if (c.getDirection() == NetworkDirection.PLAY_TO_SERVER)
      c.enqueueWork(
          () -> {
            var p = c.getSender();
            if (p == null
                || !p.isAlive()
                || p.isSpectator()
                || !Float.isFinite(m.x)
                || !Float.isFinite(m.z)) return;
            Vec3 wish = new Vec3(m.x, 0, m.z);
            if (wish.lengthSqr() > 1) wish = wish.normalize();
            final Vec3 input =
                wish.scale(
                    (m.sprint ? .045 : .027)
                        * net.mcreator.climber.ClimberConfig.INSTANCE
                            .gameplay()
                            .number("RopeSwingStrenght"));
            ClimbCapability.get(p)
                .ifPresent(
                    d -> {
                      if (!d.isClimbEnabled()) return;
                      for (int id :
                          new int[] {
                            d.isRightHandGrabbing() ? d.getRightHoldEntity() : -1,
                            d.isLeftHandGrabbing() ? d.getLeftHoldEntity() : -1
                          })
                        if (p.level().getEntity(id) instanceof MechanismEntity rope
                            && rope.spec().kind == MechanismSpec.Kind.ROPE)
                          rope.swingInput(p, input);
                    });
          });
    c.setPacketHandled(true);
  }
}
