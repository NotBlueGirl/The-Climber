package net.mcreator.climber.network;

import net.mcreator.climber.animation.AnimationServer;
import net.mcreator.climber.animation.RigAnimation;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/** Client may request input triggers; only server operators may publish or force preview. */
public record AnimationRequestPacket(int action, String text, int key) {
    public static final int INPUT = 0, PUBLISH = 1, PLAY = 2, STOP = 3, RELEASE = 4;
    public static void encode(AnimationRequestPacket m, FriendlyByteBuf b) { b.writeVarInt(m.action); b.writeUtf(m.text, RigAnimation.MAX_JSON); b.writeInt(m.key); }
    public static AnimationRequestPacket decode(FriendlyByteBuf b) { return new AnimationRequestPacket(b.readVarInt(), b.readUtf(RigAnimation.MAX_JSON), b.readInt()); }
    public static void handle(AnimationRequestPacket m, Supplier<NetworkEvent.Context> supplier) {
        var c = supplier.get();
        if (c.getDirection() != NetworkDirection.PLAY_TO_SERVER) { c.setPacketHandled(true); return; }
        c.enqueueWork(() -> { var p = c.getSender(); if (p != null) AnimationServer.request(p, m); }); c.setPacketHandled(true);
    }
}
