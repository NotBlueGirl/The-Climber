package net.mcreator.climber.network;

import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.*;

public record RemoteObjectReply(
    String id, String dimension, BlockPos pos, String kind, CompoundTag tag, int revision) {
  public static void encode(RemoteObjectReply m, FriendlyByteBuf b) {
    b.writeUtf(m.id, 180);
    b.writeUtf(m.dimension, 180);
    b.writeBlockPos(m.pos);
    b.writeUtf(m.kind, 24);
    b.writeNbt(m.tag);
    b.writeInt(m.revision);
  }

  public static RemoteObjectReply decode(FriendlyByteBuf b) {
    return new RemoteObjectReply(
        b.readUtf(180), b.readUtf(180), b.readBlockPos(), b.readUtf(24), b.readNbt(), b.readInt());
  }

  public static void handle(RemoteObjectReply m, Supplier<NetworkEvent.Context> s) {
    var c = s.get();
    if (c.getDirection() == NetworkDirection.PLAY_TO_CLIENT)
      c.enqueueWork(
          () ->
              DistExecutor.unsafeRunWhenOn(
                  Dist.CLIENT,
                  () -> () -> net.mcreator.climber.client.screens.RemoteObjectScreen.open(m)));
    c.setPacketHandled(true);
  }
}
