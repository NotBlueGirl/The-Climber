package net.mcreator.climber.network;

import net.mcreator.climber.mechanism.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;

/**
 * Remote authoring validation is independent of distance, but never of permissions or revisions.
 */
public final class RemoteAuthoring {
  private RemoteAuthoring() {}

  public static int revision(MechanismEntity obj) {
    return obj.spec().save().hashCode();
  }

  public static void save(ServerPlayer player, MechanismEntity obj, CompoundTag tag, int revision) {
    if (!RemoteObjectPacket.allowed(player)
        || obj.isChild()
        || !obj.isAlive()
        || !obj.level().mayInteract(player, obj.blockPosition()))
      throw new IllegalArgumentException("Object not editable");
    if (revision(obj) != revision)
      throw new IllegalArgumentException("Object changed since opened; reopen it before saving.");
    var spec = MechanismSpec.load(tag);
    spec.validate();
    if (spec.valveTarget != null
        && (spec.valveTarget.distSqr(obj.attachedBlock()) > 64 * 64
            || !obj.level().mayInteract(player, spec.valveTarget)))
      throw new IllegalArgumentException("Valve target protected or outside 64 blocks");
    for (var p : spec.railBlocks)
      if (!obj.level().mayInteract(player, p))
        throw new IllegalArgumentException("Route includes a protected block");
    obj.reconfigure(spec);
  }
}
