package net.mcreator.climber.network;

import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.capability.ClimbCapability;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

/** Client -> server: the settings screen changed gameplay settings. Needs op (or single player host). */
public class ConfigUpdatePacket {
    private final CompoundTag tag;

    public ConfigUpdatePacket(CompoundTag tag) {
        this.tag = tag;
    }

    public static void encode(ConfigUpdatePacket m, FriendlyByteBuf buf) {
        buf.writeNbt(m.tag);
    }

    public static ConfigUpdatePacket decode(FriendlyByteBuf buf) {
        CompoundTag t = buf.readNbt();
        return new ConfigUpdatePacket(t == null ? new CompoundTag() : t);
    }

    public static boolean canEdit(ServerPlayer sp) {
        return sp.hasPermissions(2) || sp.server.isSingleplayerOwner(sp.getGameProfile());
    }

    public static void handle(ConfigUpdatePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        if (c.getDirection() != net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER) { c.setPacketHandled(true); return; }
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp == null) return;
            if (!canEdit(sp)) {
                sp.displayClientMessage(Component.literal("§cOnly operators can change the Climber server settings."), false);
                sendTo(sp);
                return;
            }
            try { net.mcreator.climber.config.ConfigValidation.validate(m.tag, true); }
            catch (RuntimeException e) {
                sp.sendSystemMessage(Component.literal("Climber settings rejected: " + e.getMessage())); sendTo(sp); return;
            }
            boolean staminaBefore = ClimberConfig.INSTANCE.isStaminaEnabled();
            ClimberConfig.INSTANCE.applySyncTag(m.tag);
            ClimberConfig.INSTANCE.save();
            if (staminaBefore && !ClimberConfig.INSTANCE.isStaminaEnabled()) restoreStamina(sp.server);
            broadcast(sp.server);
        });
        c.setPacketHandled(true);
    }

    private static void restoreStamina(MinecraftServer server) {
        float max = ClimberConfig.INSTANCE.getStaminaMax();
        server.getPlayerList().getPlayers().forEach(p -> ClimbCapability.get(p).ifPresent(data -> {
            data.setRightStamina(max);
            data.setLeftStamina(max);
            data.setRightExhausted(false);
            data.setLeftExhausted(false);
            ClimberMod.PACKET_HANDLER.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p),
                    new StaminaSyncPacket(p.getUUID(), max, max, false, false));
        }));
    }

    public static void sendTo(ServerPlayer sp) {
        ClimberMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> sp),
                new ConfigSyncPacket(ClimberConfig.INSTANCE.toSyncTag(), canEdit(sp)));
        ClimberMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> sp),
                new GripModeSyncPacket(ClimberConfig.INSTANCE.getGripMode(), ClimberConfig.INSTANCE.getAutoGripMode()));
    }

    public static void broadcast(MinecraftServer server) {
        server.getPlayerList().getPlayers().forEach(ConfigUpdatePacket::sendTo);
    }
}
