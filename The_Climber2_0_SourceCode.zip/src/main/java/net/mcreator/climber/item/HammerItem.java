package net.mcreator.climber.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import java.util.List;
import net.mcreator.climber.entity.PitonEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Hammer: hammers pitons (3 hits = permanent hold), is a solid melee weapon and smashes wooden
 * planks fast. Unbreakable, like in White Knuckle.
 *
 * <ul>
 *   <li>Left click a piton (climbing off) or right click it (any mode) to hammer it.
 *   <li>Right click while climbing swings the hammer at whatever is in front of you.
 * </ul>
 */
public class HammerItem extends Item implements ClimberTool {

  public static final double STRIKE_RANGE = 3.2;
  private final Multimap<Attribute, AttributeModifier> modifiers;

  public HammerItem(Properties props) {
    super(props);
    ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
    b.put(
        Attributes.ATTACK_DAMAGE,
        new AttributeModifier(
            BASE_ATTACK_DAMAGE_UUID, "Hammer damage", 5.0, AttributeModifier.Operation.ADDITION));
    b.put(
        Attributes.ATTACK_SPEED,
        new AttributeModifier(
            BASE_ATTACK_SPEED_UUID, "Hammer speed", -2.6, AttributeModifier.Operation.ADDITION));
    this.modifiers = b.build();
  }

  @Override
  @SuppressWarnings("deprecation")
  public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
    return slot == EquipmentSlot.MAINHAND ? modifiers : super.getDefaultAttributeModifiers(slot);
  }

  @Override
  public float getDestroySpeed(ItemStack stack, BlockState state) {
    if (state.is(BlockTags.PLANKS)
        || state.is(BlockTags.WOODEN_SLABS)
        || state.is(BlockTags.WOODEN_STAIRS)
        || state.is(BlockTags.WOODEN_FENCES)
        || state.is(BlockTags.WOODEN_TRAPDOORS)) {
      return 8.0f;
    }
    return 1.0f;
  }

  @Override
  public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
    return true; // unbreakable
  }

  /** Hold RMB this long, then release, for a charged (heavy) swing - like in White Knuckle. */
  public static final int CHARGE_TICKS = 14;

  /**
   * Right click: quick click = normal swing at the piton / creature in front of you. Hold and
   * release = charged swing: 3x damage and it secures a piton in one hit.
   */
  @Override
  public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
    ItemStack stack = player.getItemInHand(hand);
    player.startUsingItem(hand);
    return InteractionResultHolder.consume(stack);
  }

  @Override
  public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remaining) {
    if (!level.isClientSide() && getUseDuration(stack) - remaining == CHARGE_TICKS) {
      level.playSound(
          null,
          user.getX(),
          user.getY(),
          user.getZ(),
          net.minecraft.sounds.SoundEvents.CROSSBOW_LOADING_END,
          net.minecraft.sounds.SoundSource.PLAYERS,
          0.5f,
          0.6f);
    }
  }

  @Override
  public void releaseUsing(ItemStack stack, Level level, LivingEntity user, int remaining) {
    if (!(user instanceof Player player)) return;
    boolean heavy = getUseDuration(stack) - remaining >= CHARGE_TICKS;
    InteractionHand usedHand = player.getUsedItemHand();
    player.swing(usedHand, true);
    if (!level.isClientSide()) {
      Entity target = findTarget(level, player);
      if (target instanceof PitonEntity piton) {
        if (heavy) piton.secure(player);
        else piton.hammer(player);
      } else if (target instanceof LivingEntity le) {
        if (usedHand == InteractionHand.MAIN_HAND) player.attack(target);
        else le.hurt(player.damageSources().playerAttack(player), 6f);
        if (heavy) {
          // two extra hits worth of damage on top of the normal one = 3x
          le.invulnerableTime = 0;
          float base =
              usedHand == InteractionHand.MAIN_HAND
                  ? (float) player.getAttributeValue(Attributes.ATTACK_DAMAGE)
                  : 6f;
          le.hurt(player.damageSources().playerAttack(player), base * 2f);
          Vec3 k = player.getLookAngle();
          le.knockback(0.8, -k.x, -k.z);
        }
      }
      if (heavy) {
        level.playSound(
            null,
            player.getX(),
            player.getY(),
            player.getZ(),
            net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_STRONG,
            net.minecraft.sounds.SoundSource.PLAYERS,
            1.0f,
            0.7f);
      }
    }
    player.getCooldowns().addCooldown(this, heavy ? 12 : 8);
  }

  @Override
  public int getUseDuration(ItemStack stack) {
    return 72000;
  }

  @Override
  public net.minecraft.world.item.UseAnim getUseAnimation(ItemStack stack) {
    return net.minecraft.world.item.UseAnim.SPEAR; // raise the hammer while charging
  }

  @Nullable
  public static Entity findTarget(Level level, Player player) {
    Vec3 eye = player.getEyePosition();
    Vec3 end = eye.add(player.getLookAngle().scale(STRIKE_RANGE));
    BlockHitResult block =
        level.clip(
            new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
    if (block.getType() != HitResult.Type.MISS) end = block.getLocation();
    AABB area = player.getBoundingBox().expandTowards(end.subtract(eye)).inflate(1.0);
    EntityHitResult hit =
        ProjectileUtil.getEntityHitResult(
            level,
            player,
            eye,
            end,
            area,
            e ->
                e != player
                    && !e.isSpectator()
                    && (e instanceof PitonEntity || (e instanceof LivingEntity && e.isPickable())));
    return hit != null ? hit.getEntity() : null;
  }

  @Override
  public void appendHoverText(
      ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
    tip.add(Component.translatable("item.climber.hammer.desc").withStyle(ChatFormatting.GRAY));
  }
}
