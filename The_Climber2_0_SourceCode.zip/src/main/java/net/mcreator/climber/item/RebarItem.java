package net.mcreator.climber.item;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.capability.ClimbCapability;
import net.mcreator.climber.entity.RebarEntity;
import net.mcreator.climber.network.AnchorSyncPacket;
import net.mcreator.climber.network.ClimbStatePacket;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Rebar: thrown hard, sticks into any surface and becomes a handhold. Shallow throws ricochet.
 * Throwing knocks the climber back (rebar jumps) and makes them let go.
 */
public class RebarItem extends Item implements ClimberTool {

    public static final float THROW_SPEED = 2.6f;
    /** Recoil pushed onto the thrower (2.5x the first version). */
    public static final double RECOIL = 1.05;

    public RebarItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide()) {
            RebarEntity rebar = new RebarEntity(level, player);
            rebar.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, THROW_SPEED, 0.35f);
            level.addFreshEntity(rebar);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 1.0f, 0.75f);

            // recoil + lose grip
            Vec3 look = player.getLookAngle();
            // a big shove backwards (a bit of lift so it is not eaten by ground friction)
            player.push(-look.x * RECOIL, -look.y * RECOIL * 0.8 + 0.12, -look.z * RECOIL);
            player.hurtMarked = true;
            player.fallDistance = 0;
            if (player instanceof ServerPlayer sp) releaseGrip(sp);

            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.awardStat(Stats.ITEM_USED.get(this));
        }
        player.getCooldowns().addCooldown(this, 12);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private static void releaseGrip(ServerPlayer sp) {
        ClimbCapability.get(sp).ifPresent(data -> {
            if (!data.isRightHandGrabbing() && !data.isLeftHandGrabbing()) return;
            data.setRightHandGrabbing(false);
            data.setLeftHandGrabbing(false);
            data.setRightAnchor(null);
            data.setLeftAnchor(null);
            data.setRightHoldEntity(-1);
            data.setLeftHoldEntity(-1);
            sp.setNoGravity(false);
            ClimberMod.PACKET_HANDLER.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
                    new AnchorSyncPacket(sp.getUUID(), null, null));
            ClimberMod.PACKET_HANDLER.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
                    new ClimbStatePacket(sp.getUUID(), data.isClimbEnabled(), false, false));
        });
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("item.climber.rebar.desc").withStyle(ChatFormatting.GRAY));
    }
}
