package net.mcreator.climber.item;

import net.mcreator.climber.entity.PitonEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Piton: use on any solid surface to drive in an (unstable) handhold. Hammer it 3x to make it permanent. */
public class PitonItem extends Item implements ClimberTool {

    public PitonItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        Direction face = ctx.getClickedFace();
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof DoorBlock || state.getCollisionShape(level, pos).isEmpty()) {
            return InteractionResult.FAIL;
        }
        Vec3 hit = ctx.getClickLocation();
        if (!level.getEntitiesOfClass(PitonEntity.class, new AABB(hit, hit).inflate(0.3)).isEmpty()) {
            return InteractionResult.FAIL; // already a piton here
        }
        if (!level.isClientSide()) {
            PitonEntity piton = PitonEntity.create(level, hit, face, pos);
            level.addFreshEntity(piton);
            level.playSound(null, hit.x, hit.y, hit.z, SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 1.0f, 0.8f);
            if (ctx.getPlayer() != null) {
                if (!ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
                ctx.getPlayer().getCooldowns().addCooldown(this, 6);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("item.climber.piton.desc").withStyle(ChatFormatting.GRAY));
    }
}
