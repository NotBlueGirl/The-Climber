package net.mcreator.climber.item;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Crank flashlight. Lights up whatever you point it at while held (see FlashlightEvents) and slowly
 * drains. Hold RMB to wind the crank and recharge it. Sneak + RMB switches it on/off.
 */
public class CrankFlashlightItem extends Item implements ClimberTool {
  // White Knuckle numbers (whiteknuckle.miraheze.org/wiki/Flashlight): the first crank charges it
  // for
  // 32 s, every further crank adds 10 s, up to ~78 s. Brightness follows the charge.
  public static final int FIRST_CRANK = 32 * 20;
  public static final int PER_CRANK = 10 * 20;
  public static final int MAX_CHARGE = 78 * 20;

  /** Length of one crank (lever swings out and back). */
  public static final int CRANK_TICKS = 10;

  public static int maxCharge() {
    return Math.max(
        1,
        (int)
            Math.round(
                net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("MaxTimeCrackLight")
                    * 20));
  }

  public static int crankRegen() {
    return Math.max(
        0,
        (int)
            Math.round(
                net.mcreator.climber.ClimberConfig.INSTANCE.gameplay().number("ClickCrankRegen")
                    * 20));
  }

  public CrankFlashlightItem(Properties props) {
    super(props);
  }

  /** A new flashlight is empty - crank it first. */
  public static int getCharge(ItemStack s) {
    return s.hasTag() && s.getTag().contains("Charge")
        ? Mth.clamp(s.getTag().getInt("Charge"), 0, maxCharge())
        : 0;
  }

  public static void setCharge(ItemStack s, int c) {
    s.getOrCreateTag().putInt("Charge", Mth.clamp(c, 0, maxCharge()));
  }

  /** Kept for compatibility with older stacks; the WK flashlight has no switch. */
  public static boolean isOn(ItemStack s) {
    return true;
  }

  public static boolean isShining(ItemStack s) {
    return s.getItem() instanceof CrankFlashlightItem && getCharge(s) > 0;
  }

  /**
   * Light level 0..15: very dim right after one crank from empty, brighter the more it is charged.
   */
  public static int brightness(int charge) {
    if (charge <= 0) return 0;
    float f = (float) charge / maxCharge();
    return Mth.clamp(Math.round(2f + 13f * f), 2, 15);
  }

  @Override
  public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
    ItemStack stack = player.getItemInHand(hand);
    if (!level.isClientSide()) {
      int c = getCharge(stack);
      setCharge(stack, c + crankRegen());
      level.playSound(
          null,
          player.getX(),
          player.getY(),
          player.getZ(),
          SoundEvents.CROSSBOW_LOADING_MIDDLE,
          SoundSource.PLAYERS,
          0.6f,
          0.75f);
      level.playSound(
          null,
          player.getX(),
          player.getY(),
          player.getZ(),
          SoundEvents.CROSSBOW_LOADING_END,
          SoundSource.PLAYERS,
          0.4f,
          1.4f);
      if (c + crankRegen() >= maxCharge()) {
        level.playSound(
            null,
            player.getX(),
            player.getY(),
            player.getZ(),
            SoundEvents.NOTE_BLOCK_HAT.get(),
            SoundSource.PLAYERS,
            0.6f,
            2.0f);
      }
    }
    player.getCooldowns().addCooldown(this, CRANK_TICKS);
    // consume = no vanilla arm swing (cranking is animated by the lever instead)
    return InteractionResultHolder.consume(stack);
  }

  /** Drains while it is anywhere in the inventory ("remains functional while in the inventory"). */
  @Override
  public void inventoryTick(
      ItemStack stack,
      Level level,
      net.minecraft.world.entity.Entity holder,
      int slot,
      boolean selected) {
    if (level.isClientSide() || !(holder instanceof Player p) || p.getAbilities().instabuild)
      return;
    int c = getCharge(stack);
    if (c <= 0) return;
    setCharge(stack, c - 1);
    if (c - 1 <= 0) {
      level.playSound(
          null,
          p.getX(),
          p.getY(),
          p.getZ(),
          SoundEvents.STONE_BUTTON_CLICK_OFF,
          SoundSource.PLAYERS,
          0.5f,
          0.6f);
    }
  }

  @Override
  public boolean shouldCauseReequipAnimation(
      ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
    return slotChanged || oldStack.getItem() != newStack.getItem(); // charge NBT changes every tick
  }

  @Override
  public boolean isBarVisible(ItemStack stack) {
    return true;
  }

  @Override
  public int getBarWidth(ItemStack stack) {
    return Math.round(13f * getCharge(stack) / maxCharge());
  }

  @Override
  public int getBarColor(ItemStack stack) {
    float f = (float) getCharge(stack) / maxCharge();
    return f > 0.2f ? 0xFFD21E : 0xFF5A1E;
  }

  @Override
  public void appendHoverText(
      ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
    int pct = Math.round(100f * getCharge(stack) / maxCharge());
    tip.add(
        Component.translatable("item.climber.crank_flashlight.charge", getCharge(stack) / 20, pct)
            .withStyle(ChatFormatting.YELLOW));
    tip.add(
        Component.translatable("item.climber.crank_flashlight.desc")
            .withStyle(ChatFormatting.GRAY));
  }
}
