package net.mcreator.climber.item;

import java.util.function.IntConsumer;
import net.mcreator.climber.mechanism.*;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Creative-only authoring tool. Client callback is installed solely by the client setup. */
public class DebuggerToolItem extends Item implements ClimberTool {
  public static IntConsumer OPEN = id -> {};

  public DebuggerToolItem(Properties p) {
    super(p);
  }

  public static MechanismSpec spec(ItemStack stack) {
    try {
      return MechanismSpec.load(stack.getOrCreateTag().getCompound("mechanism"));
    } catch (RuntimeException e) {
      return new MechanismSpec();
    }
  }

  @Override
  public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
    if (!p.isCreative()) return InteractionResultHolder.fail(p.getItemInHand(h));
    if (l.isClientSide()) OPEN.accept(-1);
    return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide());
  }

  @Override
  public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
    return useOn(
        context); // Place on doors/levers before their normal interaction consumes the click.
  }

  @Override
  public InteractionResult useOn(UseOnContext c) {
    Player p = c.getPlayer();
    if (p == null || !p.isCreative() || !c.getLevel().mayInteract(p, c.getClickedPos()))
      return InteractionResult.FAIL;
    if (p.isShiftKeyDown()) {
      if (c.getLevel().isClientSide()) OPEN.accept(-1);
      return InteractionResult.SUCCESS;
    }
    if (!c.getLevel().isClientSide()) {
      MechanismSpec s = spec(c.getItemInHand());
      if (s.kind == MechanismSpec.Kind.VALVE
          && s.valveTarget != null
          && (s.valveTarget.distSqr(c.getClickedPos()) > 64 * 64
              || !c.getLevel().hasChunkAt(s.valveTarget)
              || !c.getLevel().mayInteract(p, s.valveTarget))) {
        p.displayClientMessage(
            Component.literal("Valve target must be loaded, editable and within 64 blocks."), true);
        return InteractionResult.FAIL;
      }

      if (s.kind == MechanismSpec.Kind.PLATFORM && !s.railBlocks.isEmpty()) {
        if (!s.railBlocks.get(0).equals(c.getClickedPos())) {
          p.displayClientMessage(
              Component.literal("Place the platform on the FIRST selected rail block."), true);
          return InteractionResult.FAIL;
        }
        for (var b : s.railBlocks)
          if (!c.getLevel().hasChunkAt(b)
              || !c.getLevel().mayInteract(p, b)
              || c.getLevel().getBlockState(b).isAir()) {
            p.displayClientMessage(
                Component.literal("Selected rail blocks must be loaded, present and editable."),
                true);
            return InteractionResult.FAIL;
          }
      }
      if (s.kind == MechanismSpec.Kind.LADDER) {
        if (c.getLevel().getBlockState(c.getClickedPos()).getBlock()
            instanceof MechanicalLadderBlock) {
          return MechanicalLadderBlock.addLayer(c.getLevel(), c.getClickedPos())
              ? InteractionResult.SUCCESS
              : InteractionResult.FAIL;
        }
        var at = c.getClickedPos().relative(c.getClickedFace());
        if (c.getClickedFace().getAxis().isVertical()
            || !c.getLevel().getBlockState(at).canBeReplaced()) return InteractionResult.FAIL;
        var b =
            net.mcreator.climber.init.ClimberModBlocks.MECHANICAL_LADDER
                .get()
                .defaultBlockState()
                .setValue(net.minecraft.world.level.block.LadderBlock.FACING, c.getClickedFace());
        if (!b.canSurvive(c.getLevel(), at)) return InteractionResult.FAIL;
        c.getLevel().setBlockAndUpdate(at, b);
      } else {
        if ((s.kind == MechanismSpec.Kind.PLATFORM
                || s.kind == MechanismSpec.Kind.HOOK
                || s.kind == MechanismSpec.Kind.WEAK_HOOK
                || s.kind == MechanismSpec.Kind.VALVE)
            && c.getClickedFace().getAxis().isVertical()) {
          p.displayClientMessage(
              Component.literal("Place this mechanism on a vertical wall."), true);
          return InteractionResult.FAIL;
        }
        if (s.kind == MechanismSpec.Kind.ROPE && c.getClickedFace() != Direction.DOWN) {
          p.displayClientMessage(
              Component.literal("Place rope on the underside of a ceiling."), true);
          return InteractionResult.FAIL;
        }
        MechanismEntity.place(
            c.getLevel(), c.getClickLocation(), c.getClickedFace(), c.getClickedPos(), s);
      }
      p.getCooldowns().addCooldown(this, 6);
    }
    return InteractionResult.sidedSuccess(c.getLevel().isClientSide());
  }
}
