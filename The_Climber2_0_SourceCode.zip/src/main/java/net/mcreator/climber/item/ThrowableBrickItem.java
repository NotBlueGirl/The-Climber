package net.mcreator.climber.item;

import net.mcreator.climber.entity.ThrownBrickEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** White Knuckle style brick: throw it (RMB) to hit mobs and smash glass. Lands as an item you can pick up again. */
public class ThrowableBrickItem extends Item implements ClimberTool {
    public static final float THROW_SPEED = 1.35f;

    public ThrowableBrickItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.8f, 0.5f);
        if (!level.isClientSide()) {
            ThrownBrickEntity brick = new ThrownBrickEntity(level, player);
            ItemStack one = stack.copy();
            one.setCount(1);
            brick.setItem(one);
            brick.shootFromRotation(player, player.getXRot(), player.getYRot(), -4.0f, THROW_SPEED, 0.6f);
            level.addFreshEntity(brick);
            // slight recoil (much weaker than the rebar)
            Vec3 look = player.getLookAngle();
            player.push(-look.x * 0.22, -look.y * 0.12 + 0.03, -look.z * 0.22);
            player.hurtMarked = true;
        }
        player.awardStat(Stats.ITEM_USED.get(this));
        if (!player.getAbilities().instabuild) stack.shrink(1);
        player.getCooldowns().addCooldown(this, 8);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("item.climber.throwable_brick.desc").withStyle(ChatFormatting.GRAY));
    }
}
