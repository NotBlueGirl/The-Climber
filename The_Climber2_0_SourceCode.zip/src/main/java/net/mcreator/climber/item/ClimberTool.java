package net.mcreator.climber.item;

/** Marker: while climbing, the right mouse button USES this item instead of grabbing with the right hand. */
public interface ClimberTool {}
