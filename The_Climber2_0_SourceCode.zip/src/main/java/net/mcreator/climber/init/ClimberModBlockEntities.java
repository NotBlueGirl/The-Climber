package net.mcreator.climber.init;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.blockentity.DoorBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ClimberModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> REGISTRY =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ClimberMod.MODID);

    /**
     * BlockEntityType.Builder.of(...) требует явный список "валидных" блоков (varargs,
     * не может быть пустым) — но мы не можем перечислить заранее двери всех модов,
     * т.к. наш DoorEntityBlockMixin делает EntityBlock из ЛЮБОГО DoorBlock, включая
     * сторонние. Поэтому здесь передаём только ванильные двери как формальность для
     * конструктора, а реальная проверка "валиден ли этот блок для нашего типа" заменена
     * миксином BlockEntityTypeIsValidMixin, который проверяет instanceof DoorBlock
     * вместо поиска в этом списке.
     */
    public static final RegistryObject<BlockEntityType<DoorBlockEntity>> DOOR_ANIMATOR =
            REGISTRY.register("door_animator", () ->
                    BlockEntityType.Builder.of(
                            DoorBlockEntity::new,
                            net.minecraft.world.level.block.Blocks.OAK_DOOR,
                            net.minecraft.world.level.block.Blocks.IRON_DOOR,
                            net.minecraft.world.level.block.Blocks.SPRUCE_DOOR,
                            net.minecraft.world.level.block.Blocks.BIRCH_DOOR,
                            net.minecraft.world.level.block.Blocks.JUNGLE_DOOR,
                            net.minecraft.world.level.block.Blocks.ACACIA_DOOR,
                            net.minecraft.world.level.block.Blocks.DARK_OAK_DOOR,
                            net.minecraft.world.level.block.Blocks.CRIMSON_DOOR,
                            net.minecraft.world.level.block.Blocks.WARPED_DOOR,
                            net.minecraft.world.level.block.Blocks.MANGROVE_DOOR,
                            net.minecraft.world.level.block.Blocks.BAMBOO_DOOR,
                            net.minecraft.world.level.block.Blocks.CHERRY_DOOR
                    ).build(null));
}
