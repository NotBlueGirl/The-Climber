package net.mcreator.climber.init;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.mechanism.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.*;

public final class ClimberModBlocks {
  public static final DeferredRegister<Block> BLOCKS =
      DeferredRegister.create(ForgeRegistries.BLOCKS, ClimberMod.MODID);
  public static final DeferredRegister<BlockEntityType<?>> ENTITIES =
      DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ClimberMod.MODID);
  public static final RegistryObject<MechanicalLadderBlock> MECHANICAL_LADDER =
      BLOCKS.register(
          "mechanical_ladder",
          () ->
              new MechanicalLadderBlock(
                  BlockBehaviour.Properties.copy(Blocks.LADDER)
                      .strength(2)
                      .sound(SoundType.METAL)));
  public static final RegistryObject<BlockEntityType<MechanicalLadderBlockEntity>> LADDER_ENTITY =
      ENTITIES.register(
          "mechanical_ladder",
          () ->
              BlockEntityType.Builder.of(MechanicalLadderBlockEntity::new, MECHANICAL_LADDER.get())
                  .build(null));

  public static void register(IEventBus b) {
    BLOCKS.register(b);
    ENTITIES.register(b);
  }
}
