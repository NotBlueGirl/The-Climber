package net.mcreator.climber.init;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.item.CrankFlashlightItem;
import net.mcreator.climber.item.HammerItem;
import net.mcreator.climber.item.PitonItem;
import net.mcreator.climber.item.RebarItem;
import net.mcreator.climber.item.ThrowableBrickItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ClimberModItems {
  public static final DeferredRegister<Item> REGISTRY =
      DeferredRegister.create(ForgeRegistries.ITEMS, ClimberMod.MODID);

  public static final RegistryObject<Item> HAMMER =
      REGISTRY.register(
          "hammer",
          () -> new HammerItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));
  public static final RegistryObject<Item> PITON =
      REGISTRY.register("piton", () -> new PitonItem(new Item.Properties().stacksTo(16)));
  public static final RegistryObject<Item> REBAR =
      REGISTRY.register("rebar", () -> new RebarItem(new Item.Properties().stacksTo(8)));

  public static final RegistryObject<Item> THROWABLE_BRICK =
      REGISTRY.register(
          "throwable_brick", () -> new ThrowableBrickItem(new Item.Properties().stacksTo(16)));
  public static final RegistryObject<Item> CRANK_FLASHLIGHT =
      REGISTRY.register(
          "crank_flashlight", () -> new CrankFlashlightItem(new Item.Properties().stacksTo(1)));

  public static final RegistryObject<Item> DEBUGGER =
      REGISTRY.register(
          "debugger_tool",
          () ->
              new net.mcreator.climber.item.DebuggerToolItem(
                  new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
  public static final RegistryObject<Item> MECHANICAL_LADDER =
      REGISTRY.register(
          "mechanical_ladder",
          () ->
              new net.minecraft.world.item.BlockItem(
                  ClimberModBlocks.MECHANICAL_LADDER.get(), new Item.Properties()));

  public static void register(IEventBus modBus) {
    REGISTRY.register(modBus);
    modBus.addListener(ClimberModItems::onCreativeTabs);
  }

  private static void onCreativeTabs(BuildCreativeModeTabContentsEvent event) {
    if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
      event.accept(DEBUGGER);
      event.accept(MECHANICAL_LADDER);
      event.accept(HAMMER);
      event.accept(PITON);
      event.accept(REBAR);
      event.accept(THROWABLE_BRICK);
      event.accept(CRANK_FLASHLIGHT);
    } else if (event.getTabKey() == CreativeModeTabs.COMBAT) {
      event.accept(HAMMER);
      event.accept(REBAR);
      event.accept(THROWABLE_BRICK);
    }
  }
}
