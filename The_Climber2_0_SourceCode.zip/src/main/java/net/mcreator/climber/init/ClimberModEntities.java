package net.mcreator.climber.init;

import net.mcreator.climber.ClimberMod;
import net.mcreator.climber.entity.PitonEntity;
import net.mcreator.climber.entity.RebarEntity;
import net.mcreator.climber.entity.ThrownBrickEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ClimberModEntities {
  public static final DeferredRegister<EntityType<?>> REGISTRY =
      DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ClimberMod.MODID);

  public static final RegistryObject<EntityType<net.mcreator.climber.mechanism.MechanismEntity>>
      MECHANISM =
          REGISTRY.register(
              "mechanism",
              () ->
                  EntityType.Builder.<net.mcreator.climber.mechanism.MechanismEntity>of(
                          net.mcreator.climber.mechanism.MechanismEntity::new, MobCategory.MISC)
                      .sized(.55f, .3f)
                      .clientTrackingRange(12)
                      .updateInterval(1)
                      .fireImmune()
                      .build("mechanism"));

  public static final RegistryObject<EntityType<PitonEntity>> PITON =
      REGISTRY.register(
          "piton",
          () ->
              EntityType.Builder.<PitonEntity>of(PitonEntity::new, MobCategory.MISC)
                  .sized(0.3f, 0.3f)
                  .clientTrackingRange(10)
                  .updateInterval(20)
                  .fireImmune()
                  .build("piton"));

  public static final RegistryObject<EntityType<RebarEntity>> REBAR =
      REGISTRY.register(
          "rebar",
          () ->
              EntityType.Builder.<RebarEntity>of(RebarEntity::new, MobCategory.MISC)
                  .sized(0.25f, 0.25f)
                  .clientTrackingRange(8)
                  .updateInterval(20)
                  .build("rebar"));

  public static final RegistryObject<EntityType<ThrownBrickEntity>> THROWN_BRICK =
      REGISTRY.register(
          "thrown_brick",
          () ->
              EntityType.Builder.<ThrownBrickEntity>of(ThrownBrickEntity::new, MobCategory.MISC)
                  .sized(0.3f, 0.3f)
                  .clientTrackingRange(6)
                  .updateInterval(10)
                  .build("thrown_brick"));
}
