package net.mcreator.climber;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.mcreator.climber.capability.ClimbCapability;
import net.mcreator.climber.client.ClimberClientSetup;
import net.mcreator.climber.door.DoorEvents;
import net.mcreator.climber.event.ClimberServerEvents;
import net.mcreator.climber.init.ClimberModBlockEntities;
import net.mcreator.climber.init.ClimberModSounds;
import net.mcreator.climber.network.AnchorSyncPacket;
import net.mcreator.climber.network.ClimbJumpPacket;
import net.mcreator.climber.network.ClimbStatePacket;
import net.mcreator.climber.network.DoorAnglePacket;
import net.mcreator.climber.network.DoorGrabPacket;
import net.mcreator.climber.network.DoorJumpPacket;
import net.mcreator.climber.network.GripModeSyncPacket;
import net.mcreator.climber.network.HandGrabPacket;
import net.mcreator.climber.network.StaminaSyncPacket;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.fml.util.thread.SidedThreadGroups;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("climber")
public class ClimberMod {
  public static final Logger LOGGER = LogManager.getLogger(ClimberMod.class);
  public static final String MODID = "climber";

  public ClimberMod() {
    // Start of user code block mod constructor
    // End of user code block mod constructor
    MinecraftForge.EVENT_BUS.register(this);
    IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
    ClimberModSounds.REGISTRY.register(bus);
    net.mcreator.climber.init.ClimberModBlocks.register(bus);
    ClimberModBlockEntities.REGISTRY.register(bus);
    net.mcreator.climber.init.ClimberModItems.register(bus);
    net.mcreator.climber.init.ClimberModEntities.REGISTRY.register(bus);
    // Start of user code block mod init
    // The saved config (grip mode, auto grip, stamina…) was never loaded before -> /climb grip
    // realistic
    // was lost on every restart.
    ClimberConfig.INSTANCE.load();
    ClimbCapability.register(bus);
    MinecraftForge.EVENT_BUS.register(new ClimberServerEvents());
    addNetworkMessage(
        ClimbStatePacket.class,
        ClimbStatePacket::encode,
        ClimbStatePacket::decode,
        ClimbStatePacket::handle);
    addNetworkMessage(
        HandGrabPacket.class,
        HandGrabPacket::encode,
        HandGrabPacket::decode,
        HandGrabPacket::handle);
    addNetworkMessage(
        AnchorSyncPacket.class,
        AnchorSyncPacket::encode,
        AnchorSyncPacket::decode,
        AnchorSyncPacket::handle);
    addNetworkMessage(
        ClimbJumpPacket.class,
        ClimbJumpPacket::encode,
        ClimbJumpPacket::decode,
        ClimbJumpPacket::handle);
    addNetworkMessage(
        StaminaSyncPacket.class,
        StaminaSyncPacket::encode,
        StaminaSyncPacket::decode,
        StaminaSyncPacket::handle);
    addNetworkMessage(
        DoorGrabPacket.class,
        DoorGrabPacket::encode,
        DoorGrabPacket::decode,
        DoorGrabPacket::handle);
    addNetworkMessage(
        DoorAnglePacket.class,
        DoorAnglePacket::encode,
        DoorAnglePacket::decode,
        DoorAnglePacket::handle);
    addNetworkMessage(
        GripModeSyncPacket.class,
        GripModeSyncPacket::encode,
        GripModeSyncPacket::decode,
        GripModeSyncPacket::handle);
    addNetworkMessage(
        DoorJumpPacket.class,
        DoorJumpPacket::encode,
        DoorJumpPacket::decode,
        DoorJumpPacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.DoorPushPacket.class,
        net.mcreator.climber.network.DoorPushPacket::encode,
        net.mcreator.climber.network.DoorPushPacket::decode,
        net.mcreator.climber.network.DoorPushPacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.ConfigSyncPacket.class,
        net.mcreator.climber.network.ConfigSyncPacket::encode,
        net.mcreator.climber.network.ConfigSyncPacket::decode,
        net.mcreator.climber.network.ConfigSyncPacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.ConfigUpdatePacket.class,
        net.mcreator.climber.network.ConfigUpdatePacket::encode,
        net.mcreator.climber.network.ConfigUpdatePacket::decode,
        net.mcreator.climber.network.ConfigUpdatePacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.AnimationRequestPacket.class,
        net.mcreator.climber.network.AnimationRequestPacket::encode,
        net.mcreator.climber.network.AnimationRequestPacket::decode,
        net.mcreator.climber.network.AnimationRequestPacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.AnimationSyncPacket.class,
        net.mcreator.climber.network.AnimationSyncPacket::encode,
        net.mcreator.climber.network.AnimationSyncPacket::decode,
        net.mcreator.climber.network.AnimationSyncPacket::handle);
    MinecraftForge.EVENT_BUS.register(new net.mcreator.climber.animation.AnimationServer());
    addNetworkMessage(
        net.mcreator.climber.network.MechanismEditPacket.class,
        net.mcreator.climber.network.MechanismEditPacket::encode,
        net.mcreator.climber.network.MechanismEditPacket::decode,
        net.mcreator.climber.network.MechanismEditPacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.MechanismListPacket.Request.class,
        net.mcreator.climber.network.MechanismListPacket.Request::encode,
        net.mcreator.climber.network.MechanismListPacket.Request::decode,
        net.mcreator.climber.network.MechanismListPacket.Request::handle);
    addNetworkMessage(
        net.mcreator.climber.network.MechanismListPacket.Response.class,
        net.mcreator.climber.network.MechanismListPacket.Response::encode,
        net.mcreator.climber.network.MechanismListPacket.Response::decode,
        net.mcreator.climber.network.MechanismListPacket.Response::handle);
    addNetworkMessage(
        net.mcreator.climber.network.RopeSwingPacket.class,
        net.mcreator.climber.network.RopeSwingPacket::encode,
        net.mcreator.climber.network.RopeSwingPacket::decode,
        net.mcreator.climber.network.RopeSwingPacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.RemoteObjectPacket.class,
        net.mcreator.climber.network.RemoteObjectPacket::encode,
        net.mcreator.climber.network.RemoteObjectPacket::decode,
        net.mcreator.climber.network.RemoteObjectPacket::handle);
    addNetworkMessage(
        net.mcreator.climber.network.RemoteObjectReply.class,
        net.mcreator.climber.network.RemoteObjectReply::encode,
        net.mcreator.climber.network.RemoteObjectReply::decode,
        net.mcreator.climber.network.RemoteObjectReply::handle);

    MinecraftForge.EVENT_BUS.register(new net.mcreator.climber.mechanism.MechanismEvents());
    MinecraftForge.EVENT_BUS.register(new DoorEvents());
    MinecraftForge.EVENT_BUS.register(new net.mcreator.climber.event.FlashlightEvents());
    // MinecraftForge.EVENT_BUS.register(new DoorClientHandler());
    if (FMLEnvironment.dist == Dist.CLIENT) {
      ClimberClientSetup.init(bus);
    }
    // End of user code block mod init
  }

  // Start of user code block mod methods
  // End of user code block mod methods
  // v10: synchronized door hitbox position offsets.
  private static final String PROTOCOL_VERSION = "10";
  public static final SimpleChannel PACKET_HANDLER =
      NetworkRegistry.newSimpleChannel(
          new ResourceLocation(MODID, MODID),
          () -> PROTOCOL_VERSION,
          PROTOCOL_VERSION::equals,
          PROTOCOL_VERSION::equals);
  private static int messageID = 0;

  public static <T> void addNetworkMessage(
      Class<T> messageType,
      BiConsumer<T, FriendlyByteBuf> encoder,
      Function<FriendlyByteBuf, T> decoder,
      BiConsumer<T, Supplier<NetworkEvent.Context>> messageConsumer) {
    PACKET_HANDLER.registerMessage(messageID, messageType, encoder, decoder, messageConsumer);
    messageID++;
  }

  private static final Collection<AbstractMap.SimpleEntry<Runnable, Integer>> workQueue =
      new ConcurrentLinkedQueue<>();

  public static void queueServerWork(int tick, Runnable action) {
    if (Thread.currentThread().getThreadGroup() == SidedThreadGroups.SERVER)
      workQueue.add(new AbstractMap.SimpleEntry<>(action, tick));
  }

  @SubscribeEvent
  public void tick(TickEvent.ServerTickEvent event) {
    if (event.phase == TickEvent.Phase.END) {
      List<AbstractMap.SimpleEntry<Runnable, Integer>> actions = new ArrayList<>();
      workQueue.forEach(
          work -> {
            work.setValue(work.getValue() - 1);
            if (work.getValue() == 0) actions.add(work);
          });
      actions.forEach(e -> e.getKey().run());
      workQueue.removeAll(actions);
    }
  }
}
