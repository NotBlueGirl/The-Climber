import java.io.StringReader;
import java.nio.file.*;
import java.util.*;
import net.mcreator.climber.mechanism.MechanismMesh;

public final class MechanismMeshTest {
  private static int checks;

  private static void check(boolean ok, String what) {
    if (!ok) throw new AssertionError(what);
    checks++;
  }

  public static void main(String[] args) throws Exception {
    Path folder = Path.of("src/main/resources/assets/climber/models/mechanism");
    Map<String, MechanismMesh> meshes = new HashMap<>();
    int faces = 0;
    try (var files = Files.list(folder)) {
      for (Path file : files.filter(p -> p.toString().endsWith(".json")).toList()) {
        MechanismMesh mesh;
        try (var reader = Files.newBufferedReader(file)) {
          mesh = MechanismMesh.read(reader);
        }
        check(
            mesh.name().equals(file.getFileName().toString().replace(".json", "")),
            "Model identity");
        meshes.put(mesh.name(), mesh);
        faces += mesh.faces().size();
        // All three- and four-sided faces, finite coordinates, UV ranges, area and unit normals
        // have already been validated by the production parser above.
        for (var f : mesh.faces()) {
          float[][] p = f.positions();
          double[] a = new double[3], b = new double[3];
          for (int i = 0; i < 3; i++) {
            a[i] = p[1][i] - p[0][i];
            b[i] = p[2][i] - p[0][i];
          }
          double dot =
              (a[1] * b[2] - a[2] * b[1]) * f.normal()[0]
                  + (a[2] * b[0] - a[0] * b[2]) * f.normal()[1]
                  + (a[0] * b[1] - a[1] * b[0]) * f.normal()[2];
          if (dot <= 0)
            throw new AssertionError("Winding vs normal: " + mesh.name() + "/" + f.part());
        }
        check(true, "Winding matches normals");
      }
    }
    check(meshes.size() == 10, "All runtime assets");
    check(faces >= 900, "Geometry coverage");
    for (String name : List.of("climbing_hook", "weak_climbing_hook")) {
      var mesh = meshes.get(name);
      var ends = mesh.faces().stream().filter(f -> f.part().startsWith("triangular_end")).toList();
      check(ends.size() == 2, "Two triangular ends");
      for (var face : ends) {
        check(face.positions().length == 3, "Real triangle, not quad");
        float[][] p = face.positions();
        check(
            Math.abs(p[0][0] - p[1][0]) < 1e-6 && Math.abs(p[1][0] - p[2][0]) < 1e-6, "Side plane");
        var yz = new HashSet<String>();
        for (var v : p) yz.add(String.format(java.util.Locale.ROOT, "%.3f,%.3f", v[1], v[2]));
        check(
            yz.equals(Set.of("0.000,-0.125", "0.280,-0.125", "0.140,0.150")),
            "Vertical wall edge, outward apex");
      }
    }
    for (int i = 0; i < 5; i++)
      check(
          Arrays.deepEquals(
              meshes.get("climbing_hook").faces().get(i).positions(),
              meshes.get("weak_climbing_hook").faces().get(i).positions()),
          "Identical hook silhouette");
    check(
        meshes.get("weak_climbing_hook").faces().stream()
            .anyMatch(f -> f.part().equals("fracture")),
        "Weak visual distinction");
    check(
        meshes.get("valve_wheel").faces().stream().anyMatch(f -> f.part().startsWith("hex_rim")),
        "Hexagonal wheel rim");
    check(
        meshes.get("platform").faces().stream().noneMatch(f -> f.part().startsWith("wedge")),
        "No duplicate child hooks");
    check(
        meshes.get("mechanical_ladder").faces().stream()
            .anyMatch(f -> f.part().equals("rung_grip")),
        "3D ladder rungs");
    for (String bad :
        List.of(
            "{\"format_version\":2}", "{\"format_version\":1,\"name\":\"empty\",\"faces\":[]}")) {
      boolean rejected = false;
      try {
        MechanismMesh.read(new StringReader(bad));
      } catch (IllegalArgumentException e) {
        rejected = true;
      }
      check(rejected, "Reject invalid assets");
    }
    System.out.println(
        "MechanismMeshTest: "
            + checks
            + " assertions passed; validated "
            + faces
            + " faces, UVs, normals and triangular hook profiles");
  }
}
