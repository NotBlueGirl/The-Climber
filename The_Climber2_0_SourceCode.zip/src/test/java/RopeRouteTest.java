import java.util.*;
import net.mcreator.climber.mechanism.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

public final class RopeRouteTest {
  private static int checks;

  private static void check(boolean ok, String what) {
    if (!ok) throw new AssertionError(what);
    checks++;
  }

  public static void main(String[] args) {
    var anchor = new Vec3(0, 10, 0);
    var rope = new RopePhysics(anchor, 6);
    rope.impulse(new Vec3(.2, 0, 0));
    double maxError = 0;
    for (int t = 0; t < 300; t++) {
      rope.step(anchor, (old, next) -> next);
      var points = rope.points();
      if (!points.get(0).equals(anchor)
          || points.stream().anyMatch(p -> !Double.isFinite(p.lengthSqr())))
        throw new AssertionError("Unstable chain");
      double segment = 6.0 / (points.size() - 1);
      for (int i = 1; i < points.size(); i++)
        maxError =
            Math.max(maxError, Math.abs(points.get(i).distanceTo(points.get(i - 1)) - segment));
    }
    check(rope.points().size() > 4, "Multiple physical segments");
    check(maxError < .18, "Segment strain bounded: " + maxError);
    check(rope.end().distanceTo(anchor) < 7, "Total strain bounded");
    var restored = new RopePhysics(anchor, 6);
    restored.restore(rope.save(), anchor);
    check(restored.points().equals(rope.points()), "All nodes persist");
    var longRope = new RopePhysics(anchor, 32);
    for (int i = 0; i < 40; i++) longRope.step(anchor, (a, b) -> b);
    check(longRope.points().size() == 49, "Node budget bounded");
    var s = new MechanismSpec();
    s.kind = MechanismSpec.Kind.PLATFORM;
    s.roundTripSeconds = 20;
    s.curved = true;
    s.selectRailBlocks(
        List.of(new BlockPos(10, 4, 10), new BlockPos(12, 6, 10), new BlockPos(15, 6, 12)));
    s.valveTarget = new BlockPos(5, 4, 3);
    s.validate();
    check(s.path.get(0).equals(Vec3.ZERO), "First selected block is route origin");
    check(s.route().size() > s.path.size(), "Curve samples generated");
    check(s.pointAt(0).equals(Vec3.ZERO) && s.pointAt(1).equals(Vec3.ZERO), "Roundtrip endpoints");
    check(s.pointAt(.5).distanceTo(s.path.get(s.path.size() - 1)) < 1e-8, "Far endpoint");
    var copy = MechanismSpec.load(s.save());
    check(
        copy.curved
            && copy.railBlocks.equals(s.railBlocks)
            && copy.valveTarget.equals(s.valveTarget),
        "Authoring data survives NBT");
    check(copy.route().equals(s.route()), "Renderer/server share curve");
    var route = s.route();
    s.curved = false;
    check(s.route().size() == 3, "Curve cache invalidated");
    s.curved = true;
    check(s.route().equals(route), "Deterministic curve");
    s.setPath("0,0,0; 2,0,0");
    check(s.railBlocks.isEmpty(), "Legacy offset edit clears block selection");
    rope.step(anchor, (a, b) -> b);
    restored.step(anchor, (a, b) -> b);
    check(restored.points().equals(rope.points()), "Velocity/history persist across load");
    var colliding = new RopePhysics(anchor, 3);
    colliding.impulse(new Vec3(.3, 0, 0));
    for (int i = 0; i < 80; i++)
      colliding.step(anchor, (a, b) -> new Vec3(Math.min(.12, b.x), b.y, b.z));
    check(
        colliding.points().stream().allMatch(p -> p.x <= .120001),
        "Node collision resolver applied after constraints");
    copy.curved = true;
    double maxStep = 0;
    Vec3 prior = copy.pointAt(0);
    for (int i = 1; i <= 600; i++) {
      Vec3 now = copy.pointAt(i / 600.0);
      maxStep = Math.max(maxStep, now.distanceTo(prior));
      prior = now;
    }
    check(maxStep <= copy.routeLength() / 300 + .00001, "Constant arc-length speed on curve");
    var swing = new RopePhysics(anchor, 6);
    swing.impulse(new Vec3(.35, 0, 0));
    double maxX = 0, maxAcceleration = 0, strain = 0;
    Vec3 old = swing.end(), velocity = Vec3.ZERO;
    for (int t = 0; t < 400; t++) {
      swing.step(anchor, (a, b) -> b);
      Vec3 now = swing.end(), v = now.subtract(old);
      if (t > 1) maxAcceleration = Math.max(maxAcceleration, v.subtract(velocity).length());
      maxX = Math.max(maxX, Math.abs(now.x));
      velocity = v;
      old = now;
      var nodes = swing.points();
      for (int i = 1; i < nodes.size(); i++)
        strain = Math.max(strain, Math.abs(nodes.get(i).distanceTo(nodes.get(i - 1)) - .4));
    }
    check(maxX > 1, "Incoming movement creates a useful swing, not a rigid pole");
    check(maxAcceleration < .2, "No abrupt endpoint acceleration spikes: " + maxAcceleration);
    check(strain < .05, "Substepped chain strain: " + strain);
    var driven = new RopePhysics(anchor, 6);
    double drivenAmplitude = 0;
    for (int t = 0; t < 60; t++) {
      driven.accelerate(new Vec3(.027, 0, 0));
      driven.step(anchor, (a, b) -> b);
      drivenAmplitude = Math.max(drivenAmplitude, driven.end().x);
    }
    check(drivenAmplitude > .8, "Directional input visibly pumps swing: " + drivenAmplitude);
    System.out.println(
        "Swing metrics amplitude="
            + maxX
            + " acceleration="
            + maxAcceleration
            + " strain="
            + strain
            + " driven="
            + drivenAmplitude);
    System.out.println(
        "RopeRouteTest: " + checks + " assertions passed; max chain segment error=" + maxError);
  }
}
