import java.util.*;
import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.client.*;
import net.mcreator.climber.config.GameplaySettings;
import net.mcreator.climber.mechanism.*;
import net.minecraft.core.*;
import net.minecraft.nbt.*;
import net.minecraft.world.phys.Vec3;

public final class UpgradeFormatTest {
  static int n;

  static void check(boolean ok, String text) {
    n++;
    if (!ok) throw new AssertionError(text);
  }

  static void reject(CompoundTag t) {
    try {
      GameplaySettings.validate(t);
      throw new AssertionError("Accepted invalid gameplay settings");
    } catch (IllegalArgumentException ex) {
      n++;
    }
  }

  public static void main(String[] args) {
    var cfg = ClimberConfig.INSTANCE;
    var original = cfg.toSyncTag();
    try {
      cfg.resetAll();
      var defaults = cfg.toSyncTag();
      check(defaults.getBoolean("DoorPhysics"), "Physical doors default ON");
      for (var o : GameplaySettings.OPTIONS) {
        check(defaults.getDouble(o.key()) == o.initial(), "Default " + o.key());
        var t = new CompoundTag();
        t.putDouble(o.key(), o.max());
        cfg.applySyncTag(t);
        check(cfg.toSyncTag().getDouble(o.key()) == o.max(), "Synchronized " + o.key());
        for (double bad :
            new double[] {o.min() - 1, o.max() + 1, Double.NaN, Double.POSITIVE_INFINITY}) {
          t.putDouble(o.key(), bad);
          reject(t);
        }
        t.putDouble(o.key(), o.min());
        cfg.applySyncTag(t);
        check(cfg.gameplay().number(o.key()) == o.min(), "Minimum / signed value " + o.key());
        t.putDouble(o.key(), o.max());
        cfg.applySyncTag(t);
        t.putString(o.key(), "1");
        reject(t);
      }
      var json = new com.google.gson.JsonObject();
      cfg.gameplay().json(json);
      var copy = new GameplaySettings();
      copy.load(json);
      for (var o : GameplaySettings.OPTIONS)
        check(copy.number(o.key()) == o.max(), "JSON round trip " + o.key());
      var bad = new CompoundTag();
      bad.putString("DoorPhysics", "yes");
      reject(bad);
      bad.putByte("DoorPhysics", (byte) 2);
      reject(bad);
      var partial = new CompoundTag();
      partial.putBoolean("DoorPhysics", false);
      cfg.applySyncTag(partial);
      check(!cfg.gameplay().doorPhysics(), "Boolean patch");
      cfg.resetAll();
      check(cfg.toSyncTag().equals(defaults), "Complete reset");
      var origin = new Vec3(10, 4, 20);
      var route = List.of(Vec3.ZERO, new Vec3(0, 4, 0));
      for (var face : Direction.Plane.HORIZONTAL) {
        var tracks = PlatformRails.tracks(origin, face, route);
        check(tracks.size() == 2, "Two rails");
        check(
            tracks.get(0).get(0).distanceTo(tracks.get(1).get(0)) - 1.7 < 1e-8,
            "Vertical carriage spacing");
        var midpoint = tracks.get(0).get(0).add(tracks.get(1).get(0)).scale(.5);
        check(Math.abs(midpoint.y - 5) < 1e-8, "Rails centered on body, not feet");
        check(
            tracks.get(0).get(1).subtract(tracks.get(0).get(0)).equals(route.get(1)),
            "World-fixed track follows route");
      }
      var tracks =
          PlatformRails.tracks(origin, Direction.NORTH, List.of(Vec3.ZERO, new Vec3(4, 0, 0)));
      check(
          Math.abs(tracks.get(0).get(0).distanceTo(tracks.get(1).get(0)) - 1.3) < 1e-8,
          "Horizontal shoes spacing");
      for (String axis : List.of("X", "Y", "Z"))
        check(
            SettingsLayout.controls().contains("row:DoorHitboxPos" + axis),
            "Offset editable in Layout Studio " + axis);
      var layout = new SettingsLayout();
      var history = new LayoutHistory(layout);
      layout.element("Header").x = .2f;
      history.commit(layout);
      layout.element("Header").label = "TEST";
      history.commit(layout);
      check(history.undo().element("Header").label.isEmpty(), "Undo label");
      check(history.undo().element("Header").x == 0, "Undo position");
      check(history.redo().element("Header").x == .2f, "Redo position");
      history.commit(new SettingsLayout());
      check(!history.canRedo(), "New edits clear redo branch");
      check(
          SettingsLayout.controls().contains("tab:Gameplay")
              && SettingsLayout.controls().contains("row:DoorPhysics"),
          "New controls editable");
      for (int i = 0; i < 140; i++) {
        layout.element("Header").label = "Edit" + i;
        history.commit(layout);
      }
      int count = 0;
      while (history.canUndo()) {
        history.undo();
        count++;
      }
      check(count == 100, "History bounded at 100 edits");
      System.out.println("Upgrade format tests: " + n + " passed.");
    } finally {
      cfg.applySyncTag(original);
    }
  }
}
