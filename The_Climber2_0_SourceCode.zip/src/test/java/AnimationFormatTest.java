import net.mcreator.climber.animation.RigAnimation;
import com.google.gson.*;
import java.util.*;
import java.nio.file.*;
public class AnimationFormatTest {
 static int checks=0;
 static void ok(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
 static void reject(String text,String s){try{RigAnimation.fromJson(text);throw new AssertionError("Accepted: "+s);}catch(IllegalArgumentException e){checks++;}}
 public static void main(String[] args)throws Exception{
  RigAnimation a=RigAnimation.blank();a.id="flashlight_wave";a.item="climber:crank_flashlight";a.event=RigAnimation.Trigger.KeyClicked;a.keyCode=82;a.durationTicks=40;a.cooldownTicks=40;
  a.frames.clear();a.frames.put(0,new LinkedHashMap<>());a.frames.put(10,new LinkedHashMap<>());a.frames.put(20,new LinkedHashMap<>());a.frames.put(30,new LinkedHashMap<>());a.frames.put(40,new LinkedHashMap<>());
  a.frames.get(0).put("right_arm",new float[]{0,0,0,0,0,0});
  a.frames.get(10).put("right_arm",new float[]{-75,0,-20,0,0,0});
  a.frames.get(20).put("right_arm",new float[]{-75,0,20,0,0,0});
  a.frames.get(30).put("right_arm",new float[]{-75,0,-20,0,0,0});
  a.frames.get(40).put("right_arm",new float[]{0,0,0,0,0,0});
  ok(a.sample("right_arm",5)[0]==-37.5f,"Linear interpolation");
  ok(a.sample("left_leg",5)==null,"Unkeyed bone untouched");
  ok(a.sample("right_arm",-2)[0]==0,"Hold first key");
  ok(a.sample("right_arm",80)[0]==0,"Hold final key");
  var b=RigAnimation.fromJson(a.toJson());ok(b.toJson().equals(a.toJson()),"JSON round trip");b.frames.get(0).get("right_arm")[0]=55;ok(a.frames.get(0).get("right_arm")[0]==0,"Deep copy");
  JsonObject base=JsonParser.parseString(a.toJson()).getAsJsonObject();
  String[] badIds={"../escape","UPPER","a/b","a.b","", "x".repeat(49)};
  for(String id:badIds){var o=base.deepCopy();o.addProperty("id",id);reject(o.toString(),"Bad ID "+id);}
  for(String key:List.of("duration_ticks")){for(double n:new double[]{0,-1,1201,1.5}){var o=base.deepCopy();o.addProperty(key,n);reject(o.toString(),"Bad duration");}}
  var o=base.deepCopy();o.getAsJsonArray("keyframes").add(o.getAsJsonArray("keyframes").get(0).deepCopy());reject(o.toString(),"Duplicate tick");
  o=base.deepCopy();o.getAsJsonArray("keyframes").get(1).getAsJsonObject().addProperty("tick",41);reject(o.toString(),"Tick beyond duration");
  o=base.deepCopy();o.getAsJsonArray("keyframes").get(0).getAsJsonObject().getAsJsonObject("bones").add("finger",new JsonObject());reject(o.toString(),"Unknown bone");
  for(float n:new float[]{721,Float.NaN,Float.POSITIVE_INFINITY}){o=base.deepCopy();o.getAsJsonArray("keyframes").get(0).getAsJsonObject().getAsJsonObject("bones").getAsJsonObject("right_arm").getAsJsonArray("rotation").set(0,new JsonPrimitive(n));reject(o.toString(),"Bad rotation");}
  o=base.deepCopy();o.getAsJsonArray("keyframes").get(0).getAsJsonObject().getAsJsonObject("bones").getAsJsonObject("right_arm").getAsJsonArray("position").set(2,new JsonPrimitive(33));reject(o.toString(),"Bad pivot offset");
  o=base.deepCopy();o.getAsJsonObject("binding").addProperty("key_code",999);reject(o.toString(),"Bad GLFW key");
  o=base.deepCopy();o.getAsJsonObject("binding").addProperty("item","../../secret");reject(o.toString(),"Bad item id");
  o=base.deepCopy();o.addProperty("mode","unsafe");reject(o.toString(),"Bad mode");
  reject(" ".repeat(RigAnimation.MAX_JSON+1),"Size cap");reject("{}","Missing fields");
  var sparse=RigAnimation.blank();sparse.frames.get(0).put("body",new float[]{0,0,0,0,0,0});sparse.frames.put(10,new LinkedHashMap<>());sparse.frames.get(20).put("body",new float[]{360,0,0,10,0,0});
  ok(sparse.sample("body",10)[0]==180,"Sparse track interpolation");ok(sparse.sample("body",10)[3]==5,"Position interpolation");
  String sample=a.toJson();Path out=Path.of(args.length > 0 ? args[0] : "build/animation-test-examples");Files.createDirectories(out);Files.writeString(out.resolve("flashlight_wave.json"),sample);
  RigAnimation m=a.copy();m.id="click_recoil";m.event=RigAnimation.Trigger.Mouse1Clicked;m.durationTicks=8;m.cooldownTicks=8;m.frames.clear();
  m.frames.put(0,Map.of("right_arm",new float[]{0,0,0,0,0,0}));m.frames.put(2,Map.of("right_arm",new float[]{-25,0,5,0,0,-1}));m.frames.put(8,Map.of("right_arm",new float[]{0,0,0,0,0,0}));Files.writeString(out.resolve("click_recoil.json"),m.toJson());
  System.out.println("Animation format tests: "+checks+" passed. Examples written.");
 }
}
