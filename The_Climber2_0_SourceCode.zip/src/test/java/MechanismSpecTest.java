import java.util.*;
import net.mcreator.climber.client.SettingsLayout;
import net.mcreator.climber.mechanism.*;
import net.minecraft.nbt.*;
import net.minecraft.world.phys.Vec3;

public final class MechanismSpecTest {
  static int checks;

  static void check(boolean b, String why) {
    checks++;
    if (!b) throw new AssertionError(why);
  }

  static void near(double a, double b, String why) {
    check(Math.abs(a - b) < 1e-6, why);
  }

  static void reject(Runnable r, String why) {
    try {
      r.run();
      throw new AssertionError("Accepted: " + why);
    } catch (IllegalArgumentException e) {
      checks++;
    }
  }

  public static void main(String[] args) {
    for (var kind : MechanismSpec.Kind.values()) {
      var a = new MechanismSpec();
      a.kind = kind;
      a.validate();
      var b = MechanismSpec.load(a.save());
      check(b.kind == kind, "kind round trip " + kind);
      check(a.save().equals(b.save()), "spec round trip " + kind);
    }
    var a = new MechanismSpec();
    a.setPath("0,0,0; 4,0,0; 4,0,3");
    a.validate();
    near(a.pointAt(0).length(), 0, "origin");
    near(a.pointAt(.25).x, 3.5, "constant-speed out");
    near(a.pointAt(.5).z, 3, "turn point");
    near(a.pointAt(.75).x, 3.5, "return");
    near(a.pointAt(1).length(), 0, "full round trip");
    for (int i = 0; i < 20; i++) {
      Vec3 end = MechanismSpec.constrain(new Vec3(1, 3, 2), new Vec3(i, -i, 0), 6);
      near(end.distanceTo(new Vec3(1, 3, 2)), 6, "rope length constraint");
    }
    near(MechanismSpec.constrain(Vec3.ZERO, Vec3.ZERO, 4).y, -4, "zero-vector rope fallback");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.ropeLength = Double.NaN;
          s.validate();
        },
        "NaN rope");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.weakSeconds = 0;
          s.validate();
        },
        "zero lifetime");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.valveMax = Double.POSITIVE_INFINITY;
          s.validate();
        },
        "infinite counter");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.repeats = -1;
          s.validate();
        },
        "negative repeats");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.setPath("0,0; 1,2,3");
        },
        "incomplete point");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.setPath("1,0,0; 3,0,0");
          s.validate();
        },
        "nonzero first point");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.setPath("0,0,0; 0,0,0");
          s.validate();
        },
        "zero segment");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.setPath("0,0,0; 100,0,0");
          s.validate();
        },
        "out of range");
    reject(
        () -> {
          var s = new MechanismSpec();
          s.kind = MechanismSpec.Kind.PLATFORM;
          s.roundTripSeconds = 1;
          s.setPath("0,0,0; 10,0,0");
          s.validate();
        },
        "unsafe rail speed");
    a = new MechanismSpec();
    a.action = "PULSE";
    a.trigger = true;
    a.redstone = true;
    a.repeats = 9;
    check(MechanismSpec.load(a.save()).redstone, "redstone persisted");
    check(MechanismSpec.load(a.save()).trigger, "trigger persisted");
    check(MechanismSpec.load(a.save()).repeats == 9, "repeats persisted");
    SettingsLayout l = new SettingsLayout();
    l.validate();
    check(l.color() == 0xFFE8C547, "original accent");
    l.element("row:Grip mode").x = .1f;
    l.element("row:Grip mode").visible = false;
    var c = l.copy();
    check(!c.element("row:Grip mode").visible, "visibility copy");
    near(c.element("row:Grip mode").x, .1, "position copy");
    c.element("row:Grip mode").x = .2f;
    near(l.element("row:Grip mode").x, .1, "draft isolation");
    reject(
        () -> {
          var s = new SettingsLayout();
          s.accent = "<script>";
          s.validate();
        },
        "bad color");
    reject(
        () -> {
          var s = new SettingsLayout();
          s.element("Panel").scale = Float.NaN;
          s.validate();
        },
        "NaN scale");
    reject(
        () -> {
          var s = new SettingsLayout();
          s.rowSpacing = 0;
          s.validate();
        },
        "zero spacing");
    reject(
        () -> {
          var s = new SettingsLayout();
          s.element("Header").x = 3;
          s.validate();
        },
        "inaccessible header");
    System.out.println("Mechanism/layout tests: " + checks + " passed.");
  }
}
