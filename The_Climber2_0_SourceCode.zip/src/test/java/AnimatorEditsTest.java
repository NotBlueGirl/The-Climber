import net.mcreator.climber.animation.*;
import java.util.*;
public final class AnimatorEditsTest {
 static int n;static void check(boolean b,String name){n++;if(!b)throw new AssertionError(name);}
 static void reject(Runnable r,String name){try{r.run();throw new AssertionError("Accepted "+name);}catch(IllegalArgumentException e){n++;}}
 public static void main(String[] args){
  RigAnimation a=RigAnimation.blank();final RigAnimation work=a;a.frames.get(0).put("right_arm",new float[]{10,20,30,4,5,6});
  var copy=AnimationEdits.copy(a);copy.frames.get(0).get("right_arm")[0]=99;check(a.sample("right_arm",0)[0]==10,"Deep clip copy");
  var pose=AnimationEdits.fullPose(a,0);check(pose.size()==6,"Full pose fills all bones");
  var mirror=AnimationEdits.mirror(pose);check(Arrays.equals(mirror.get("left_arm"),new float[]{10,-20,-30,-4,5,6}),"Mirror swaps arm and signs");
  var twice=AnimationEdits.mirror(mirror);for(String b:RigAnimation.BONES)check(Arrays.equals(pose.get(b),twice.get(b)),"Mirror twice "+b);
  AnimationEdits.paste(a,10,mirror);mirror.get("left_arm")[0]=77;check(a.frames.get(10).get("left_arm")[0]==10,"Paste deep copies");
  AnimationEdits.move(a,10,12);check(!a.frames.containsKey(10)&&a.frames.containsKey(12),"Move frame");
  reject(()->AnimationEdits.move(work,12,20),"Move to occupied tick");check(a.frames.containsKey(12),"Collision preserves source");
  reject(()->AnimationEdits.move(work,99,2),"Move missing source");reject(()->AnimationEdits.move(work,12,21),"Move outside duration");
  AnimationEdits.stretch(a,40);check(a.durationTicks==40&&a.frames.containsKey(24),"Stretch preserves timing ratio");
  var before=AnimationEdits.copy(a);reject(()->AnimationEdits.stretch(work,0),"Zero duration");check(a.toJson().equals(before.toJson()),"Failed stretch atomic");
  RigAnimation shortClip=RigAnimation.blank();shortClip.frames.put(1,new LinkedHashMap<>());reject(()->AnimationEdits.stretch(shortClip,1),"Rounding collision");check(shortClip.durationTicks==20&&shortClip.frames.containsKey(20),"Collision does not alter clip");
  var history=new AnimationEdits.History();history.record(a,"id",1000);a.id="one";history.record(a,"id",1100);a.id="two";
  a=history.undo(a);check(a.id.equals("new_animation"),"Grouped typing undoes in one step");a=history.redo(a);check(a.id.equals("two"),"Redo restores edit");
  history.record(a,"item",2000);a.item="minecraft:stick";a=history.undo(a);check(a.item.equals("*"),"Different field separate undo");
  history.record(a,"name",3000);a.id="other";check(!history.canRedo(),"New edit clears redo");
  for(int i=0;i<70;i++){history.record(a,"edit"+i,4000+i*500);a.keyCode=32+i;}
  int count=0;while(history.canUndo()){a=history.undo(a);count++;}check(count==64,"History bounded to 64");
  RigAnimation cap=RigAnimation.blank();cap.frames.clear();cap.durationTicks=100;for(int i=0;i<64;i++)cap.frames.put(i,new LinkedHashMap<>());
  reject(()->AnimationEdits.paste(cap,80,pose),"Keyframe limit");AnimationEdits.paste(cap,0,pose);check(cap.frames.size()==64,"Can replace existing frame at limit");
  check(RigAnimation.fromJson(AnimationEdits.copy(shortClip).toJson()).durationTicks==20,"Editing remains JSON compatible");
  System.out.println("Animator editing tests: "+n+" passed.");
 }
}
