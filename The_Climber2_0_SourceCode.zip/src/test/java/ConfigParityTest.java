import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.config.ConfigValidation;
import net.minecraft.nbt.*;
import net.minecraft.world.phys.Vec3;
import java.util.*;
public final class ConfigParityTest {
 static int n;static void check(boolean b,String s){n++;if(!b)throw new AssertionError(s);}
 static void reject(CompoundTag t,String s){try{ConfigValidation.validate(t,false);throw new AssertionError("Accepted "+s);}catch(IllegalArgumentException e){n++;}}
 public static void main(String[] args){
  var cfg=ClimberConfig.INSTANCE;CompoundTag original=cfg.toSyncTag();
  try{
   cfg.resetAll();CompoundTag defaults=cfg.toSyncTag();check(defaults.equals(ClimberConfig.defaultSyncTag()),"All fields have correct defaults");
   cfg.setStaminaMax(555);cfg.setStaminaDrainRate(2.7f);cfg.setStaminaRegenRate(.5f);cfg.setStrengthJumpBothHands(2.3f);cfg.setStrengthJumpOneHand(1.8f);cfg.setStaminaEnabled(true);
   cfg.setGripMode(net.mcreator.climber.grip.GripMode.REALISTIC);cfg.setAutoGripMode(net.mcreator.climber.grip.AutoGripMode.BOTH);
   cfg.setIdleHandPos(new Vec3(.5,-1.25,2));cfg.addIncludes(List.of("minecraft:stone","minecraft:dirt"));cfg.addExcludes(List.of("minecraft:glass"));cfg.setGrabHitSound("minecraft:block.stone.break");cfg.setGrabJumpSound("./sounds/jump.ogg");
   CompoundTag t=cfg.toSyncTag();for(String key:new String[]{"idleHandX","idleHandY","idleHandZ","includeList","excludeList","grabHitSound","grabJumpSound"})check(t.contains(key),"Sync includes "+key);
   ConfigValidation.validate(t,false);cfg.resetAll();cfg.applySyncTag(t);check(cfg.toSyncTag().equals(t),"Full settings sync round trip");
   var partial=new CompoundTag();partial.putString("grabHitSound","");cfg.applySyncTag(partial);check(cfg.getGrabHitSound()==null,"Blank sound restores default");check(cfg.getIdleHandPos().y==-1.25,"Partial patch preserves unrelated fields");
   check(ConfigValidation.blockIds("minecraft:stone; minecraft:dirt\nminecraft:stone").size()==2,"List separators and deduplication");
   partial=new CompoundTag();partial.putDouble("idleHandX",Double.NaN);reject(partial,"NaN position");
   for(String key:ConfigValidation.NUMBERS){var bad=new CompoundTag();bad.putDouble(key,Double.POSITIVE_INFINITY);reject(bad,"Infinite "+key);bad.putDouble(key,-1);reject(bad,"Negative "+key);}
   partial=new CompoundTag();partial.putDouble("staminaMax",1.5);reject(partial,"Fractional max stamina");
   partial=new CompoundTag();partial.putString("grabHitSound","wrong text");reject(partial,"Malformed sound ID");partial.putString("grabHitSound","./audio/not_audio.exe");reject(partial,"Invalid file suffix");
   try{ConfigValidation.blockIds("not_a_block");throw new AssertionError("Accepted unqualified block");}catch(IllegalArgumentException e){n++;}
   cfg.resetAll();check(cfg.getIncludeList().isEmpty()&&cfg.getExcludeList().isEmpty(),"Reset clears both lists");
   for(String command:new String[]{"/climb settings","/climber settings","/climb menu","/CLIMBER GUI"})check(net.mcreator.climber.client.ClimberSettingsCommands.matches(command),"Settings shortcut "+command);
   for(String command:new String[]{"/climb config","/climb sprites on","/climber settings extra","hello"})check(!net.mcreator.climber.client.ClimberSettingsCommands.matches(command),"Does not intercept "+command);
   System.out.println("Configuration parity tests: "+n+" passed.");
  }finally{cfg.applySyncTag(original);}
 }
}
