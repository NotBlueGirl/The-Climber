package net.mcreator.climber.test;

import java.util.*;
import net.mcreator.climber.ClimberConfig;
import net.mcreator.climber.init.*;
import net.mcreator.climber.mechanism.*;
import net.mcreator.climber.network.*;
import net.minecraft.core.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.*;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.gametest.*;

@GameTestHolder("climber")
@PrefixGameTestTemplate(false)
public final class UpgradeWorldTests {
  static BlockPos chain(GameTestHelper h) {
    var l = h.getLevel();
    var top = h.absolutePos(new BlockPos(4, 8, 4));
    for (int i = 0; i < 3; i++) {
      var b = top.below(i);
      l.setBlockAndUpdate(b.south(), Blocks.STONE.defaultBlockState());
      l.setBlockAndUpdate(
          b,
          ClimberModBlocks.MECHANICAL_LADDER
              .get()
              .defaultBlockState()
              .setValue(LadderBlock.FACING, Direction.NORTH)
              .setValue(MechanicalLadderBlock.LAYERS, 2));
    }
    return top;
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void full_front_chain_deploys_and_persists(GameTestHelper h) {
    var l = h.getLevel();
    var top = chain(h);
    MechanicalLadderBlock.hit(l, top.below());
    for (int i = 0; i < 3; i++) {
      h.assertTrue(
          l.getBlockState(top.below(i)).getValue(MechanicalLadderBlock.LAYERS) == 1,
          "Every fixed back stays");
      h.assertTrue(
          l.getBlockState(top.below(i + 3)).getValue(MechanicalLadderBlock.EXTENSION),
          "Entire front chain drops its full three-block length");
    }
    var root = (MechanicalLadderBlockEntity) l.getBlockEntity(top);
    var tag = root.saveWithFullMetadata();
    h.assertTrue(tag.getInt("chainLength") == 3, "Controller length persists");
    root.load(tag);
    l.setBlockAndUpdate(top.below(4).east(), Blocks.REDSTONE_BLOCK.defaultBlockState());
    h.runAfterDelay(
        5,
        () -> {
          for (int i = 0; i < 3; i++) {
            h.assertTrue(
                l.getBlockState(top.below(i)).getValue(MechanicalLadderBlock.LAYERS) == 2,
                "Redstone at a front member retracts all layers");
            h.assertTrue(l.getBlockState(top.below(i + 3)).isAir(), "Front destination cleared");
          }
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void chain_projectile_hits_middle(GameTestHelper h) {
    var l = h.getLevel();
    var top = chain(h);
    var middle = top.below();
    var ball =
        new net.minecraft.world.entity.projectile.Snowball(
            l, middle.getX() + .5, middle.getY() + .65, middle.getZ() - 2);
    ball.shoot(0, 0, 1, 2f, 0);
    l.addFreshEntity(ball);
    h.runAfterDelay(
        8,
        () -> {
          h.assertTrue(
              l.getBlockState(top.below(5)).getBlock() instanceof MechanicalLadderBlock,
              "Projectile on middle drops bottom three blocks below original bottom");
          h.assertTrue(
              l.getBlockState(top).getValue(MechanicalLadderBlock.DEPLOYED),
              "Top participates in connected chain");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void chain_blocked_is_atomic(GameTestHelper h) {
    var l = h.getLevel();
    var top = chain(h);
    l.setBlockAndUpdate(top.below(5), Blocks.DIAMOND_BLOCK.defaultBlockState());
    MechanicalLadderBlock.hit(l, top);
    for (int i = 0; i < 3; i++)
      h.assertTrue(
          l.getBlockState(top.below(i)).getValue(MechanicalLadderBlock.LAYERS) == 2,
          "Blocked full chain does not partly deploy");
    h.assertTrue(l.getBlockState(top.below(3)).isAir(), "No partial front created");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void chain_missing_front_not_duplicated(GameTestHelper h) {
    var l = h.getLevel();
    var top = chain(h);
    MechanicalLadderBlock.hit(l, top);
    l.removeBlock(top.below(4), false);
    ((MechanicalLadderBlockEntity) l.getBlockEntity(top.below(5))).retract();
    h.assertTrue(
        l.getBlockState(top.below()).getValue(MechanicalLadderBlock.LAYERS) == 1,
        "Missing middle front not recreated");
    h.assertTrue(
        l.getBlockState(top).getValue(MechanicalLadderBlock.LAYERS) == 2
            && l.getBlockState(top.below(2)).getValue(MechanicalLadderBlock.LAYERS) == 2,
        "Other fronts restored independently");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void remote_edits_ignore_distance_but_check_revision(GameTestHelper h) {
    var l = h.getLevel();
    var spec = new MechanismSpec();
    spec.kind = MechanismSpec.Kind.ROPE;
    var block = h.absolutePos(new BlockPos(3, 8, 3));
    l.setBlockAndUpdate(block, Blocks.STONE.defaultBlockState());
    var obj =
        MechanismEntity.place(
            l, Vec3.atLowerCornerOf(block).add(.5, 0, .5), Direction.DOWN, block, spec);
    var player =
        FakePlayerFactory.get(
            l, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "[RemoteQA]"));
    player.setGameMode(net.minecraft.world.level.GameType.CREATIVE);
    player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ClimberModItems.DEBUGGER.get()));
    player.setPos(obj.getX() + 500, obj.getY(), obj.getZ());
    int revision = RemoteAuthoring.revision(obj);
    var patch = MechanismSpec.load(obj.spec().save());
    patch.ropeLength = 8;
    RemoteAuthoring.save(player, obj, patch.save(), revision);
    h.assertTrue(obj.spec().ropeLength == 8, "Edit succeeds 500 blocks away");
    try {
      RemoteAuthoring.save(player, obj, spec.save(), revision);
      h.fail("Stale write accepted");
    } catch (IllegalArgumentException expected) {
    }
    player.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
    try {
      RemoteAuthoring.save(player, obj, spec.save(), RemoteAuthoring.revision(obj));
      h.fail("No-tool write accepted");
    } catch (IllegalArgumentException expected) {
    }
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void door_absolute_dimensions_and_flashlight_units(GameTestHelper h) {
    var cfg = ClimberConfig.INSTANCE;
    var old = cfg.toSyncTag();
    try {
      var tag = new CompoundTag();
      tag.putDouble("DoorHitboxX", 1.5);
      tag.putDouble("DoorHitboxY", 3);
      tag.putDouble("DoorHitboxZ", .25);
      tag.putDouble("MaxTimeCrackLight", 20);
      tag.putDouble("ClickCrankRegen", 2.5);
      cfg.applySyncTag(tag);
      var boxes =
          net.mcreator.climber.door.DoorGeometry.worldSegments(
              BlockPos.ZERO, Direction.NORTH, false, 0);
      AABB total = boxes.get(0);
      for (var b : boxes) total = total.minmax(b);
      h.assertTrue(
          Math.abs(total.getXsize() - 1.5) < 1e-8
              && Math.abs(total.getYsize() - 3) < 1e-8
              && Math.abs(total.getZsize() - .25) < 1e-8,
          "Door hitbox is absolute width/height/depth in blocks");
      var upper =
          net.mcreator.climber.door.DoorGeometry.rotatedShape(
                  BlockPos.ZERO, Direction.NORTH, false, 0, 1)
              .bounds();
      h.assertTrue(upper.maxY == 2, "Height above upper half preserved");
      h.assertTrue(
          net.mcreator.climber.item.CrankFlashlightItem.maxCharge() == 400,
          "20 seconds = 400 ticks");
      h.assertTrue(
          net.mcreator.climber.item.CrankFlashlightItem.crankRegen() == 50,
          "2.5 seconds = 50 ticks");
      h.succeed();
    } finally {
      cfg.applySyncTag(old);
    }
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void rebar_distance_stops_at_budget(GameTestHelper h) {
    var cfg = ClimberConfig.INSTANCE;
    var old = cfg.toSyncTag();
    var tag = new CompoundTag();
    tag.putDouble("RebarKnockback", 2);
    cfg.applySyncTag(tag);
    var pig =
        new net.minecraft.world.entity.animal.Pig(
            net.minecraft.world.entity.EntityType.PIG, h.getLevel());
    pig.setNoAi(true);
    pig.setNoGravity(true);
    Vec3 start = Vec3.atCenterOf(h.absolutePos(new BlockPos(2, 5, 2)));
    pig.setPos(start);
    h.getLevel().addFreshEntity(pig);
    net.mcreator.climber.event.RebarKnockback.start(pig, new Vec3(1, 0, 0));
    cfg.applySyncTag(old);
    h.runAfterDelay(
        12,
        () -> {
          h.assertTrue(
              Math.abs(pig.getX() - start.x - 2) < .001,
              "Knockback consumes exactly two horizontal blocks");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void rebar_collision_does_not_tunnel(GameTestHelper h) {
    var cfg = ClimberConfig.INSTANCE;
    var old = cfg.toSyncTag();
    var tag = new CompoundTag();
    tag.putDouble("RebarKnockback", 8);
    cfg.applySyncTag(tag);
    var p = h.absolutePos(new BlockPos(3, 5, 3));
    for (int y = 0; y < 3; y++)
      h.getLevel().setBlockAndUpdate(p.east().above(y), Blocks.STONE.defaultBlockState());
    var pig =
        new net.minecraft.world.entity.animal.Pig(
            net.minecraft.world.entity.EntityType.PIG, h.getLevel());
    pig.setNoAi(true);
    pig.setNoGravity(true);
    pig.setPos(Vec3.atCenterOf(p));
    h.getLevel().addFreshEntity(pig);
    net.mcreator.climber.event.RebarKnockback.start(pig, new Vec3(1, 0, 0));
    cfg.applySyncTag(old);
    h.runAfterDelay(
        12,
        () -> {
          h.assertTrue(
              pig.getBoundingBox().maxX <= p.getX() + 1.001,
              "Collision stops configured knockback at wall");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void resting_doors_use_live_dimensions_and_disable(GameTestHelper h) {
    var l = h.getLevel();
    var p = h.absolutePos(new BlockPos(4, 3, 4));
    l.setBlockAndUpdate(p.below(), Blocks.STONE.defaultBlockState());
    l.setBlockAndUpdate(
        p, Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING, Direction.NORTH));
    l.setBlockAndUpdate(
        p.above(),
        l.getBlockState(p)
            .setValue(
                DoorBlock.HALF,
                net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER));
    var cfg = ClimberConfig.INSTANCE;
    var old = cfg.toSyncTag();
    try {
      var tag = new CompoundTag();
      tag.putDouble("DoorHitboxX", 1.5);
      tag.putDouble("DoorHitboxY", 1.5);
      tag.putDouble("DoorHitboxZ", .25);
      cfg.applySyncTag(tag);
      var shape = l.getBlockState(p).getCollisionShape(l, p).bounds();
      h.assertTrue(
          Math.abs(shape.getXsize() - 1.5) < 1e-8 && Math.abs(shape.getZsize() - .25) < 1e-8,
          "Resting collision bypasses cached vanilla shape");
      var upper = l.getBlockState(p.above()).getCollisionShape(l, p.above()).bounds();
      h.assertTrue(upper.maxY == .5, "Upper-half shape respects total door height");
      tag.putBoolean("DoorPhysics", false);
      cfg.applySyncTag(tag);
      shape = l.getBlockState(p).getCollisionShape(l, p).bounds();
      h.assertTrue(
          Math.abs(shape.getXsize() - 1) < 1e-8 && Math.abs(shape.getZsize() - .1875) < 1e-8,
          "Physics OFF restores vanilla collision");
      var player = FakePlayerFactory.getMinecraft(l);
      var result =
          l.getBlockState(p)
              .use(
                  l,
                  player,
                  InteractionHand.MAIN_HAND,
                  new BlockHitResult(Vec3.atCenterOf(p), Direction.NORTH, p, false));
      h.assertTrue(
          l.getBlockState(p).getValue(DoorBlock.OPEN), "Physics OFF restores ordinary door use");
      h.succeed();
    } finally {
      cfg.applySyncTag(old);
    }
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void gravity_multiplier_restores_normal_on_exit(GameTestHelper h) {
    var cfg = ClimberConfig.INSTANCE;
    var old = cfg.toSyncTag();
    var player =
        FakePlayerFactory.get(
            h.getLevel(), new com.mojang.authlib.GameProfile(UUID.randomUUID(), "[GravityQA]"));
    try {
      var tag = new CompoundTag();
      tag.putDouble("ClimberGravity", .5);
      cfg.applySyncTag(tag);
      net.mcreator.climber.capability.ClimbCapability.get(player)
          .ifPresent(d -> d.setClimbEnabled(true));
      net.mcreator.climber.event.ClimberGravity.update(player);
      h.assertTrue(
          Math.abs(
                  player.getAttributeValue(net.minecraftforge.common.ForgeMod.ENTITY_GRAVITY.get())
                      - .04)
              < 1e-8,
          "Multiplier also affects free-fall in Climber mode");
      net.mcreator.climber.capability.ClimbCapability.get(player)
          .ifPresent(d -> d.setClimbEnabled(false));
      net.mcreator.climber.event.ClimberGravity.update(player);
      h.assertTrue(
          Math.abs(
                  player.getAttributeValue(net.minecraftforge.common.ForgeMod.ENTITY_GRAVITY.get())
                      - .08)
              < 1e-8,
          "Exiting Climber mode restores original gravity");
      h.succeed();
    } finally {
      cfg.applySyncTag(old);
    }
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void moving_platform_reconfiguration_resets_route_safely(GameTestHelper h) {
    var spec = new MechanismSpec();
    spec.kind = MechanismSpec.Kind.PLATFORM;
    spec.roundTripSeconds = 10;
    spec.setPath("0,0,0; 3,0,0");
    var obj = MechanismWorldTests.make(h, spec, 4, 3, 4);
    h.runAfterDelay(
        15,
        () -> {
          h.assertTrue(
              obj.position().distanceToSqr(obj.origin()) > .001,
              "Platform is moving before editing");
          var patch = MechanismSpec.load(obj.spec().save());
          patch.roundTripSeconds = 20;
          obj.reconfigure(patch);
          h.assertTrue(
              obj.position().equals(obj.origin()),
              "Remote configuration restarts at route origin, without redefining rail anchor");
          h.assertTrue(obj.spec().roundTripSeconds == 20, "Moving platform can be edited");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void door_position_offsets_rotate_and_preserve_dimensions(GameTestHelper h) {
    var cfg = ClimberConfig.INSTANCE;
    var old = cfg.toSyncTag();
    try {
      for (var face : Direction.Plane.HORIZONTAL)
        for (boolean right : new boolean[] {false, true})
          for (float angle : new float[] {0, 37, 90})
            for (double sign : new double[] {-1, 1}) {
              cfg.resetAll();
              var pos = new BlockPos(7, 11, 13);
              var before =
                  net.mcreator.climber.door.DoorGeometry.worldSegments(pos, face, right, angle);
              var t = new CompoundTag();
              t.putDouble("DoorHitboxPosX", sign * .125);
              t.putDouble("DoorHitboxPosY", sign * .25);
              t.putDouble("DoorHitboxPosZ", sign * .375);
              cfg.applySyncTag(t);
              var dir =
                  net.mcreator.climber.door.DoorGeometry.getPlankDirection(face, right, angle);
              var shift =
                  new Vec3(
                      sign * (.125 * dir[0] - .375 * dir[1]),
                      sign * .25,
                      sign * (.125 * dir[1] + .375 * dir[0]));
              var after =
                  net.mcreator.climber.door.DoorGeometry.worldSegments(pos, face, right, angle);
              AABB total = after.get(0);
              for (int i = 0; i < before.size(); i++) {
                var expected = before.get(i).move(shift);
                var actual = after.get(i);
                h.assertTrue(
                    expected.getCenter().distanceTo(actual.getCenter()) < 1e-8,
                    "Signed local offset follows facing/hinge/angle");
                h.assertTrue(
                    Math.abs(expected.getXsize() - actual.getXsize()) < 1e-8
                        && Math.abs(expected.getYsize() - actual.getYsize()) < 1e-8
                        && Math.abs(expected.getZsize() - actual.getZsize()) < 1e-8,
                    "Offsets translate without resizing");
                total = total.minmax(actual);
              }
              var lower =
                  net.mcreator.climber.door.DoorGeometry.rotatedShape(pos, face, right, angle, 0)
                      .bounds()
                      .move(pos);
              var upper =
                  net.mcreator.climber.door.DoorGeometry.rotatedShape(pos, face, right, angle, 1)
                      .bounds()
                      .move(pos.above());
              var combined = lower.minmax(upper);
              h.assertTrue(
                  combined.getCenter().distanceTo(total.getCenter()) < 1e-8
                      && Math.abs(combined.minY - total.minY) < 1e-8
                      && Math.abs(combined.maxY - total.maxY) < 1e-8,
                  "Half shapes preserve signed Y offset without seam clipping");
            }
      h.succeed();
    } finally {
      cfg.applySyncTag(old);
    }
  }
}
