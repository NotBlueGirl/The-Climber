package net.mcreator.climber.test;

import java.util.*;
import net.mcreator.climber.init.*;
import net.mcreator.climber.mechanism.*;
import net.minecraft.core.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.phys.*;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.gametest.*;

@GameTestHolder("climber")
@PrefixGameTestTemplate(false)
public final class MechanismWorldTests {
  static BlockPos abs(GameTestHelper h, int x, int y, int z) {
    return h.absolutePos(new BlockPos(x, y, z));
  }

  static MechanismEntity make(GameTestHelper h, MechanismSpec s, int x, int y, int z) {
    BlockPos b = abs(h, x, y, z);
    h.getLevel().setBlockAndUpdate(b, Blocks.STONE.defaultBlockState());
    return MechanismEntity.place(
        h.getLevel(), new Vec3(b.getX() + .5, b.getY() + .5, b.getZ()), Direction.NORTH, b, s);
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void ladder_layers_allow_climbing_gap(GameTestHelper h) {
    var l = h.getLevel();
    var b = ladder(h);
    var state = l.getBlockState(b);
    var gap = net.minecraft.world.phys.shapes.Shapes.create(new AABB(.2, 0, .05, .8, 1, .95));
    h.assertFalse(
        net.minecraft.world.phys.shapes.Shapes.joinIsNotEmpty(
            state.getCollisionShape(l, b), gap, net.minecraft.world.phys.shapes.BooleanOp.AND),
        "Double layer leaves player-width climbing gap between rails");
    h.assertTrue(
        state.getValue(MechanicalLadderBlock.LAYERS) == 2,
        "Paired visual/selection depth remains full block");
    MechanicalLadderBlock.hit(l, b);
    var child = l.getBlockState(b.below());
    h.assertFalse(
        net.minecraft.world.phys.shapes.Shapes.joinIsNotEmpty(
            child.getCollisionShape(l, b.below()),
            gap,
            net.minecraft.world.phys.shapes.BooleanOp.AND),
        "Deployed layer also allows ladder climbing");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void valve_opens_door(GameTestHelper h) {
    var l = h.getLevel();
    BlockPos p = abs(h, 3, 2, 3);
    l.setBlockAndUpdate(p.below(), Blocks.STONE.defaultBlockState());
    l.setBlockAndUpdate(p, Blocks.OAK_DOOR.defaultBlockState());
    l.setBlockAndUpdate(
        p.above(),
        Blocks.OAK_DOOR
            .defaultBlockState()
            .setValue(
                DoorBlock.HALF,
                net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER));
    var s = new MechanismSpec();
    s.kind = MechanismSpec.Kind.VALVE;
    s.valveStep = 1;
    s.valveMax = 2;
    var e = MechanismEntity.place(l, Vec3.atCenterOf(p).add(0, 0, -.5), Direction.NORTH, p, s);
    var player = FakePlayerFactory.getMinecraft(l);
    e.interact(player, InteractionHand.MAIN_HAND);
    h.assertFalse(
        l.getBlockState(p).getValue(DoorBlock.OPEN), "First turn must not activate early");
    h.runAfterDelay(
        5,
        () -> {
          e.interact(player, InteractionHand.MAIN_HAND);
          h.assertTrue(l.getBlockState(p).getValue(DoorBlock.OPEN), "Threshold must open door");
          h.assertTrue(e.progress() == 0, "Counter resets after activation");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void weak_hook_breaks(GameTestHelper h) {
    var s = new MechanismSpec();
    s.kind = MechanismSpec.Kind.WEAK_HOOK;
    s.weakSeconds = .1;
    var e = make(h, s, 3, 3, 3);
    var p = FakePlayerFactory.getMinecraft(h.getLevel());
    e.onGripTick(p);
    e.onGripTick(p);
    h.assertTrue(e.isAlive(), "Two hands in one tick must not double wear");
    h.runAfterDelay(
        2,
        () -> {
          e.onGripTick(p);
          h.assertFalse(e.isAlive(), "Weak hook must break after configured total grip time");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void rope_swing_and_save(GameTestHelper h) {
    var s = new MechanismSpec();
    s.kind = MechanismSpec.Kind.ROPE;
    s.ropeLength = 3;
    BlockPos p = abs(h, 4, 6, 4);
    h.getLevel().setBlockAndUpdate(p, Blocks.STONE.defaultBlockState());
    var e =
        MechanismEntity.place(
            h.getLevel(), new Vec3(p.getX() + .5, p.getY(), p.getZ() + .5), Direction.DOWN, p, s);
    var player = FakePlayerFactory.getMinecraft(h.getLevel());
    player.setDeltaMovement(.8, 0, 0);
    e.onGripTick(player);
    double start = e.getX();
    h.runAfterDelay(
        10,
        () -> {
          h.assertTrue(
              e.position().distanceTo(e.ceiling()) <= 3.5 && e.ropePoints(1).size() > 4,
              "Physical rope stays length constrained with multiple nodes");
          h.assertTrue(Math.abs(e.getX() - start) > .05, "Grab momentum must produce a swing");
          CompoundTag tag = e.saveWithoutId(new CompoundTag());
          var restored = new MechanismEntity(ClimberModEntities.MECHANISM.get(), h.getLevel());
          restored.load(tag);
          h.assertTrue(
              restored.spec().kind == MechanismSpec.Kind.ROPE && restored.spec().ropeLength == 3,
              "Rope setup survives NBT");
          h.assertTrue(restored.ceiling().distanceTo(e.ceiling()) < .0001, "Ceiling survives NBT");
          h.assertTrue(
              restored.ropePoints(1).equals(e.ropePoints(1)),
              "Every simulated rope node survives NBT");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 100)
  public static void platform_route_hooks_and_trigger(GameTestHelper h) {
    var s = new MechanismSpec();
    s.kind = MechanismSpec.Kind.PLATFORM;
    s.trigger = true;
    s.repeats = 1;
    s.roundTripSeconds = 1;
    s.path = new ArrayList<>(List.of(Vec3.ZERO, new Vec3(2, 0, 0), new Vec3(2, 2, 1)));
    var e = make(h, s, 4, 3, 5);
    Vec3 origin = e.position();
    h.runAfterDelay(
        3,
        () -> {
          h.assertTrue(e.position().distanceTo(origin) < .001, "Trigger gate prevents autostart");
          var hooks =
              h.getLevel()
                  .getEntitiesOfClass(
                      MechanismEntity.class, e.getBoundingBox().inflate(.5), q -> q.isChild());
          h.assertTrue(hooks.size() == 2, "Platform has exactly two independent hooks");
          var hook = hooks.get(0);
          Vec3 initial = hook.getGripPoint();
          e.trigger();
          h.runAfterDelay(
              5,
              () -> {
                h.assertTrue(
                    e.position().distanceTo(origin) > .3, "Platform moves along authored route");
                h.assertTrue(hook.getGripPoint().distanceTo(initial) > .3, "Hooks follow platform");
              });
          h.runAfterDelay(
              24,
              () -> {
                h.assertFalse(e.running(), "Finite repeats stop");
                h.assertTrue(
                    e.position().distanceTo(origin) < .001, "Round trip returns to origin");
                e.removeWithChildren();
                h.assertFalse(hook.isAlive(), "Deleting platform removes hooks");
                h.succeed();
              });
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void platform_redstone_gate(GameTestHelper h) {
    var s = new MechanismSpec();
    s.kind = MechanismSpec.Kind.PLATFORM;
    s.redstone = true;
    var e = make(h, s, 3, 3, 4);
    Vec3 start = e.position();
    h.runAfterDelay(
        4,
        () -> {
          h.assertTrue(e.position().equals(start), "Unpowered platform must wait");
          h.getLevel()
              .setBlockAndUpdate(abs(h, 4, 3, 4), Blocks.REDSTONE_BLOCK.defaultBlockState());
          h.runAfterDelay(
              8,
              () -> {
                h.assertTrue(
                    e.position().distanceTo(start) > .05, "Redstone releases movement gate");
                h.succeed();
              });
        });
  }

  static BlockPos ladder(GameTestHelper h) {
    BlockPos root = abs(h, 3, 5, 4);
    h.getLevel().setBlockAndUpdate(root.south(), Blocks.STONE.defaultBlockState());
    h.getLevel()
        .setBlockAndUpdate(
            root,
            ClimberModBlocks.MECHANICAL_LADDER
                .get()
                .defaultBlockState()
                .setValue(LadderBlock.FACING, Direction.NORTH));
    h.assertTrue(
        MechanicalLadderBlock.addLayer(h.getLevel(), root), "Second layer fits same block");
    return root;
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void ladder_deploy_and_redstone_reset(GameTestHelper h) {
    var l = h.getLevel();
    BlockPos root = ladder(h);
    MechanicalLadderBlock.hit(l, root);
    h.assertTrue(
        l.getBlockState(root).getValue(MechanicalLadderBlock.LAYERS) == 1, "Back layer stays");
    h.assertTrue(
        l.getBlockState(root).getValue(MechanicalLadderBlock.DEPLOYED),
        "Base tracks its deployed layer");
    h.assertTrue(l.getBlockState(root.above()).isAir(), "No vertical stacking requirement");
    h.assertTrue(
        l.getBlockState(root.below()).getValue(MechanicalLadderBlock.EXTENSION),
        "Front layer drops one block below");
    h.assertTrue(
        ((MechanicalLadderBlockEntity) l.getBlockEntity(root.below())).owner().equals(root),
        "Owned front layer");
    CompoundTag saved = l.getBlockEntity(root.below()).saveWithFullMetadata();
    var copy = new MechanicalLadderBlockEntity(root.below(), l.getBlockState(root.below()));
    copy.load(saved);
    h.assertTrue(root.equals(copy.owner()), "Owner survives reload");
    l.setBlockAndUpdate(root.east(), Blocks.REDSTONE_BLOCK.defaultBlockState());
    h.runAfterDelay(
        5,
        () -> {
          h.assertTrue(
              l.getBlockState(root).getValue(MechanicalLadderBlock.LAYERS) == 2,
              "Redstone restores layer into same block");
          h.assertTrue(l.getBlockState(root.below()).isAir(), "Outer layer retracts");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void ladder_does_not_overwrite(GameTestHelper h) {
    var l = h.getLevel();
    BlockPos root = ladder(h);
    l.setBlockAndUpdate(root.below(), Blocks.DIAMOND_BLOCK.defaultBlockState());
    MechanicalLadderBlock.hit(l, root);
    h.assertTrue(
        l.getBlockState(root).getValue(MechanicalLadderBlock.LAYERS) == 2,
        "Blocked deployment leaves both layers folded");
    h.assertTrue(l.getBlockState(root.below()).is(Blocks.DIAMOND_BLOCK), "No overwrite");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void projectile_deploys_ladder(GameTestHelper h) {
    BlockPos root = ladder(h);
    var ball =
        new net.minecraft.world.entity.projectile.Snowball(
            h.getLevel(), root.getX() + .5, root.getY() + .65, root.getZ() - 2);
    ball.shoot(0, 0, 1, 2f, 0);
    h.getLevel().addFreshEntity(ball);
    h.runAfterDelay(
        8,
        () -> {
          h.assertTrue(
              h.getLevel().getBlockState(root.below()).getBlock() instanceof MechanicalLadderBlock,
              "Real projectile deploys front layer");
          h.assertTrue(
              h.getLevel().getBlockState(root).getValue(MechanicalLadderBlock.LAYERS) == 1,
              "Projectile never drops the fixed layer");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void ladder_second_item_same_cell(GameTestHelper h) {
    var l = h.getLevel();
    BlockPos root = abs(h, 3, 3, 4);
    l.setBlockAndUpdate(root.south(), Blocks.STONE.defaultBlockState());
    l.setBlockAndUpdate(root, ClimberModBlocks.MECHANICAL_LADDER.get().defaultBlockState());
    var p =
        FakePlayerFactory.get(l, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "[Layers]"));
    p.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);
    p.setPos(Vec3.atCenterOf(root).add(0, 0, -2));
    var stack = new net.minecraft.world.item.ItemStack(ClimberModItems.MECHANICAL_LADDER.get(), 2);
    p.setItemInHand(InteractionHand.MAIN_HAND, stack);
    var hit = new BlockHitResult(Vec3.atCenterOf(root).add(0, .5, 0), Direction.UP, root, false);
    var result =
        stack.useOn(
            new net.minecraft.world.item.context.UseOnContext(p, InteractionHand.MAIN_HAND, hit));
    h.assertTrue(result.consumesAction(), "Second item placement succeeds");
    h.assertTrue(
        l.getBlockState(root).getValue(MechanicalLadderBlock.LAYERS) == 2,
        "Two layers occupy clicked block, not cell above");
    h.assertTrue(stack.getCount() == 1, "Exactly one item consumed");
    h.assertTrue(l.getBlockState(root.above()).isAir(), "Cell above stays empty");
    var drops = Block.getDrops(l.getBlockState(root), l, root, l.getBlockEntity(root));
    h.assertTrue(
        drops.stream().mapToInt(net.minecraft.world.item.ItemStack::getCount).sum() == 2,
        "Folded double ladder drops two items");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void ladder_no_duplicate_on_missing_layer(GameTestHelper h) {
    var l = h.getLevel();
    var root = ladder(h);
    MechanicalLadderBlock.hit(l, root);
    l.removeBlock(root.below(), false);
    l.setBlockAndUpdate(root.east(), Blocks.REDSTONE_BLOCK.defaultBlockState());
    h.runAfterDelay(
        4,
        () -> {
          h.assertTrue(
              l.getBlockState(root).getValue(MechanicalLadderBlock.LAYERS) == 1,
              "Removed front layer is not regenerated");
          h.assertFalse(
              l.getBlockState(root).getValue(MechanicalLadderBlock.DEPLOYED),
              "Missing layer clears deployment");
          h.succeed();
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void hammer_offhand_use_and_strike(GameTestHelper h) {
    var l = h.getLevel();
    var p =
        net.minecraftforge.common.util.FakePlayerFactory.get(
            l, new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(), "[HandTest]"));
    BlockPos at = abs(h, 4, 2, 3);
    p.setPos(at.getX() + .5, at.getY(), at.getZ() + .5);
    p.setYRot(0);
    p.setXRot(0);
    p.setItemInHand(
        InteractionHand.OFF_HAND,
        new net.minecraft.world.item.ItemStack(ClimberModItems.HAMMER.get()));
    Vec3 point = p.getEyePosition().add(0, 0, 2);
    BlockPos wall = BlockPos.containing(point.add(0, 0, .2));
    l.setBlockAndUpdate(wall, Blocks.STONE.defaultBlockState());
    var piton = net.mcreator.climber.entity.PitonEntity.create(l, point, Direction.NORTH, wall);
    l.addFreshEntity(piton);
    var stack = p.getOffhandItem();
    var item = (net.mcreator.climber.item.HammerItem) stack.getItem();
    item.use(l, p, InteractionHand.OFF_HAND);
    h.assertTrue(
        p.isUsingItem() && p.getUsedItemHand() == InteractionHand.OFF_HAND,
        "Hammer can charge in off hand");
    item.releaseUsing(stack, l, p, item.getUseDuration(stack) - 15);
    h.assertTrue(piton.isSecured(), "Charged off-hand hammer secures aimed piton");
    p.stopUsingItem();
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void debugger_places_on_door_before_vanilla_use(GameTestHelper h) {
    var l = h.getLevel();
    BlockPos at = abs(h, 3, 2, 4);
    l.setBlockAndUpdate(at.below(), Blocks.STONE.defaultBlockState());
    l.setBlockAndUpdate(at, Blocks.OAK_DOOR.defaultBlockState());
    l.setBlockAndUpdate(
        at.above(),
        Blocks.OAK_DOOR
            .defaultBlockState()
            .setValue(
                DoorBlock.HALF,
                net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER));
    var p =
        FakePlayerFactory.get(
            l, new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(), "[DebugTest]"));
    p.setGameMode(net.minecraft.world.level.GameType.CREATIVE);
    p.setPos(at.getX() + .5, at.getY(), at.getZ() - 2);
    var stack = new net.minecraft.world.item.ItemStack(ClimberModItems.DEBUGGER.get());
    var spec = new MechanismSpec();
    spec.kind = MechanismSpec.Kind.VALVE;
    stack.getOrCreateTag().put("mechanism", spec.save());
    p.setItemInHand(InteractionHand.MAIN_HAND, stack);
    var hit =
        new BlockHitResult(
            new Vec3(at.getX() + .5, at.getY() + .5, at.getZ()), Direction.NORTH, at, false);
    p.gameMode.useItemOn(p, l, stack, InteractionHand.MAIN_HAND, hit);
    var placed = l.getEntitiesOfClass(MechanismEntity.class, new AABB(at).inflate(.5));
    h.assertTrue(
        placed.size() == 1 && placed.get(0).spec().kind == MechanismSpec.Kind.VALVE,
        "Debugger must place valve before door consumes interaction");
    h.assertFalse(l.getBlockState(at).getValue(DoorBlock.OPEN), "Placement must not toggle door");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void debugger_rejects_survival_placement(GameTestHelper h) {
    var l = h.getLevel();
    BlockPos at = abs(h, 3, 2, 4);
    l.setBlockAndUpdate(at, Blocks.STONE.defaultBlockState());
    var p =
        FakePlayerFactory.get(
            l, new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(), "[NoDebug]"));
    p.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);
    var stack = new net.minecraft.world.item.ItemStack(ClimberModItems.DEBUGGER.get());
    p.setItemInHand(InteractionHand.MAIN_HAND, stack);
    var hit =
        new BlockHitResult(
            new Vec3(at.getX() + .5, at.getY() + .5, at.getZ()), Direction.NORTH, at, false);
    var result =
        stack
            .getItem()
            .useOn(
                new net.minecraft.world.item.context.UseOnContext(
                    p, InteractionHand.MAIN_HAND, hit));
    h.assertTrue(result == InteractionResult.FAIL, "Survival cannot use Creative Debugger");
    h.assertTrue(
        l.getEntitiesOfClass(MechanismEntity.class, new AABB(at).inflate(1)).isEmpty(),
        "Unauthorized placement creates nothing");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void linked_valve_and_rope_culling(GameTestHelper h) {
    var level = h.getLevel();
    BlockPos target = abs(h, 7, 2, 6);
    level.setBlockAndUpdate(target.below(), Blocks.STONE.defaultBlockState());
    level.setBlockAndUpdate(target, Blocks.OAK_DOOR.defaultBlockState());
    level.setBlockAndUpdate(
        target.above(),
        Blocks.OAK_DOOR
            .defaultBlockState()
            .setValue(
                DoorBlock.HALF,
                net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER));
    var spec = new MechanismSpec();
    spec.kind = MechanismSpec.Kind.VALVE;
    spec.valveStep = spec.valveMax = 1;
    spec.valveTarget = target;
    var valve = make(h, spec, 2, 2, 3);
    valve.interact(FakePlayerFactory.getMinecraft(level), InteractionHand.MAIN_HAND);
    h.assertTrue(
        level.getBlockState(target).getValue(DoorBlock.OPEN),
        "Valve activates selected remote block, not supporting stone");
    var ropeSpec = new MechanismSpec();
    ropeSpec.kind = MechanismSpec.Kind.ROPE;
    ropeSpec.ropeLength = 3;
    BlockPos ceiling = abs(h, 4, 7, 4);
    level.setBlockAndUpdate(ceiling, Blocks.STONE.defaultBlockState());
    var rope =
        MechanismEntity.place(
            level, Vec3.atLowerCornerOf(ceiling).add(.5, 0, .5), Direction.DOWN, ceiling, ropeSpec);
    h.assertTrue(
        rope.getBoundingBoxForCulling().inflate(.001).contains(rope.ceiling()),
        "Rope anchor remains in render bounds when endpoint is off-screen");
    h.succeed();
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void platform_keeps_moving_on_hook_grab(GameTestHelper h) {
    var spec = new MechanismSpec();
    spec.kind = MechanismSpec.Kind.PLATFORM;
    spec.roundTripSeconds = 2;
    spec.path = new ArrayList<>(List.of(Vec3.ZERO, new Vec3(2, 0, 0)));
    var platform = make(h, spec, 4, 3, 6);
    var hooks =
        h.getLevel()
            .getEntitiesOfClass(
                MechanismEntity.class, platform.getBoundingBox().inflate(.6), q -> q.isChild());
    h.assertTrue(hooks.size() == 2, "Two hooks");
    h.assertTrue(
        hooks.stream().allMatch(q -> q.authoringRoot() == platform),
        "Editing a child hook targets the platform");
    double
        low =
            hooks.stream()
                .mapToDouble(e -> e.position().y - platform.position().y)
                .min()
                .orElseThrow(),
        high =
            hooks.stream()
                .mapToDouble(e -> e.position().y - platform.position().y)
                .max()
                .orElseThrow();
    h.assertTrue(Math.abs(low + high + .28 - 2) < 1e-6, "Upper/lower hook margins symmetric");
    Vec3 start = platform.position();
    hooks.get(0).onGripTick(FakePlayerFactory.getMinecraft(h.getLevel()));
    h.runAfterDelay(
        2,
        () -> {
          h.assertTrue(
              platform.position().distanceToSqr(start) > 1e-6, "Hook grab must not pause platform");
          h.runAfterDelay(
              5,
              () -> {
                h.assertTrue(
                    platform.position().distanceToSqr(start) > .001,
                    "Platform keeps moving with its hooks");
                h.succeed();
              });
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void platform_contact_keeps_curve_moving(GameTestHelper h) {
    var spec = new MechanismSpec();
    spec.kind = MechanismSpec.Kind.PLATFORM;
    spec.roundTripSeconds = 3;
    spec.curved = true;
    var first = abs(h, 4, 3, 6);
    spec.selectRailBlocks(List.of(first, first.offset(2, 1, 0), first.offset(3, 1, 1)));
    spec.validate();
    var e = make(h, spec, 4, 3, 6);
    Vec3 initial = e.position();
    e.playerTouch(FakePlayerFactory.getMinecraft(h.getLevel()));
    h.runAfterDelay(
        2,
        () -> {
          h.assertTrue(e.position().distanceToSqr(initial) > 1e-6, "Touch does not pause travel");
          h.runAfterDelay(
              6,
              () -> {
                h.assertTrue(
                    e.position().distanceToSqr(initial) > .001, "Travel continues on same curve");
                h.assertTrue(e.spec().route().size() > 3, "World uses sampled curved route");
                h.succeed();
              });
        });
  }

  @GameTest(template = "empty", timeoutTicks = 80)
  public static void catalog_tracks_roots_and_removals(GameTestHelper h) {
    var l = h.getLevel();
    var s = new MechanismSpec();
    s.kind = MechanismSpec.Kind.PLATFORM;
    var e = make(h, s, 4, 3, 6);
    var catalog = MechanismCatalog.get(l.getServer());
    var rows = catalog.query(e.getUUID().toString());
    h.assertTrue(rows.size() == 1, "Created root indexed once");
    h.assertTrue(
        catalog.query("HOOK").stream()
            .noneMatch(r -> r.pos().distSqr(e.blockPosition()) < 4 && r.id().startsWith("entity:")),
        "Owned platform hooks are not duplicate objects");
    var restored = MechanismCatalog.load(catalog.save(new CompoundTag()));
    h.assertTrue(
        restored.query(e.getUUID().toString()).size() == 1,
        "Catalog survives save with unloaded metadata");
    e.removeWithChildren();
    h.assertTrue(
        catalog.query(e.getUUID().toString()).isEmpty(), "Removed object disappears from catalog");
    var root = ladder(h);
    MechanismCatalog.ladder(l, root);
    h.assertTrue(
        catalog.query(MechanismCatalog.ladderId(l, root)).size() == 1,
        "Layered ladder indexed as one object");
    l.removeBlock(root, false);
    h.assertTrue(
        catalog.query(MechanismCatalog.ladderId(l, root)).isEmpty(),
        "Mined ladder removed from catalog");
    h.succeed();
  }
}
