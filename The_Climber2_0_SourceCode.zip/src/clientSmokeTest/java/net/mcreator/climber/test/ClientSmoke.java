package net.mcreator.climber.test;

import net.mcreator.climber.client.screens.*;
import net.mcreator.climber.mechanism.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "climber", value = Dist.CLIENT)
public final class ClientSmoke {
  private static boolean opened;
  private static int ticks;
  private static int valveId = -1;
  private static int ropeId = -1, supportId = -1, traceTicks;

  @SubscribeEvent
  public static void tick(TickEvent.ClientTickEvent e) {
    var mc = Minecraft.getInstance();
    if (e.phase == TickEvent.Phase.END
        && traceTicks > 0
        && mc.player != null
        && mc.getSingleplayerServer() != null
        && --traceTicks % 20 == 0) {
      var uuid = mc.player.getUUID();
      mc.getSingleplayerServer()
          .execute(
              () -> {
                var sp = mc.getSingleplayerServer().getPlayerList().getPlayer(uuid);
                var entity = sp.level().getEntity(supportId);
                net.mcreator.climber.capability.ClimbCapability.get(sp)
                    .ifPresent(
                        d ->
                            System.out.println(
                                "LIVE_SUPPORT player="
                                    + sp.position()
                                    + " support="
                                    + (entity == null ? null : entity.position())
                                    + " grab="
                                    + d.isRightHandGrabbing()
                                    + " id="
                                    + d.getRightHoldEntity()));
              });
    }
    if (e.phase == TickEvent.Phase.END
        && !opened
        && ++ticks > 120
        && mc.getOverlay() == null
        && mc.screen != null) {
      opened = true;
      mc.setScreen(new MechanismEditorScreen(-1));
      System.out.println(
          "UI_SMOKE_OPENED "
              + mc.getWindow().getGuiScaledWidth()
              + "x"
              + mc.getWindow().getGuiScaledHeight());
    }
  }

  @SubscribeEvent
  public static void key(InputEvent.Key e) {
    if (e.getAction() != 1) return;
    var mc = Minecraft.getInstance();
    if ((e.getKey() == 91 || e.getKey() == 93)
        && mc.player != null
        && mc.getSingleplayerServer() != null) {
      mc.setScreen(null);
      var id = mc.player.getUUID();
      mc.getSingleplayerServer()
          .execute(
              () -> {
                var sp = mc.getSingleplayerServer().getPlayerList().getPlayer(id);
                if (e.getKey() == 93) {
                  sp.setItemInHand(
                      net.minecraft.world.InteractionHand.OFF_HAND,
                      net.minecraft.world.item.ItemStack.EMPTY);
                  System.out.println("SWAP_EMPTY_OFF_READY");
                  return;
                }
                sp.teleportTo(sp.serverLevel(), 1.5, 81, 3.5, 0, 0);
                sp.getAbilities().flying = true;
                sp.onUpdateAbilities();
                sp.setItemInHand(
                    net.minecraft.world.InteractionHand.MAIN_HAND,
                    new net.minecraft.world.item.ItemStack(
                        net.mcreator.climber.init.ClimberModItems.HAMMER.get()));
                sp.setItemInHand(
                    net.minecraft.world.InteractionHand.OFF_HAND,
                    new net.minecraft.world.item.ItemStack(
                        net.mcreator.climber.init.ClimberModItems.CRANK_FLASHLIGHT.get()));
                net.mcreator.climber.ClimberConfig.INSTANCE.setGripMode(
                    net.mcreator.climber.grip.GripMode.LIP_HANDS);
                net.mcreator.climber.ClimberConfig.INSTANCE.setAutoGripMode(
                    net.mcreator.climber.grip.AutoGripMode.OFF);
                net.mcreator.climber.capability.ClimbCapability.get(sp)
                    .ifPresent(d -> d.setClimbEnabled(true));
                var dest = net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> sp);
                net.mcreator.climber.ClimberMod.PACKET_HANDLER.send(
                    dest,
                    new net.mcreator.climber.network.ClimbStatePacket(id, true, false, false));
                net.mcreator.climber.ClimberMod.PACKET_HANDLER.send(
                    dest,
                    new net.mcreator.climber.network.GripModeSyncPacket(
                        net.mcreator.climber.grip.GripMode.LIP_HANDS,
                        net.mcreator.climber.grip.AutoGripMode.OFF));
                System.out.println("SWAP_SETUP_READY");
              });
    }
    if (e.getKey() == 293 && mc.player != null) {
      System.out.println(
          "SWAP_CLIENT using="
              + mc.player.isUsingItem()
              + " main="
              + mc.player.getMainHandItem()
              + " off="
              + mc.player.getOffhandItem()
              + " grabs="
              + net.mcreator.climber.client.ClimberClientData.rightGrabbing
              + ","
              + net.mcreator.climber.client.ClimberClientData.leftGrabbing);
      var id = mc.player.getUUID();
      mc.getSingleplayerServer()
          .execute(
              () -> {
                var sp = mc.getSingleplayerServer().getPlayerList().getPlayer(id);
                net.mcreator.climber.capability.ClimbCapability.get(sp)
                    .ifPresent(
                        d ->
                            System.out.println(
                                "SWAP_SERVER enabled="
                                    + d.isClimbEnabled()
                                    + " grabs="
                                    + d.isRightHandGrabbing()
                                    + ","
                                    + d.isLeftHandGrabbing()
                                    + " using="
                                    + sp.isUsingItem()));
              });
    }
    if (e.getKey() == 79 && mc.player != null && mc.screen == null)
      mc.setScreen(new MechanismObjectScreen(new MechanismEditorScreen(-1)));
    if (e.getKey() == 80
        && mc.screen == null
        && mc.player != null
        && mc.getSingleplayerServer() != null) {
      mc.setScreen(null);
      var uuid = mc.player.getUUID();
      mc.getSingleplayerServer()
          .execute(
              () -> {
                var l = mc.getSingleplayerServer().overworld();
                var sp = mc.getSingleplayerServer().getPlayerList().getPlayer(uuid);
                var b = new BlockPos(-3, 82, 5);
                l.setBlockAndUpdate(
                    b,
                    net.mcreator.climber.init.ClimberModBlocks.MECHANICAL_LADDER
                        .get()
                        .defaultBlockState()
                        .setValue(MechanicalLadderBlock.LAYERS, 2));
                var b2 = new BlockPos(-1, 82, 5);
                l.setBlockAndUpdate(
                    b2,
                    net.mcreator.climber.init.ClimberModBlocks.MECHANICAL_LADDER
                        .get()
                        .defaultBlockState()
                        .setValue(MechanicalLadderBlock.LAYERS, 2));
                MechanicalLadderBlock.hit(l, b2);
                var ceiling = new BlockPos(-5, 87, -4);
                l.setBlockAndUpdate(
                    ceiling, net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
                var spec = new MechanismSpec();
                spec.kind = MechanismSpec.Kind.ROPE;
                spec.ropeLength = 5;
                var rope =
                    MechanismEntity.place(
                        l, new Vec3(-4.5, 87, -3.5), Direction.DOWN, ceiling, spec);
                sp.teleportTo(l, -1, 81, -1, 0, 0);
                ropeId = rope.getId();
                System.out.println("LAYER_ROPE_FIXTURE_READY rope=" + rope.getId());
              });
    }
    if ((e.getKey() == 82 || e.getKey() == 84)
        && mc.screen == null
        && mc.player != null
        && mc.getSingleplayerServer() != null) {
      mc.setScreen(null);
      var uuid = mc.player.getUUID();
      mc.getSingleplayerServer()
          .execute(
              () -> {
                var server = mc.getSingleplayerServer();
                var sp = server.getPlayerList().getPlayer(uuid);
                var l = sp.serverLevel();
                if (!sp.getMainHandItem().isEmpty() || !sp.getOffhandItem().isEmpty()) {
                  sp.setItemInHand(
                      net.minecraft.world.InteractionHand.MAIN_HAND,
                      net.minecraft.world.item.ItemStack.EMPTY);
                  sp.setItemInHand(
                      net.minecraft.world.InteractionHand.OFF_HAND,
                      net.minecraft.world.item.ItemStack.EMPTY);
                  System.out.println("LIVE_EMPTY_READY");
                  return;
                }
                MechanismEntity held = null;
                if (e.getKey() == 82 && l.getEntity(ropeId) instanceof MechanismEntity rope)
                  held = rope;
                if (e.getKey() == 84) {
                  var spec = new MechanismSpec();
                  spec.kind = MechanismSpec.Kind.PLATFORM;
                  spec.roundTripSeconds = 12;
                  spec.path =
                      new java.util.ArrayList<>(java.util.List.of(Vec3.ZERO, new Vec3(3, 0, 0)));
                  var platform =
                      MechanismEntity.place(
                          l, new Vec3(0.5, 84, 5.9), Direction.NORTH, new BlockPos(0, 84, 6), spec);
                  held =
                      l.getEntitiesOfClass(
                              MechanismEntity.class,
                              platform.getBoundingBox().inflate(.6),
                              q -> q.isChild())
                          .get(0);
                }
                if (held == null) return;
                var h = held;
                supportId = h.getId();
                traceTicks = 240;
                Vec3 a = h.getGripPoint();
                sp.teleportTo(l, a.x, a.y - 1.1, a.z - .25, 0, 0);
                sp.getAbilities().flying = false;
                sp.onUpdateAbilities();
                sp.setDeltaMovement(Vec3.ZERO);
                net.mcreator.climber.capability.ClimbCapability.get(sp)
                    .ifPresent(
                        d -> {
                          d.setClimbEnabled(true);
                          d.setRightHandGrabbing(true);
                          d.setRightAnchor(a);
                          d.setRightHoldEntity(h.getId());
                          d.setLeftHandGrabbing(false);
                          d.setLeftAnchor(null);
                          d.setLeftHoldEntity(-1);
                        });
                var dest = net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> sp);
                net.mcreator.climber.ClimberMod.PACKET_HANDLER.send(
                    dest,
                    new net.mcreator.climber.network.ClimbStatePacket(uuid, true, true, false));
                net.mcreator.climber.ClimberMod.PACKET_HANDLER.send(
                    dest,
                    new net.mcreator.climber.network.AnchorSyncPacket(
                        uuid, a, null, h.getId(), -1));
                System.out.println("LIVE_SUPPORT_ATTACHED=" + h.spec().kind + " id=" + supportId);
              });
    }
    if (e.getKey() == 85 && mc.screen == null && mc.getSingleplayerServer() != null) {
      mc.getSingleplayerServer()
          .execute(
              () -> {
                var l = mc.getSingleplayerServer().overworld();
                var block = new BlockPos(1008, 80, 1008);
                l.getChunkSource()
                    .addRegionTicket(
                        net.minecraft.server.level.TicketType.POST_TELEPORT,
                        new net.minecraft.world.level.ChunkPos(block),
                        2,
                        12345);
                l.getChunkAt(block);
                l.setBlockAndUpdate(
                    block, net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
                var spec = new MechanismSpec();
                spec.kind = MechanismSpec.Kind.VALVE;
                var obj =
                    MechanismEntity.place(
                        l, Vec3.atCenterOf(block).add(0, 0, -.5), Direction.NORTH, block, spec);
                MechanismCatalog.get(l.getServer()).track(obj);
                System.out.println("REMOTE_FIXTURE=" + obj.getUUID() + " at " + obj.position());
              });
    }
    if (e.getKey() == 89
        && mc.screen == null
        && mc.player != null
        && mc.getSingleplayerServer() != null) {
      var uuid = mc.player.getUUID();
      mc.getSingleplayerServer()
          .execute(
              () -> {
                var sp = mc.getSingleplayerServer().getPlayerList().getPlayer(uuid);
                sp.setItemInHand(
                    net.minecraft.world.InteractionHand.MAIN_HAND,
                    new net.minecraft.world.item.ItemStack(
                        net.mcreator.climber.init.ClimberModItems.DEBUGGER.get()));
                sp.getAbilities().flying = true;
                sp.onUpdateAbilities();
                sp.connection.teleport(1000.5, 95, 1000.5, 0, 0);
                System.out.println("REMOTE_AWAY " + sp.position());
              });
    }
    if (e.getKey() == 294) {
      mc.options.guiScale().set(mc.options.guiScale().get() == 2 ? 3 : 2);
      mc.resizeDisplay();
      mc.setScreen(new SettingsLayoutScreen(null));
    }
    if (e.getKey() == 295) mc.setScreen(new MechanismEditorScreen(-1));
    if (e.getKey() == 296) mc.setScreen(new ModelGalleryScreen());
    if (e.getKey() == 297 && mc.level == null)
      mc.createWorldOpenFlows().loadLevel(mc.screen, "PhysicsQA");
    if (e.getKey() == 298 && mc.getSingleplayerServer() != null && mc.player != null) setup();
    if (e.getKey() == 299
        && mc.level != null
        && mc.level.getEntity(valveId) instanceof MechanismEntity valve) {
      var s = MechanismSpec.load(valve.spec().save());
      s.valveTarget = new BlockPos(3, 82, 6);
      Vec3 original = mc.player.position();
      mc.setScreen(
          new MechanismCameraScreen(
              new MechanismEditorScreen(valveId),
              s,
              valve,
              true,
              chosen -> {
                net.mcreator.climber.ClimberMod.PACKET_HANDLER.sendToServer(
                    new net.mcreator.climber.network.MechanismEditPacket(
                        chosen.save(), valveId, 0));
                System.out.println(
                    "CAMERA_CONFIRM_PLAYER_UNMOVED=" + mc.player.position().equals(original));
              }));
    }
    if (e.getKey() == 301 && mc.level != null && mc.player != null) {
      var s = new MechanismSpec();
      s.kind = MechanismSpec.Kind.PLATFORM;
      s.curved = true;
      s.roundTripSeconds = 20;
      s.selectRailBlocks(
          java.util.List.of(
              new BlockPos(-3, 81, 6), new BlockPos(-1, 83, 6), new BlockPos(2, 83, 6)));
      mc.setScreen(
          new MechanismCameraScreen(
              new MechanismEditorScreen(-1),
              s,
              null,
              false,
              chosen -> System.out.println("CAMERA_ROUTE_POINTS=" + chosen.route().size())));
    }
  }

  private static void setup() {
    var mc = Minecraft.getInstance();
    var server = mc.getSingleplayerServer();
    if (mc.player == null) return;
    mc.getTutorial().setStep(net.minecraft.client.tutorial.TutorialSteps.NONE);
    mc.getToasts().clear();
    var id = mc.player.getUUID();
    mc.setScreen(null);
    server.execute(
        () -> {
          var level = server.overworld();
          level.setDayTime(6000);
          var player = server.getPlayerList().getPlayer(id);
          player.setGameMode(net.minecraft.world.level.GameType.CREATIVE);
          for (int x = -7; x <= 7; x++)
            for (int y = 79; y <= 87; y++)
              level.setBlockAndUpdate(
                  new BlockPos(x, y, 6),
                  net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
          for (int x = -8; x <= 8; x++)
            for (int z = -6; z <= 7; z++)
              level.setBlockAndUpdate(
                  new BlockPos(x, 79, z),
                  net.minecraft.world.level.block.Blocks.SMOOTH_STONE.defaultBlockState());
          var door = new BlockPos(3, 81, 6);
          level.setBlockAndUpdate(
              door.below(), net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
          level.setBlockAndUpdate(
              door, net.minecraft.world.level.block.Blocks.OAK_DOOR.defaultBlockState());
          level.setBlockAndUpdate(
              door.above(),
              net.minecraft.world.level.block.Blocks.OAK_DOOR
                  .defaultBlockState()
                  .setValue(
                      net.minecraft.world.level.block.DoorBlock.HALF,
                      net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER));
          for (var e :
              level.getEntitiesOfClass(
                  MechanismEntity.class, new net.minecraft.world.phys.AABB(-10, 78, -8, 10, 90, 8)))
            e.removeWithChildren();
          var s = new MechanismSpec();
          s.kind = MechanismSpec.Kind.VALVE;
          var valve =
              MechanismEntity.place(
                  level, new Vec3(.5, 82.5, 6), Direction.NORTH, new BlockPos(0, 82, 6), s);
          valveId = valve.getId();
          player.setItemInHand(
              net.minecraft.world.InteractionHand.MAIN_HAND,
              new net.minecraft.world.item.ItemStack(
                  net.mcreator.climber.init.ClimberModItems.DEBUGGER.get()));
          player.setItemInHand(
              net.minecraft.world.InteractionHand.OFF_HAND,
              net.minecraft.world.item.ItemStack.EMPTY);
          player.teleportTo(level, .5, 81, .5, 0, 0);
          player.getAbilities().flying = true;
          player.onUpdateAbilities();
          mc.execute(() -> System.out.println("CAMERA_WORLD_READY valve=" + valveId));
        });
  }
}
