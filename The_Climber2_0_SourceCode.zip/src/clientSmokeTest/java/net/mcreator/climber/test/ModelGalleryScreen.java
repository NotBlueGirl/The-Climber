package net.mcreator.climber.test;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import net.mcreator.climber.client.model.MechanismModels;
import net.mcreator.climber.client.renderer.MechanismRenderer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

/** Test-only gallery uses the exact world meshes/materials. Never bundled in the release JAR. */
public final class ModelGalleryScreen extends Screen {
  private int page;
  private float angle;
  private static final String[] TITLES = {
    "VALVE / HEXAGONAL WHEEL",
    "ROPE / BRAID + CEILING MOUNT",
    "MOVING PLATFORM / 3 x 2 BLOCKS",
    "CLIMBING HOOK / TRIANGULAR WEDGE",
    "WEAK HOOK / TRIANGULAR WEDGE",
    "CLIMBING HOOK / SIDE PROFILE",
    "WEAK HOOK / SIDE PROFILE",
    "MECHANICAL LADDER / VOLUMETRIC",
    "LADDER ITEM / BAKED BLOCK MODEL",
    "DEBUGGER TOOL / 3D WRENCH"
  };

  public ModelGalleryScreen() {
    super(Component.literal("Mechanism model QA"));
  }

  @Override
  public boolean keyPressed(int key, int scan, int mods) {
    if (key == 262) {
      page = (page + 1) % TITLES.length;
      angle = 0;
      return true;
    }
    if (key == 263) {
      page = Math.floorMod(page - 1, TITLES.length);
      angle = 0;
      return true;
    }
    if (key == 32) {
      angle += 30;
      return true;
    }
    return super.keyPressed(key, scan, mods);
  }

  @Override
  public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
    g.fill(0, 0, width, height, 0xFF151C22);
    g.fill(0, 0, width, 41, 0xFF10151B);
    g.drawString(font, "THE CLIMBER  /  1.4.0 MODEL QA", 12, 10, 0xDFB92D, false);
    g.drawString(font, TITLES[page], 12, 25, 0xFFFFFF, false);
    g.drawString(font, "< >  Models      Space  Rotate", 12, height - 18, 0xA1ADB6, false);
    g.drawString(font, (page + 1) + " / 10", width - 45, height - 18, 0xA1ADB6, false);
    g.flush();
    if (page == 8 || page == 9) {
      var ip = g.pose();
      ip.pushPose();
      ip.translate(width * .5 - 60, height * .5 - 60, 50);
      ip.scale(7.5f, 7.5f, 7.5f);
      g.renderItem(
          new net.minecraft.world.item.ItemStack(
              (page == 9
                  ? net.mcreator.climber.init.ClimberModItems.DEBUGGER.get()
                  : net.mcreator.climber.init.ClimberModItems.MECHANICAL_LADDER.get())),
          0,
          0);
      g.flush();
      ip.popPose();
      return;
    }
    var p = g.pose();
    p.pushPose();
    p.translate(width * .5, height * .55, 300);
    float scale =
        page == 2
            ? Math.min(width * .25f, height * .28f)
            : page == 1 ? height * .38f : page == 7 ? height * .62f : height * .85f;
    p.scale(scale, -scale, scale);
    p.mulPose(Axis.XP.rotationDegrees(page == 5 || page == 6 ? 0 : 20));
    p.mulPose(
        Axis.YP.rotationDegrees((page == 5 || page == 6 ? 90 : page == 7 ? 152 : -28) + angle));
    if (page == 0) {
      p.translate(0, -.15, 0);
      draw("valve_base", g);
      p.translate(0, .15, .12);
      draw("valve_wheel", g);
    } else if (page == 1) {
      p.translate(0, -.75, 0);
      MechanismRenderer.repeat(
          "rope_link", p, g.bufferSource(), Vec3.ZERO, new Vec3(0, 1.5, 0), 15728880);
      draw("rope_end", g);
      p.translate(0, 1.5, 0);
      draw("rope_anchor", g);
    } else if (page == 2) {
      p.translate(0, -1, 0);
      for (float x : new float[] {-.85f, .85f}) {
        p.pushPose();
        p.translate(x, -.25, -.16);
        MechanismRenderer.repeat(
            "rail_segment", p, g.bufferSource(), Vec3.ZERO, new Vec3(0, 2.5, 0), 15728880);
        p.popPose();
      }
      draw("platform", g);
      for (double y : new double[] {.5, 1.22}) {
        p.pushPose();
        p.translate(0, y, .2);
        draw("climbing_hook", g);
        p.popPose();
      }
    } else if (page == 7) {
      p.translate(-.5, -.5, -.85);
      draw("mechanical_ladder", g);
    } else {
      p.translate(0, -.14, 0);
      draw(page == 4 || page == 6 ? "weak_climbing_hook" : "climbing_hook", g);
    }
    RenderSystem.enableDepthTest();
    Lighting.setupFor3DItems();
    g.flush();
    p.popPose();
    Lighting.setupFor3DItems();
  }

  private void draw(String name, GuiGraphics g) {
    MechanismModels.draw(name, g.pose(), g.bufferSource(), 15728880);
  }
}
